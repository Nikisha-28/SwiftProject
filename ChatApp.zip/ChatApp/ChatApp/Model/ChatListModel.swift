//
//
// ChatListModel.swift
// ChatApp
//
// Created by Shubh Magdani on 31/01/25
// Copyright © 2025 Differenz System Pvt. Ltd. All rights reserved.
//


import Foundation

struct ChatListModel: Codable, Hashable, Identifiable {
     
    var id = UUID()
    var roomId : String?
    var userName: String?
    var lastMessage: String?
    var timeStamp: Int? // Store timestamp as Int
    var senderId : String?
    var profileUrl : String?

    init(userName: String? = nil, roomId : String? = nil , lastMessage: String? = nil, timeStamp: Int? = nil,senderId : String? = nil, profileUrl : String? = nil) {
        self.userName = userName
        self.roomId = roomId
        self.lastMessage = lastMessage
        self.timeStamp = timeStamp
        self.senderId = senderId
        self.profileUrl = profileUrl
    }

    // Convert Int timestamp to readable date format
    var formattedTime: String {
        guard let timeStamp = timeStamp else { return "" }
        
        // Convert milliseconds to seconds
        let timeInterval = TimeInterval(timeStamp) / 1000
        
        // Create a Date object from the time interval
        let date = Date(timeIntervalSince1970: timeInterval)
        
        // Set up the DateFormatter for your desired format
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM d, h:mm a" // Example: "Jan 31, 10:30 AM"
        
        // Return the formatted time as a string
        return dateFormatter.string(from: date)
    }
}

