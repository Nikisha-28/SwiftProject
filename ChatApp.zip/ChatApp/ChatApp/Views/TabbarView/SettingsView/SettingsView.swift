//
//  SettingsView.swift
//  ChatApp
//
//  Created by differenz48 on 31/01/25.
//

import SwiftUI
import SDWebImageSwiftUI
struct SettingsView: View {
    
    ///`Declaration`
    @State var txtUsername: String = ""
    @State var txtGender: String = ""
    @State var txtPhoneNumber: String = ""
    @State var txtPassword: String = ""
    @State var isImagePickerOpen: Bool = false
    @State var isDialogOpen: Bool = false
    
    @State var profileImage : UIImage? = nil
    @State var selection = Country(code: "+91" , name: "India")
    @State var profileUrl : String = ""
    
    @StateObject var viewModel: ChatAppModel = .shared
    
    static var uniqueKey: String {
        UUID().uuidString
    }
    
    static let options: [DropdownOption] = [
        DropdownOption(key: uniqueKey, value: Gender.kMale),
        DropdownOption(key: uniqueKey, value: Gender.kFemale),
        DropdownOption(key: uniqueKey, value: Gender.kOther)
    ]
    
    var body: some View {
        VStack {
        ScrollView {
            VStack(alignment: .leading) {
                HStack {
                    
                    Spacer()
                    Button(action: {
                        isDialogOpen = true
                    })
                    {
                        if profileImage != nil {
                            VStack {
                                Image(uiImage: profileImage ?? UIImage())
                                    .resizable()
                                    .frame(width: 100 , height: 100)
                                    .cornerRadius(100, corners: .allCorners)
                            }
                            .padding(5)
                            .background(Color.AppBrownColor , in: RoundedRectangle(cornerRadius: 100).stroke(lineWidth: 3))
                            .padding(.top,10)
                            
                        }
                        else   {
                            VStack {
                                WebImage(url: URL(string: profileUrl),options: [ .fromLoaderOnly]){ image in
                                    image.resizable()
                                        .frame(width: 100 , height: 100)
                                        .cornerRadius(100, corners: .allCorners)
                                } placeholder: {
                                    Image(systemName: "plus.circle.dashed")
                                        .resizable()
                                        .frame(width: 100 , height: 100)
                                        .foregroundStyle(Color.AppBrownColor)
                                }
                                .indicator(.activity)
                                
                            }
                            .padding(5)
                            .background(Color.AppBrownColor , in: RoundedRectangle(cornerRadius: 100).stroke(lineWidth: 3))
                            .padding(.top,10)
                            
                        }

                    }
                    
                    Spacer()
                }
                .padding(.bottom)
                VStack(alignment: .leading,spacing: 30) {
                    TextFieldView(placeholder: "Email", text: .constant(UserDefaults.standard.loginUser?.email ?? ""))
                        .disabled(true)
                    GenderPicker(placeholder: "Gender", text: $txtGender)
                    NumberField(shouldHavePicker: .constant(true), selection: $selection, text: $txtPhoneNumber)
                    SecureFieldView(placeholder: "Password", text: $txtPassword)
                }
                .padding(15)
                .padding(.top, 10)
                Spacer()
            }
            .padding(.horizontal, 20)
            
            
            
            
            
            Button {
                FireBaseAuthService.shared.logoutUser {
                    viewModel.chatList = []
                    viewModel.isDashBoardShowing = false
                }
            } label: {
                CommonText(title: "Logout",fontSize: 18,foregroundColor: Color.AppBrownColor)
                    .padding(12)
                    .padding(.horizontal,10)
                    .overlay {
                        RoundedRectangle(cornerRadius: 18)
                            .fill(Color.clear)
                            .stroke(.appBrown, lineWidth: 2)
                    }
                    .padding(.bottom,10)
            }
            
        }
        .padding(.vertical)
    }
        .fullScreenCover(isPresented: $isImagePickerOpen){
            CustomImagePickerView(image: $profileImage, isPresented: $isImagePickerOpen) {
                Indicator.show()
                Task {
                    await SBStorageManager.shared.uploadImage(profileImage ?? UIImage(), folderName: .profileImages){ folderPath in
                        guard let folderPath = folderPath else {
                            Indicator.hide()
                            Alert.show(message : "Something went wrong.")
                            return
                        }
                        guard let user = UserDefaults.standard.loginUser else {return}
                        let userDict: [String: Any] = UserModel.getUserInput(
                            userId: user.userId,
                            userName: user.userName,
                            gender: user.gender,
                            email: user.email,
                            phoneNumber: user.phoneNumber,
                            password: user.password,
                            createdDate: user.createdDate,
                            profileUrl: "https://nrriukflpxyoyrsoxikn.supabase.co/storage/v1/object/public/ChatAppStorage/\(folderPath)"
                        )
                        
                        FireBaseDataStore.shared.setUserData(for: user.userId ?? "", userDict: userDict) {
                            Indicator.hide()  // ✅ Hide loading indicator on success
                            profileImage = nil
                            profileUrl = "https://nrriukflpxyoyrsoxikn.supabase.co/storage/v1/object/public/ChatAppStorage/\(folderPath)"
                            
                            UserDefaults.standard.loginUser = UserModel(dictionary: userDict)
                            Alert.show(message : "your Profile Picture Has been uploaded Successfully.")
                            
                        }
                    }
                }
            }
                
            
        }
        .onAppear {
            Indicator.show()
            FireBaseDataStore.shared.getUserData(for: UserDefaults.standard.loginUser?.userId ?? ""){userModel in
                Indicator.hide()
                if userModel != nil {
                    self.txtGender = userModel?.gender ?? ""
                    self.txtPassword = userModel?.password ?? ""
                    self.txtPhoneNumber = userModel?.phoneNumber ?? ""
                    self.txtUsername = userModel?.userName ?? ""
                    self.profileUrl = userModel?.profileUrl ?? ""
                }
                
                
                
            }
        }
        .confirmationDialog("Select Option", isPresented: $isDialogOpen, titleVisibility: .visible) {
            if profileUrl.isEmpty {
                Button("PhotoLibrary") {
                    isImagePickerOpen = true
                }
            }
            else {
                Button("Delete Photo") {
                    Indicator.show()
                    Task {
                        let isdeleted =  await SBStorageManager.shared.DeleteImage(folderName: .profileImages)
                        if isdeleted {
                            guard let user = UserDefaults.standard.loginUser else {return}
                            let userDict: [String: Any] = UserModel.getUserInput(
                                userId: user.userId,
                                userName: user.userName,
                                gender: user.gender,
                                email: user.email,
                                phoneNumber: user.phoneNumber,
                                password: user.password,
                                createdDate: user.createdDate,
                                profileUrl: ""
                            )
                            
                            FireBaseDataStore.shared.setUserData(for: user.userId ?? "", userDict: userDict) {
                                Indicator.hide()  // ✅ Hide loading indicator on success
                                UserDefaults.standard.loginUser = UserModel(dictionary: userDict)
                                profileUrl = ""
                                Alert.show(message : "your Profile Picture Has been Deleted Successfully.")
                                
                            }
                        }
                        else {
                            Indicator.hide()
                            Alert.show(message : "Something went wrong.")
                        }
                        
                    }
                   
                }
            }

        }
    }
}

#Preview {
    SettingsView()
}


