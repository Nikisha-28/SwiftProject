//
//
// DashBoardView.swift
// ChatApp
//
// Created by Shubh Magdani on 30/01/25
// Copyright © 2025 Differenz System Pvt. Ltd. All rights reserved.
//


import SwiftUI
import SDWebImageSwiftUI
struct DashBoardView : View {
    
    ///`Declarations`
    @Binding var chatList : [ChatListModel]
    @Binding var isChatDetailOpen : Bool
    @Binding var selectedRoomId : String
    @Binding var selectedChatList : ChatListModel
    @State var isEmptyView = false
    
    var body: some View {
        VStack(spacing: 5) {
//            SearchBarView(searchText: viewModel.searchText)
            theList()
            
           

        }
        .padding(.horizontal,15)
//        .navigationBarBackButtonHidden(true)
        

    }
}

#Preview {
    DashBoardView(chatList:.constant( []), isChatDetailOpen: .constant(false) , selectedRoomId: .constant(""), selectedChatList: .constant(ChatListModel()) )
}

extension DashBoardView {
    
    func theList() -> some View {
        VStack {
            if chatList.isEmpty {
                NoDataFound()
            }
            else {
            ScrollView(showsIndicators: false) {
                LazyVStack(spacing: 10) {
                    ForEach(chatList, id: \.id) { chat in
                        VStack {
                            HStack(alignment: .top) {
                                // Profile Image (If needed, replace with actual user image)
                                
                                WebImage(url: URL(string: chat.profileUrl ?? ""),options: [ .fromLoaderOnly]){ image in
                                    image.resizable()
                                        .frame(width: 50, height: 50)
                                        .clipShape(Circle())
                                        .shadow(radius: 5)
                                } placeholder: {
                                    Image(systemName: "person.circle.fill")
                                        .resizable()
                                        .frame(width: 50, height: 50)
                                        .clipShape(Circle())
                                        .shadow(radius: 5)
                                        .foregroundColor(Color.AppBlack)
                                }
                                .indicator(.activity)
                                
                                
                                
                                
                                VStack(alignment: .leading, spacing: 5) {
                                    HStack {
                                        // Display User Name
                                        CommonText(title: chat.userName ?? "Unknown", fontSize: 18, weight: .semibold)
                                           
                                        
                                        Spacer()
                                        
                                        // Display TimeStamp
                                        CommonText(title: chat.formattedTime, fontSize: 14, weight: .regular)
                                            
                                    }
                                    
                                    HStack {
                                        // Display Last Message
                                        if let senderId = chat.senderId, !senderId.isEmpty {
                                            if senderId == UserDefaults.standard.loginUser?.userId {
                                                CommonText(title: "You: \(chat.lastMessage ?? "")", fontSize: 15)
                                                    .lineLimit(2)
                                                   
                                            } else {
                                                CommonText(title: "\(chat.userName ?? ""): \(chat.lastMessage ?? "")", fontSize: 15)
                                                    .lineLimit(2)
                                                    
                                            }
                                        } else {
                                            CommonText(title: "No messages yet", fontSize: 15)
                                                .lineLimit(2)
                                                
                                        }
                                        
                                        
                                    }
                                }
                            }
                            .padding(.vertical, 10)
                            
                            Divider()
                                .background(Color.AppBlack.opacity(0.3))
                        }
                        .background(Color.AppWhite.opacity(0.01))
                        .onTapGesture{
                            self.selectedRoomId = chat.roomId ?? ""
                            self.selectedChatList = chat
                            isChatDetailOpen = true
                            
                        }
                    }
                }
                
            }
            
            .background(Color.AppWhite)
            .cornerRadius(10)
        }
        }
    }
}
