//
//  ChatDetailsView.swift
//  ChatApp
//
//  Created by differenz48 on 03/02/25.
//

import SwiftUI

struct ChatDetailsView: View {
    @State var chatMessages: [ChatModel] =  [
        ChatModel(
            messageId: "1",
            messageBody: "Welcome to the chat!",
            senderId: "system",
            isDeleted: false,
            createDate: Date().formatted(),
            createDateTimeStamp: Int(Date().timeIntervalSince1970 * 1000),
            deletedUserNames: nil
        ),
        ChatModel(
            messageId: "2",
            messageBody: "Feel free to start messaging.",
            senderId: "system",
            isDeleted: false,
            createDate: Date().formatted(),
            createDateTimeStamp: Int(Date().timeIntervalSince1970 * 1000),
            deletedUserNames: nil
        ),
        ChatModel(
            messageId: "2",
            messageBody: "hello",
            senderId: "system2",
            isDeleted: false,
            createDate: Date().formatted(),
            createDateTimeStamp: Int(Date().timeIntervalSince1970 * 1000),
            deletedUserNames: nil
        )
    ]
    @Binding var Selectedchatlist : ChatListModel
    @Binding var selectedRoomId : String
    @State var txtMessage: String = ""
    @State var scrollPosition = ScrollPosition()
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        
            
        VStack {
            if chatMessages.isEmpty {
                Spacer()
                NoDataFound()
                Spacer()
            }
            else {
                ScrollView(showsIndicators : false) {
                    VStack {
                        ForEach(chatMessages) { message in
                            HStack {
                                VStack() {
                                    Text(message.messageBody ?? "")
                                    
                                    
                                }
                                .foregroundColor(.white)
                                .padding()
                                .background( message.senderId ?? "" == UserDefaults.standard.loginUser?.userId ?? "" ? Color.AppBrownColor : Color.AppBrownColor.opacity(0.7))
                                .cornerRadius(15, corners: message.senderId ?? "" == UserDefaults.standard.loginUser?.userId ?? "" ?  [.bottomLeft,.topLeft,.topRight] : [.bottomRight,.topLeft,.topRight])
                                .frame(maxWidth: .infinity, alignment: message.senderId ?? "" == UserDefaults.standard.loginUser?.userId ?? "" ? .trailing : .leading)
                                
                            }
                        }
                    }
                }
                .scrollPosition($scrollPosition)
            }
            
            
            
            
            sendMessageView()
        }
        .padding(.horizontal)
        
        .navigationBarBackButtonHidden(true)
        .navigationTitle(Selectedchatlist.userName ?? "")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar{
            ToolbarItem(placement: .topBarLeading){
                Button(action:{
                    dismiss()
                }){
                    HStack {
                        Image(systemName: "chevron.left")
                        Text("Back")
                    }
                    .foregroundStyle(Color.AppBrownColor)
                    
                }
            }
        }
        .onAppear(){
            
            FireBaseDataStore.shared.getMessages(roomId: selectedRoomId){ chatData in
                self.chatMessages = chatData ?? []
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                withAnimation(){
                    scrollPosition.scrollTo(edge: .bottom)
                }
            }
        }
        
    }
}

#Preview {
    ChatDetailsView( Selectedchatlist: .constant(ChatListModel()), selectedRoomId: .constant(""))
}

extension ChatDetailsView {
    
    func sendMessageView() -> some View {
        VStack {
            MultiLineTextField(txtMessage: $txtMessage) {
                // Button action here
                if txtMessage.isEmpty {
                    Alert.show(message : "please type Something....")
                }
                else {
                    let message = ChatModel.ChatData(
                        messageId: UUID().uuidString,
                        messageBody: txtMessage,
                        senderId: UserDefaults.standard.loginUser?.userId ?? "",
                        isDeleted: false,
                        createDate: Date().formatted(),
                        createDateTimeStamp: Int((Date().timeIntervalSince1970) * 1000 ),
                        deletedUserNames: ""
                    )
                    FireBaseDataStore.shared.addMessageToRoom(roomId: Selectedchatlist.roomId ?? "", message: message){
                        
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2){
                        withAnimation(){
                            scrollPosition.scrollTo(edge: .bottom)
                        }
                    }
                   
                    txtMessage = ""
                }
            }
        }
        .padding(.top,15)
//        .background(Color.gray)
//        .padding(20)
    }
}

