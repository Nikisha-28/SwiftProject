//
//  TabbarView.swift
//  ChatApp
//
//  Created by differenz48 on 31/01/25.
//

import SwiftUI

struct TabbarView: View {
    @ObservedObject var viewModel : ChatAppModel = .shared
    ///`Declarations`
    @State var selectedTab: Int = 0
    @State var isNewRoom: Bool = false
    @State var email : String = ""
    @State var isChatDetailOpen : Bool = false
    @State var selectedRoomId : String = ""
    @State var selectedChatList : ChatListModel = ChatListModel()
    var body: some View {
        VStack {
            TabView(selection: $selectedTab) {
                DashBoardView(chatList: $viewModel.chatList,isChatDetailOpen: $isChatDetailOpen,selectedRoomId: $selectedRoomId,selectedChatList: $selectedChatList)
                    .tabItem {
                        Image(systemName: "message")
                            .resizable()
                            .renderingMode(.template)
                            .foregroundColor(selectedTab == 1 ? Color.AppBrownColor : Color.black)
                            .frame(width: 20, height: 20)
                        CommonText(title: "Chats", fontSize: 12,foregroundColor: selectedTab == 0 ? Color.AppBrownColor : Color.black)
                    }
                    .tag(0)
                
                SettingsView()
                    .tabItem {
                        Image(systemName: "person.circle")
                            .resizable()
                            .renderingMode(.template)
                            .foregroundColor(selectedTab == 1 ? Color.AppBrownColor : Color.black)
                            .frame(width: 20, height: 20)
                        CommonText(title: "Profile", fontSize: 12, foregroundColor: selectedTab == 1 ? Color.AppBrownColor : Color.black)
                    }
                    .clipped()
                    .tag(1)
            }
        }
        .onAppear{
//            FireBaseDataStore.shared.getChatListData(loginUserId: UserDefaults.standard.loginUser?.userId ?? ""){chatList in
//                viewModel.chatList = chatList
//            }
            FireBaseAuthService.shared.isUserLoggedIn{ isLoggedIn , error in
                if isLoggedIn {
                    if viewModel.chatList.isEmpty {
                        Indicator.show()
                        FireBaseDataStore.shared.getChatListData(loginUserId: UserDefaults.standard.loginUser?.userId ?? ""){chatList in
                            viewModel.chatList = chatList
                            print(dump(viewModel.chatList))
                        }
                    }
                }
                else {
                    DispatchQueue.main.async{
                        viewModel.isDashBoardShowing = false
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                        Alert.show(title: "Error", message: "\(error!)")
                    }
                    
                }
            }
            
            setTabItemColor()
        }
        .sheet(isPresented: $isNewRoom){
            NavigationStack {
                ScrollView {
                    VStack {
                        TextFieldView(placeholder: "Email", text: $email)
                        Spacer(minLength: 15)
                        ButtonView(title: "Verify", action: {
                            isNewRoom = false
                            
                            if UserDefaults.standard.loginUser?.email == email {
                                
                                Alert.show(message: "Can't put this email")
                                email = ""
                            }
                            else {
                                Indicator.show()
                                FireBaseDataStore.shared.getUserIDByEmail(email: email){ userId in
                                    if let userId = userId {
                                       
                                        FireBaseDataStore.shared.isRoomIDUnique(user1ID: UserDefaults.standard.loginUser?.userId ?? "", user2ID: userId){ isUnique , roomId in
                                            if isUnique {
                                                let roomId = "\( UserDefaults.standard.loginUser?.userId ?? "")_\(userId)"
                                                FireBaseDataStore.shared.setRoomIDs(roomId: roomId){
                                                    
                                                        if let chat = viewModel.chatList.first(where: { $0.roomId ?? "" == roomId }) {
                                                            selectedChatList = chat
                                                        }
                                                        selectedRoomId = roomId
                                                        email = ""
                                                        isChatDetailOpen = true
                                                    
                                                }
                                                
                                            }
                                            else {
                                                if let chatRoomId = roomId {
                                                    if let chat = viewModel.chatList.first(where: { $0.roomId ?? "" == chatRoomId }) {
                                                        selectedChatList = chat
                                                    }
                                                    selectedRoomId = chatRoomId
                                                    email = ""
                                                    isChatDetailOpen = true
                                                }
                                            }
                                        }
                                    }
                                    else {
                                        Alert.show(message: "This email is not registered yet")
                                        email = ""
                                    }
                                }
                                
                                
                            }
                        },background: !email.isValidEmail() ? Color.AppBrownColor.opacity(0.5) : Color.AppBrownColor)
                        .disabled(!email.isValidEmail())
                            }
                    .padding()
                }
                .navigationTitle(Text("New Conversation"))
                .toolbar{
                    ToolbarItem(placement: .topBarTrailing) {
                        Button {
                            email = ""
                            isNewRoom = false
                        } label: {
                            Image(systemName: "xmark.circle.fill")
                                .resizable()
                                .frame(width: 30,height: 30)
                                .foregroundStyle(Color.AppBrownColor)
                        }
                    }
                }
            }
            .presentationDetents([.fraction(0.35)])
        }
        .navigationTitle(Text(selectedTab == 1 ? "Profile" : "Chats"))
        .navigationBarBackButtonHidden(true)
        .toolbar{
            if selectedTab == 0 {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        isNewRoom = true
                    } label: {
                        Image(systemName: "plus.circle.fill")
                            .resizable()
                            .frame(width: 30,height: 30)
                            .tint(Color.AppBrownColor)
                    }
                }
            }
        }
        .navigationDestination(isPresented: $isChatDetailOpen){
//            ChatDetailsView(chatMessages: $chatMessages, isChatDetailOpen = $isChatDetailOpen , Selectedchatlist: $selectedChatList)
            ChatDetailsView( Selectedchatlist: $selectedChatList,selectedRoomId : $selectedRoomId)
        }
    }
    
    
}

#Preview {
    TabbarView()
}

extension TabbarView {
    
    func setTabItemColor() {
        let appearance = UITabBarAppearance()
        
        appearance.stackedLayoutAppearance.selected.iconColor = UIColor(named: "AppBrownColor")
        appearance.stackedLayoutAppearance.selected.titleTextAttributes = [.foregroundColor: UIColor(named: "AppBrownColor") ?? .red]
        
        appearance.stackedLayoutAppearance.normal.iconColor = UIColor.gray
        appearance.stackedLayoutAppearance.normal.titleTextAttributes = [.foregroundColor: UIColor.gray]
        
        UITabBar.appearance().standardAppearance = appearance
        UITabBar.appearance().scrollEdgeAppearance = appearance
    }
}
