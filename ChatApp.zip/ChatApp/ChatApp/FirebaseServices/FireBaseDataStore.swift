//
//
// FireBaseDataStore.swift
// ChatApp
//
// Created by Shubh Magdani on 29/01/25
// Copyright © 2025 Differenz System Pvt. Ltd. All rights reserved.
//

import Foundation
import SwiftUI
import FirebaseFirestore

enum FBDataStoreCollection : String {
    case users = "Users"
    case chats = "Chats"
}

class FireBaseDataStore {
    static let shared : FireBaseDataStore = FireBaseDataStore()
    private init () {}
    let db : Firestore = Firestore.firestore()
}

extension FireBaseDataStore {
    func setUserData (for userID : String, userDict : [String : Any] , completion : @escaping (()->())) {
        self.db.getCollection(.users).document(userID).setData(userDict) { error in
            if let error = error as? NSError {
                
                print("error getting for  set the user data with documentId: \(userID), error: \(error.localizedDescription)")
            } else {
                completion()
            }
        }
    }
}

extension FireBaseDataStore {
    func getUserData(for userID: String , completion :@escaping ((UserModel?) -> ())){
        self.db.getCollection(.users).document(userID).getDocument{ FBData , error in
            if let error = error as? NSError {
                print("error getting data from UserDocument with id \(userID) , error \(error.localizedDescription) ")
                Indicator.hide()
                Alert.show(message: "\(error.localizedDescription)")
                return
            }
            else {
                guard let document = FBData else {return}
                do {
                    let messageModel = try document.data(as: UserModel.self)
                    Indicator.hide()
                    completion(messageModel)
                }
                catch let error {
                    print("error getting data from UserDocument with id \(userID) , error \(error.localizedDescription) ")
                    Indicator.hide()
                    Alert.show(message: "\(error.localizedDescription)")
                    return
                }
            }
            
        }
    }
}

extension FireBaseDataStore {
    func isUserIDUnique(userID: String, completion: @escaping (Bool) -> Void) {
        self.db.getCollection(.users).document(userID).getDocument { document, error in
            if let error = error {
                print("Error checking user ID uniqueness: \(error.localizedDescription)")
                completion(false) // Assume not unique if there's an error
                return
            }
            
            if let document = document, document.exists {
                completion(false) // User ID already exists
            } else {
                completion(true) // User ID is unique
            }
        }
    }
}

extension FireBaseDataStore {
    func setChatData(roomId : String ,chatData : [String : Any] , completion:@escaping (() -> ())){
        self.db.getCollection(.chats).document(roomId).setData(chatData) { error in
            if let error = error {
                print("error for seting the chatData with roomId \(roomId) , error : \(error.localizedDescription)")
            }
            else {
                completion()
            }
        }
    }
}

extension FireBaseDataStore {
    func setRoomIDs(roomId : String ,completion:@escaping (()->())){
       self.db.getCollection(.chats).document(roomId).setData(["messages": []]) { error in
            if let error = error {
                Indicator.hide()
                Alert.show(message : "\(error.localizedDescription)")
                print("error in generating the room id :   \(error.localizedDescription)")
            }
            else {
                Indicator.hide()
                completion()
            }
        }
    }
}

extension FireBaseDataStore {
    func isRoomIDUnique(user1ID: String, user2ID: String, completion: @escaping (Bool, String?) -> ()) {
        let roomId1 = "\(user1ID)_\(user2ID)"
        let roomId2 = "\(user2ID)_\(user1ID)" // Reverse order

        let chatRef1 = self.db.getCollection(.chats).document(roomId1)
        let chatRef2 = self.db.getCollection(.chats).document(roomId2)

        chatRef1.getDocument { (document1, error1) in
            if let error1 = error1 {
                Indicator.hide()
                print("Error checking room ID \(roomId1): \(error1.localizedDescription)")
                completion(false, nil)
                return
            }

            if let document1 = document1, document1.exists {
                Indicator.hide()
                print("Room ID \(roomId1) already exists")
                completion(false, roomId1) // Return existing room ID
                return
            }

            chatRef2.getDocument { (document2, error2) in
                if let error2 = error2 {
                    Indicator.hide()
                    print("Error checking room ID \(roomId2): \(error2.localizedDescription)")
                    completion(false, nil)
                    return
                }

                if let document2 = document2, document2.exists {
                    Indicator.hide()
                    print("Room ID \(roomId2) already exists")
                    completion(false, roomId2) // Return existing room ID
                } else {
                    Indicator.hide()
                    print("Room ID is unique")
                    completion(true, nil) // Room is unique, no existing ID
                }
            }
        }
    }
}


extension FireBaseDataStore {
    func addMessageToRoom(roomId: String, message: [String: Any], completion: @escaping (() -> ())) {
        let chatRef = self.db.getCollection(.chats).document(roomId)

        chatRef.updateData([
            "messages": FieldValue.arrayUnion([message]) // Append message without overwriting
        ]) { error in
            if let error = error {
                print("Error adding message to room \(roomId): \(error.localizedDescription)")
            } else {
                completion()
            }
        }
    }
}

extension FireBaseDataStore {
    func getMessages(roomId: String , completion : @escaping (([ChatModel]?) -> ())) {
        self.db.getCollection(.chats).document(roomId).addSnapshotListener{ snapshot , error in
            if let error = error {
                            print("Error fetching documents: \(error.localizedDescription)")
                            completion(nil) // Return nil if error occurs
                            Indicator.hide()
                            return
                        }
                        
                        // Ensure that the document exists
                        guard let document = snapshot, document.exists else {
                            print("No document found for roomID: \(roomId)")
                            Indicator.hide()
                            completion(nil) // Return nil if document is missing
                            return
                        }

                        // Extract the "messages" field (which should be an array)
                        guard let messagesArray = document.data()?["messages"] as? [[String: Any]] else {
                            print("No 'messages' field found in the document")
                            Indicator.hide()
                            completion(nil) // Return nil if messages field is missing
                            return
                        }
            
            let chatData: [ChatModel] = messagesArray.compactMap { messageData in
                           // Decode each message into a ChatModel
                           if let messageId = messageData["messageId"] as? String,
                              let messageBody = messageData["messageBody"] as? String,
                              let senderId = messageData["senderId"] as? String,
                              let isDeleted = messageData["isDeleted"] as? Bool,
                              let createDate = messageData["createDate"] as? String,
                              let createDateTimeStamp = messageData["createDateTimeStamp"] as? Int {
                               return ChatModel(
                                   messageId: messageId,
                                   messageBody: messageBody,
                                   senderId: senderId,
                                   isDeleted: isDeleted,
                                   createDate: createDate,
                                   createDateTimeStamp: createDateTimeStamp,
                                   deletedUserNames: messageData["deletedUserNames"] as? String
                               )
                           }
                           return nil // Return nil if data is incomplete or invalid
                       }
            Indicator.hide()
            completion(chatData)
        }
    }
}


extension FireBaseDataStore {
    func getUserIDByEmail(email: String, completion: @escaping (String?) -> Void) {
        self.db.getCollection(.users)
            .whereField("email", isEqualTo: email)
            .getDocuments { snapshot, error in
                if let error = error {
                    Indicator.hide()
                    Alert.show(message : "\(error.localizedDescription)")
                    completion(nil) // Return nil if there's an error
                    return
                }

                if let document = snapshot?.documents.first {
                    let userId = document.documentID
                    Indicator.hide()
                    completion(userId) // Return user ID if found
                }
                else {
                    Indicator.hide()
                    completion(nil) // No email found
                }
            }
    }
}


extension FireBaseDataStore {
    func getChatListData(loginUserId: String, completion: @escaping ([ChatListModel]) -> ()) {
        Indicator.show()  // Show indicator when fetching starts

        self.db.getCollection(.chats).addSnapshotListener { (snapshot, error) in
            if let error = error {
                print("Error observing chat rooms: \(error.localizedDescription)")
                Indicator.hide()  // Hide indicator in case of error
                Alert.show(message: "Error")
                completion([])
                return
            }

            guard let documents = snapshot?.documents else {
                print("No documents found")
                Indicator.hide()  // Hide indicator if no documents are found
                Alert.show(message: "No documents found")
                completion([])
                return
            }

            var chatList: [ChatListModel] = []
            let dispatchGroup = DispatchGroup()
            let chatListQueue = DispatchQueue(label: "chatlist") // Protects shared resource

            for document in documents {
                let roomId = document.documentID
                let userIds = roomId.split(separator: "_").map { String($0) }

                // Find the other user's ID
                guard userIds.contains(loginUserId), let otherUserID = userIds.first(where: { $0 != loginUserId }) else {
                    continue
                }

                dispatchGroup.enter()

                // Fetch the "messages" array and extract the last message
                if let messages = document.data()["messages"] as? [[String: Any]], let lastMessageData = messages.last {
                    let senderId = lastMessageData["senderId"] as? String ?? ""
                    let lastMessage = lastMessageData["messageBody"] as? String ?? "No messages yet"
                    let timestamp = lastMessageData["createDateTimeStamp"] as? Int ?? 0

                    // Listen for real-time user name changes
                    self.db.getCollection(.users).document(otherUserID).addSnapshotListener { (userSnapshot, userError) in
                        defer { dispatchGroup.leave() } // Ensure it's called to prevent deadlocks

                        if let userError = userError {
                            print("Error fetching user details: \(userError.localizedDescription)")
                        }

                        let otherUserName = userSnapshot?.data()?["userName"] as? String ?? "Unknown User"
                        let otherUserprofileUrl = userSnapshot?.data()?["profileUrl"] as? String ?? ""

                        let chatItem = ChatListModel(
                            userName: otherUserName,
                            roomId: roomId,
                            lastMessage: lastMessage,
                            timeStamp: timestamp,
                            senderId: senderId,
                            profileUrl: otherUserprofileUrl
                        )

                        // Synchronize chatList update
                        chatListQueue.sync {
                            chatList.append(chatItem)
                        }
                    }
                } else {
                    // For rooms with no messages (empty messages array), set default values
                    let lastMessage = "No messages yet"
                    let timestamp = 0

                    // Listen for real-time user name changes for rooms without messages
                    self.db.getCollection(.users).document(otherUserID).addSnapshotListener { (userSnapshot, userError) in
                        defer { dispatchGroup.leave() }

                        if let userError = userError {
                            print("Error fetching user details: \(userError.localizedDescription)")
                        }

                        let otherUserName = userSnapshot?.data()?["userName"] as? String ?? "Unknown User"

                        let chatItem = ChatListModel(
                            userName: otherUserName,
                            roomId: roomId,
                            lastMessage: lastMessage,
                            timeStamp: timestamp
                        )

                        // Synchronize chatList update
                        chatListQueue.sync {
                            chatList.append(chatItem)
                        }
                    }
                }
            }

            dispatchGroup.notify(queue: .main) {
                Indicator.hide()  // Hide indicator once all async tasks are completed
                completion(chatList.sorted { ($0.timeStamp ?? 0) > ($1.timeStamp ?? 0) }) // Sort safely
            }
        }
    }
}


extension Firestore {
    func getCollection(_ collectionPath: FBDataStoreCollection) -> CollectionReference {
        self.collection(collectionPath.rawValue)
    }
}




