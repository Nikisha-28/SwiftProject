//
//
// FireBaseAuthSerivce.swift
// ChatApp
//
// Created by Shubh Magdani on 29/01/25
// Copyright © 2025 Differenz System Pvt. Ltd. All rights reserved.
//

import Foundation
import FirebaseAuth
import SwiftUI
class FireBaseAuthService {
    static let shared : FireBaseAuthService = FireBaseAuthService()
    private var fireBaseUser : User?
    private init() {}
}

extension FireBaseAuthService {
    func registerUser (name : String , email : String , password : String , gender : String , phoneNumber : String , completion : @escaping (_ userModel : UserModel? ) -> Void) {
        Auth.auth().createUser(withEmail: email, password: password){
            success ,
            error in
            guard error == nil
            else {
                self.handleError(error!)
                Indicator.hide()
                return
            }
            guard let user = success?.user
            else {
                Indicator.hide()
                print("No user data here....")
                return
            }
            
            
            let userDict : [String : Any] = UserModel.getUserInput(
                userId: user.uid,
                userName: name,
                gender: gender,
                email: email,
                phoneNumber: phoneNumber,
                password: password,
                createdDate: Date().formatted()
            )
            
            FireBaseDataStore.shared.setUserData(for: user.uid, userDict: userDict) {
                Indicator.hide()
                UserDefaults.standard.loginUser = UserModel(dictionary: userDict)
                UserDefaults.isLoggedIn = true
                completion(UserModel(dictionary: userDict))
            }
            
            
        }
    }
}

extension FireBaseAuthService {
    func signIn(with email : String , and password : String, completion : @escaping ((UserModel?) -> ())){
        Auth.auth().signIn(withEmail: email, password: password) { result, error in
            guard error == nil
            else {
                Indicator.hide()
                self.handleError(error!)
                return
            }
            guard let user = result?.user
            else {
                Indicator.hide()
                return
            }
            
            FireBaseDataStore.shared.getUserData(for: user.uid){userModel in
                Indicator.hide()
                UserDefaults.standard.loginUser = userModel
                UserDefaults.isLoggedIn = true
                completion(userModel)
            }
        }
        
    }
}


extension FireBaseAuthService {
    func logoutUser(completion: (() -> ())) {
        do {
            try Auth.auth().signOut()
            
            UserDefaults.standard.loginUser = nil
            UserDefaults.isLoggedIn = false
            completion()
        } catch {
            Alert.show(message: error.localizedDescription)
        }
    }
}


extension FireBaseAuthService {
    func handleError(_ error: Error) {
        print(error.localizedDescription)
        Alert.show(message: error.localizedDescription)
    }
}


extension FireBaseAuthService {
    func isUserLoggedIn(completion: @escaping (Bool, String?) -> ()) {
        // Check if the user's email matches the saved email in UserDefaults
        if Auth.auth().currentUser?.email == UserDefaults.standard.loginUser?.email {
            if let user = Auth.auth().currentUser {
                refreshUserToken(user) {
                    // User is valid and authenticated
                    UserDefaults.isLoggedIn = true
                    Indicator.hide()
                    completion(true, nil) // No error, user is logged in
                } failure: { error in
                    UserDefaults.standard.loginUser = nil
                    UserDefaults.isLoggedIn = false
                    Indicator.hide()
                    completion(false, error) // Pass error as string
                }
            }
        } else {
            // Handle mismatch or no user logged in
            
            Indicator.hide()
            completion(false, "Authentication mismatch or no user found. Please log in again.") // Pass failure message
        }
    }

    func refreshUserToken(_ user: User, completion: @escaping () -> (), failure: @escaping (String) -> ()) {
        user.getIDTokenForcingRefresh(true) { (token, error) in
            if let error = error {
                print("Token refresh failed: \(error.localizedDescription)")
                failure("\(error.localizedDescription)") // Pass the error as a string
            } else {
                print("Token refreshed successfully.")
                completion() // No error
            }
        }
    }
}
