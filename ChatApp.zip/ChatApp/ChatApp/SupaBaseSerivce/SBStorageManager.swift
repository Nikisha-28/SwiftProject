//
//
// SBStorageManager.swift
// ChatApp
//
// Created by Shubh Magdani on 28/02/25
// Copyright © 2025 Differenz System Pvt. Ltd. All rights reserved.
//
import Foundation
import Supabase
import UIKit
import SwiftUI


enum SBStorageFolders : String {
    case profileImages = "ProfileImages"
    case chatsImages = "ChatImages"
}
enum SBStorageOperations : String {
    case upload
    case update
}

class SBStorageManager {
    static let shared : SBStorageManager = SBStorageManager()
    let supabaseClient = SupabaseClient(
        supabaseURL: URL(string: "https://nrriukflpxyoyrsoxikn.supabase.co")!,
        supabaseKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5ycml1a2ZscHh5b3lyc294aWtuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDE2MDQ2MTQsImV4cCI6MjA1NzE4MDYxNH0.g7PUuk-3imVP4BcRGn2Iom3l6mCrrjNkJHLoHT_a_so"
    )
    
}

extension SBStorageManager {
    func uploadImage(_ image: UIImage, folderName: SBStorageFolders  , completion : @escaping ((String?) -> ())) async  {
        guard let imageData = image.jpegData(compressionQuality: 0.8) else {
            Indicator.hide()
            Alert.show(message: "Failed to convert image to JPEG.")
            completion(nil)
            return
        }
        
        guard let user = UserDefaults.standard.loginUser else {
            Indicator.hide()
            Alert.show(message: "User not found.")
            completion(nil)
            return
        }
        
        let filePath = "\(folderName)/\(user.userId ?? "")/default.jpeg"
        
        do{
            try await supabaseClient.storage
                .from("ChatAppStorage")
                .upload(
                                filePath,
                                data: imageData,
                                options: FileOptions(contentType: "image/jpeg")
                            )
            completion(filePath)
        }
        catch {
            Indicator.hide()  // ✅ Hide loading indicator on error
            Alert.show(message: "Upload failed: \(error.localizedDescription)")
            print("Upload error: \(error)")
            completion(nil)
        }
    }
}

extension SBStorageManager {
    func DeleteImage(folderName: SBStorageFolders) async -> Bool {
        guard let user = UserDefaults.standard.loginUser else {
            Indicator.hide()
            Alert.show(message: "User not found.")
            return false
        }

        let filePath = "\(folderName)/\(user.userId ?? "")/default.jpeg"

        do {
            try await supabaseClient.storage.from("ChatAppStorage").remove(paths: [filePath])
            print("Previous image deleted successfully")
            return true
        } catch {
            Indicator.hide()
            Alert.show(message: "Image deletion failed: \(error.localizedDescription)")
            print("Delete error: \(error)")
            return false
        }
    }
}
