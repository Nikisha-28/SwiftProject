//
//
// CommonExtensions.swift
// FireBaseIntegration
//
// Created by Shubh Magdani on 31/12/24
// Copyright © 2024 Differenz System Pvt. Ltd. All rights reserved.
//

import Foundation
import SwiftUI
import UIKit

struct TextFieldView:View {
    var placeholder :String
    var color : Color = .AppWhite
    @Binding var text : String
    @FocusState var focus
    var body: some View {
        
        
        ZStack (alignment: .leading){
            TextField("", text: $text)
                .padding(.leading)
                .frame(height: 50)
                .focused($focus)
                .background(focus ? Color.AppBrownColor : Color.AppBrownColor ,in: RoundedRectangle(cornerRadius: 20).stroke(lineWidth: 2))
                .autocapitalization(.none)
                .disableAutocorrection(true)
                
            Text(placeholder)
                .padding(.horizontal,5)
                .background(color.opacity(focus || !text.isEmpty ? 1 : 0))
                .foregroundStyle(focus ? Color.AppBrownColor : Color.AppBlack)
                .padding(.leading)
                .offset(x : focus || !text.isEmpty ? 5 : 0 ,y : focus || !text.isEmpty ? -25 : 0)
                .scaleEffect(focus ? 1.1 : 1)
                .onTapGesture{
                    focus.toggle()
                }
                
            
        }
        .animation(.linear(duration: 0.2), value: focus)
            
    }
}
struct SecureFieldView:View {
    @State var isSecure = true
    var placeholder :String
    var color : Color = .AppWhite
    @Binding var text : String
    @FocusState var focus
    var body: some View {
        ZStack (alignment: .leading){
            HStack {
                if isSecure {
                    SecureField("", text: $text)
                        .focused($focus)
                        .textContentType(.newPassword)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                }
                else {
                    TextField("", text: $text)
                        .focused($focus)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                }
                
                Button(action: {
                    isSecure.toggle()
                    
                }, label: {
                    isSecure ? Image(systemName: "eye.slash.fill").font(.system(size: 20)).foregroundStyle(Color.gray) : Image(systemName: "eye.fill").font(.system(size: 20)).foregroundStyle(Color.AppBlack)
                }
                    
                )
                .opacity(text.isEmpty ? 0 : 1)
                .padding(.trailing)
                
            }
            
                .padding(.leading)
                .frame(height: 50)
                
                .background(focus ? Color.AppBrownColor : Color.AppBrownColor ,in: RoundedRectangle(cornerRadius: 20).stroke(lineWidth: 2))
                
            Text(placeholder)
                .padding(.horizontal,5)
                .background(color.opacity(focus || !text.isEmpty ? 1 : 0))
                .foregroundStyle(focus ? Color.AppBrownColor : Color.AppBlack)
                .padding(.leading)
                .offset(x : focus || !text.isEmpty ? 5 : 0   , y : focus || !text.isEmpty ? -25 : 0)
                .scaleEffect(focus   ? 1.1 : 1)
                .onTapGesture{
                    focus = true
                }
                
            
        }
        .animation(.linear(duration: 0.2), value: focus)
    }
}



struct ButtonView:View {
    var title : String
    var action : (() -> ())
    var background : Color = Color.AppBrownColor
    var body: some View {
        Button(action: {action()}) {
            Text(title)
                .foregroundColor(Color.white)
                .padding()
                .frame(maxWidth: .infinity)
                .background(background)
                .cornerRadius(20)
        }
        .buttonStyle(shinkingButton())
    }
}



struct GenderPicker : View {
    var placeholder :String
    @FocusState var focus: Bool
    @Binding var text : String
   
    @State var pickerIsThere = false
    @State  var Gender = ["Male", "Female"]
    var body: some View {
        ZStack (alignment: .leading){
            TextField("", text: $text)
                .padding(.leading)
                .frame(height: 50)
                .background(focus || pickerIsThere ? Color.AppBrownColor : Color.AppBrownColor ,in: RoundedRectangle(cornerRadius:20).stroke(lineWidth: 2))
                .autocapitalization(.none)
                .disabled(true)
                .onTapGesture {
                    pickerIsThere = true
                    focus = true
                    UIApplication.shared.sendAction(#selector(UIApplication.resignFirstResponder), to: nil, from: nil, for: nil);
                }
                
            Text(placeholder)
                .padding(.horizontal,5)
                .background(Color.AppWhite.opacity(pickerIsThere || focus || !text.isEmpty ? 1 : 0))
                .foregroundStyle(pickerIsThere || focus ? Color.AppBrownColor : Color.AppBlack)
                .padding(.leading)
                .offset( x : pickerIsThere || focus || !text.isEmpty ? 5 : 0 , y : pickerIsThere || focus || !text.isEmpty ? -25 : 0)
                .scaleEffect(pickerIsThere || focus ? 1.1 : 1)
                .onTapGesture {
                    pickerIsThere = true
                    focus = true
                    UIApplication.shared.sendAction(#selector(UIApplication.resignFirstResponder), to: nil, from: nil, for: nil);
                }
                
            
        }
        .animation(.linear(duration: 0.2), value: focus || pickerIsThere)
        .focused($focus)
        .sheet(isPresented: $pickerIsThere, content: {
            PickerView1()
                .presentationDetents([.height(250), .fraction(0.50)])
        })
    }
}
extension GenderPicker {
    func PickerView1() -> some View {
        NavigationStack{
            List(Array((Gender).enumerated()),id: \.element){ index, gender in
                Text("\(gender)")
                    .foregroundStyle(Color.AppBlack)
                    .font(.system(size: 20))
                
                    .onTapGesture {
                        focus = true
                        text = gender
                        pickerIsThere = false
                    }
                    .swipeActions(edge: HorizontalEdge.trailing){
                        Button(action:{
                            text = gender
                            pickerIsThere = false
                        }){
                            Image(systemName: "arrow.up.right")
                                .symbolRenderingMode(.palette)
                        }
                        
                        .foregroundStyle(Color.AppWhite)
                    }
                    .contextMenu{
                        Button(action:{
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: {
                                text = gender
                                pickerIsThere = false
                                
                            })
                            
                        }){
                            Text( "Select It . ")
                        }
                    }
                    .listRowBackground(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.AppBrownColor)
                           
                    )
            }
            .listRowSpacing(2)
            .navigationTitle("Gender")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar{
                Button(action:{
                    withAnimation{
                        focus = true
                        pickerIsThere = false
                    }
                    
                }){
                    Image(systemName: "xmark.circle.fill")
                        .resizable()
                        .frame(width: 25, height: 25)
                        .foregroundColor(Color.AppBrownColor)
                }
            }
        }
    }
}

struct BtnWithoutBorder: View {
    let  img : String
    let  label : String
    let  fun : (()->Void)
    let color : Color
    
    var body: some View {
        Button(action: fun){
            HStack {
                Spacer()
                Image(systemName: img)
                Text(label)
                Spacer()
            }
            .frame(maxWidth: .infinity)
            
        }
        .padding()
        .foregroundStyle(Color.white)
        .background(color,in: RoundedRectangle(cornerRadius: 30))
    }
}
struct BtnWithBorder: View {
    let  img : String
    let  label : String
    let  fun : (()->Void)
    let color : Color
    var body: some View {
        Button(action: fun){
            HStack {
                Spacer()
                Image(systemName: img)
                Text(label)
                Spacer()
            }
            
                .frame(maxWidth: .infinity)
        }
        .padding()
        .foregroundStyle(color)
        .background(color,in: RoundedRectangle(cornerRadius: 30).stroke())
    }
}


//struct CommonText: View {
//    var title: String
//    var foregroundColor: Color = Color.black
//    var fontSize: CGFloat = 20
//    
//    var body: some View {
//        Text(title)
//            .foregroundStyle(foregroundColor)
//            .font(.system(size: fontSize))
//            .dynamicTypeSize(.medium)
//    }
//}

struct CommonText: View {
    var title: String
    var fontSize: CGFloat = 20
    var weight: Font.Weight = .regular
    var foregroundColor: Color = Color.AppBlack
    
    var body: some View {
        Text(title)
            .font(.system(size: fontSize, weight: weight))
            .foregroundColor(foregroundColor)
    }
}



enum DividerOrientation {
    case horizontal
    case vertical
}

struct CustomDivider: View {
    var color: Color = .gray
    var thickness: CGFloat = 1
    var direction: DividerOrientation = .horizontal

    var body: some View {
        Group {
            if direction == .horizontal {
                Rectangle()
                    .fill(color)
                    .frame(height: thickness)
                    .edgesIgnoringSafeArea(.horizontal)
            } else {
                Rectangle()
                    .fill(color)
                    .frame(width: thickness)
                    .edgesIgnoringSafeArea(.vertical)
            }
        }
    }
}



struct CircularProgressView: View {
    // 1
    var progress: Double
    var color : Color = Color.green
    var lineWidth : CGFloat = 10
    
    var body: some View {
        ZStack {
            Circle()
                .stroke(
                    color.opacity(0.5),
                    lineWidth: lineWidth
                )
            Circle()
                // 2
                .trim(from: 0, to: progress)
                .stroke(
                    color,
                    style: StrokeStyle(
                        lineWidth: lineWidth,
                        lineCap: .round
                    )
                )
                .rotationEffect(.degrees(-90))
            Text("\(String(format : "%.1f" , (progress * 100)))%")
                           .foregroundColor(color)
                           .padding(20)
        }
    }
}

struct shinkingButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.9 : 1)
           
    }
}

struct newPreView : View {
    @State var isSelected = false
    var body: some View {
        if isSelected {
            Button(action: {
                withAnimation(){
                    isSelected.toggle()
                }
                
            }){
                HStack {
                    Spacer()
                    Image(systemName: "circle")
                    Text("Button")
                    Spacer()
                }
                
                    .frame(maxWidth: .infinity)
            }
            .padding()
            .buttonStyle(shinkingButton())
            .foregroundStyle(Color.white)
            .background(.white,in: RoundedRectangle(cornerRadius: 30).stroke())
        }
        else {
            Button(action: {
                withAnimation(){
                    isSelected.toggle()
                }
                
            }){
                HStack {
                    Spacer()
                    Image(systemName: "circle")
                    Text("Button")
                    Spacer()
                }
                .frame(maxWidth: .infinity)
                
            }
            .padding()
            .foregroundStyle(Color.black)
            
            .background(.white,in: RoundedRectangle(cornerRadius: 30))
        }
       
       
    }
}



extension UIApplication {
    /// `returns keyWindows from UIWindowScenes`
    static var keyWindow: UIWindow? {
        return self.shared.connectedScenes
            .filter({ $0.activationState == .foregroundActive })
            .first(where: { $0 is UIWindowScene })
            .flatMap({ $0 as? UIWindowScene })?.windows
            .first(where: \.isKeyWindow)
    }
}
struct NavigationUtil {
    
    ///`PopToRootView`
    static func popToRootView() {
        findNavigationController(viewController: UIApplication.keyWindow?.rootViewController)?.popToRootViewController(animated: true)
    }
    
    
    static func findNavigationController(viewController: UIViewController?) -> UINavigationController? {
        
        guard let viewController = viewController else {
            return nil
        }
        
        if let navigationController = viewController as? UINavigationController {
            return navigationController
            
        }
        for childViewController in viewController.children {
            return findNavigationController(viewController: childViewController)
        }
        return nil
    }
}


struct AlertButtonTintColor: ViewModifier {
    @Binding var color: Color
    @State private var previousTintColor: UIColor?

    func body(content: Content) -> some View {
        content
            .onAppear {
                previousTintColor = UIView.appearance(whenContainedInInstancesOf: [UIAlertController.self]).tintColor
                UIView.appearance(whenContainedInInstancesOf: [UIAlertController.self]).tintColor = UIColor(color)
            }
            .onDisappear {
                UIView.appearance(whenContainedInInstancesOf: [UIAlertController.self]).tintColor = previousTintColor
            }
            .onChange(of: color) { _, newValue in
                UIView.appearance(whenContainedInInstancesOf: [UIAlertController.self]).tintColor = UIColor(color)
            }
    }
}

struct preloader:View {
    @State var appear : Bool = false
    var body: some View {
        
    ZStack{
        Circle()
            .trim(from: 0,to: 0.3)
            .stroke(Color.AppBrownColor)
            .frame(width: 70,height: 70)
            . rotationEffect(Angle(degrees: appear ? 360 : 0))
            .animation(.linear(duration: 0.5).repeatForever(autoreverses: false))
        VStack{
            Circle()
                
                .foregroundStyle(
                    .linearGradient(colors: [Color.AppBrownColor,Color.AppBrownColor.opacity(0.5),Color.AppBrownColor.opacity(0.3),Color.AppBrownColor.opacity(0.2)], startPoint: .topLeading, endPoint: .bottomTrailing))
                . rotationEffect(Angle(degrees: appear ? 0 : 360))
                .animation(.linear(duration:0.7).repeatForever(autoreverses: true))
                .frame(width: 50)
                
        }
        
    }
    .onAppear {
            appear = true
        }
    .padding(30)
    }
}






struct Glow : ViewModifier {
    func body (content : Content ) -> some View {
        ZStack {
            content
                .blur(radius: 20)
            content
        }
    }
}




struct CustomPopupView : View {
    var action : (() -> ())
    var color : Color = Color.gray //ChatAppModel.shared.themeColor
    var text = """
• Password Change:  If the password is changed, the user will be automatically logged out.

• Profile Update:   Any changes to the user's profile, such as name or gender, will be immediately reflected. 
"""
    var body: some View {
        ZStack {
            Color.black.opacity(0.9)
                .ignoresSafeArea()
            ZStack (alignment: .bottom){
                VStack{
                    Text("Note")
                        .font(.largeTitle)
                        .fontWidth(.expanded)
                    CustomDivider(color: color , thickness: 2)
                        .padding(.bottom)
                    Text(text)
                        .padding(.bottom,40)
                }
//                .foregroundStyle(color)
                .padding()
                .frame(maxWidth: .infinity)
                .background(color , in: RoundedRectangle(cornerRadius: 15).stroke(lineWidth: 2))
                .padding()
                
               
                    Image(systemName: "xmark.circle")
                        .resizable()
                        .frame(width: 40 , height: 40)
                        .padding(5)
                        .foregroundStyle(color)
                        .background(Color.black ,in: Circle())
                        .offset(y:9)
                        .onTapGesture {
                            action()
                        }
                       
                    
                
                
            }
           
            
        }
       
    }
}








struct commonImageButtonView : View {
    var ImageName :  String = "list.clipboard"
    var color = Color.gray//ChatAppModel.shared.themeColor
    var opacity : Double = 1.0
    var scale : Double = 1.0
    var degress : Double = 0
    var width : CGFloat = 50
    var height : CGFloat = 50
    var text : String = ""
    var neededText : Bool = true
    var tapAction :  (() -> ()) = {}
    var pressing :  (() -> ()) = {}
    var elsepressing :  (() -> ()) = {}
    var perform:  (() -> ()) = {}
    @State var trueText:  Bool = false
    
   
    var body: some View {
        VStack {
            HStack {
                Image(systemName: ImageName)
                    .resizable()
                    .frame(width: width,height: height)
                    .rotationEffect(Angle(degrees: degress))
                    
                if   neededText {
                    Text(text)
                        .padding(.trailing)
                        .minimumScaleFactor(0.5)
                }
                
            }
            .opacity(opacity)
            .scaleEffect(scale)
            .foregroundStyle(color)
            .onTapGesture {
                tapAction()
            }
//            .background( neededText ? color : Color.clear , in : RoundedRectangle(cornerRadius: 30).stroke(lineWidth: 3))
            
            }
            
    }
}



struct NoDataFound : View {
    @State var isAnimate : Double = 0.0
    var body: some View {
        VStack{
            Image(systemName: "exclamationmark.triangle")
                .resizable()
                .frame(width: 100,height: 100)
                .symbolEffect(.bounce, value: isAnimate)
                .onTapGesture {
                    isAnimate = Double.random(in: 0...1)
                }.padding(.bottom,20)
            
            Text("NO DATA FOUND")
                .font(.headline)
                .fontWidth(.expanded)
        }
        .foregroundStyle(Color.AppBlack)
        .onAppear{
            isAnimate = Double.random(in: 0...1)
        }
        
    }
}


//#Preview{
//    NoDataFound()
//}

///`RoundedCorners`
struct RoundedCorner: Shape
{
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners
    func path(in rect: CGRect) -> Path
    {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
        
    }
}

///`CornerRadius`
extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(
            RoundedCorner(
                radius: radius,
                corners: corners
            )
        )
    }
}

struct CommonTextFieldForProfile: View {
    
    @Binding var nameOfField: String
    var placeholderText: String
    
    var body: some View {
        TextField("", text: $nameOfField)
            .autocorrectionDisabled()
            .textInputAutocapitalization(.never)
            .font(.system(size: 15))
            .frame(height: 44)
            .padding(.horizontal,8)
            .markUnderline(color: Color.AppBrownColor)
    }
}

///`markUnderline` Modifier
extension View {
    func markUnderline(color: Color, offset: Double = -2.0, height: Double = 1.0) -> some View {
        self
            .overlay(
                Rectangle()
                    .fill(color)
                    .frame(height: height)
                    .offset(y: offset)
                , alignment: .bottom
            )
    }
}

struct MultiLineTextField: View {
    
    ///`Declarations`
    @Binding var txtMessage: String
    var action : (() -> ())
    
    var body: some View {
        HStack(alignment: .bottom) {
            TextField("", text: $txtMessage
                      ,prompt: Text( "Type a message")
                .foregroundStyle(Color.AppBlack.opacity(0.3))
//                .fontWidth(.expanded)
                      , axis: .vertical)
            .lineLimit(1...3)
            .padding(7)
//            .background(Color.white)
            .background(Color.AppBrownColor , in: RoundedRectangle(cornerRadius: 15).stroke())
            .autocorrectionDisabled()
            .autocapitalization(.none)
            
            Button(action : {action()}){
                Image(systemName: "paperplane")
                    .resizable()
                    .renderingMode(.template)
                    .foregroundColor(.white)
                    .frame(width: 20,height: 20)
                    .padding(7)
                    .background(Color.AppBrownColor , in: RoundedRectangle(cornerRadius: 15))
                    
                    
            }
            .frame(width: 40)
        }
        .padding(.horizontal,10)
        .foregroundStyle(Color.AppBrownColor)
    }
}



/*
 struct TextFieldView:View {
     var placeholder :String
     var color : Color = .white
     @Binding var text : String
     @FocusState var focus
     var body: some View {
         
         
         ZStack (alignment: .leading){
             TextField("", text: $text)
                 .padding(.leading)
                 .frame(height: 50)
                 .focused($focus)
                 .background(focus ? Color.AppBrownColor : Color.AppBrownColor ,in: RoundedRectangle(cornerRadius: 20).stroke(lineWidth: 2))
                 .autocapitalization(.none)
                 .disableAutocorrection(true)
                 
             Text(placeholder)
                 .padding(.horizontal,5)
                 .background(color.opacity(focus || !text.isEmpty ? 1 : 0))
                 .foregroundStyle(focus ? Color.AppBrownColor : Color.gray)
                 .padding(.leading)
                 .offset(x : focus || !text.isEmpty ? 5 : 0 ,y : focus || !text.isEmpty ? -25 : 0)
                 .scaleEffect(focus ? 1.1 : 1)
                 .onTapGesture{
                     focus.toggle()
                 }
                 
             
         }
         .animation(.linear(duration: 0.2), value: focus)
             
     }
 }
 
 */




struct NumberField : View {
  
        @StateObject var isdVM : IsdViewModel = IsdViewModel()
        @Binding var shouldHavePicker : Bool
        @State var pickerIsThere = false
        @State var search : String = ""
        @FocusState var focus
        @Binding var selection : Country
        @Binding var text : String
    var color : Color = .AppWhite
        var body: some View {
            ZStack(alignment:.leading) {
                HStack{
                    if shouldHavePicker {
                        Text ("\(selection.code ?? "")")
                            .foregroundStyle(Color.AppBlack)
                            .onTapGesture {
                                pickerIsThere = true
                            }
                            .foregroundColor(Color.black)
                    }
                    TextField("", text: $text,prompt:Text("00000-00000").foregroundStyle(Color.AppWhite.opacity(0.5)))
                        .frame(height: 30)
                        .autocorrectionDisabled(true)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                        .onLongPressGesture(minimumDuration: 0.01) {}
                      
                        
                }
                .onChange(of: text) {
                    text = text.formatPhoneNumber()
                }
                .padding(.leading)
                .frame(height: 50)
                .focused($focus)
                .background(focus ? Color.AppBrownColor : Color.AppBrownColor ,in: RoundedRectangle(cornerRadius: 20).stroke(lineWidth: 2))
                .autocapitalization(.none)
                .disableAutocorrection(true)
                
                Text(!text.isEmpty || focus ? "Phone Number" :  "00000-00000"  )
                    .padding(.horizontal,5)
                    .background(color.opacity(focus || !text.isEmpty ? 1 : 0))
                    .foregroundStyle(focus ? Color.AppBrownColor : Color.AppBlack)
                    .padding(.leading)
                    .offset(x : focus || !text.isEmpty ? 5 : 30 ,y : focus || !text.isEmpty ? -25 : 0)
                    .scaleEffect(focus ? 1.1 : 1)
                    .onTapGesture{
                        focus.toggle()
                    }
            }
            .onAppear {
                UITextField.appearance(whenContainedInInstancesOf: [UISearchBar.self]).textColor = UIColor.appBlack
                UITextField.appearance(whenContainedInInstancesOf: [UISearchBar.self]).attributedPlaceholder = NSAttributedString(
                    string: "Your Country",
                    attributes: [NSAttributedString.Key.foregroundColor: UIColor.appBlack] // Changes placeholder color
                    
                )
                UIBarButtonItem.appearance(whenContainedInInstancesOf: [UISearchBar.self]).tintColor = UIColor.appBlack
            }
            .animation(.easeInOut(duration: 0.2), value: focus)
                
                .sheet(isPresented: $pickerIsThere, content: {
                PickerView()
                    .presentationDetents([.height(.infinity*0.8), .fraction(0.70)])
                    .searchable(text: $search,placement:.navigationBarDrawer(displayMode: .always), prompt: "Your Country")
            })
        }
    }
    /**
     `DealerPickerView`
     */
    extension NumberField {
        func PickerView() -> some View {
            NavigationStack{
                List(Array((search.isEmpty ? self.isdVM.countries : self.isdVM.countries.filter {
                    ($0.name ?? "").localizedStandardContains(search) || ($0.code ?? "").localizedStandardContains(search)
                }).enumerated()), id: \.element) { index, country in
                HStack{
                    Text("\(country.name ?? "")")

                    Spacer()
                    Text("\(country.code ?? "")")
                }
                .background(Color.AppWhite.opacity(0.01))
                .foregroundColor(Color.AppBlack)
                .onTapGesture {
                   
                        
                        selection = country
                        
                        pickerIsThere = false
                        search = ""
                    
                    
                }
                .swipeActions(edge: HorizontalEdge.trailing){
                    Button(action:{
                        selection = country
                        pickerIsThere = false
                        search = ""
                    }){
                        Image(systemName: "arrow.up.right")
                            .symbolRenderingMode(.palette)
                    }
//                    .tint(Color.black.opacity(0.3))
                    .foregroundStyle(Color.AppBrownColor)
                }
                .contextMenu{
                    Button(action:{
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: {
                            selection = country
                            pickerIsThere = false
                            search = ""
                        })
                       
                    }){
                        Text( "Select It . ")
                            
                    }
                }
                }
                .listRowSpacing(2)
                
                .navigationTitle("Countries")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar{
                    Button(action:{
                        withAnimation{
                            pickerIsThere = false
                        }
                       
                    }){
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(Color.AppBlack)
                    }
                }
            }
        }
    

}


struct Country: Codable, Hashable {
    var code, name: String?
}

class IsdViewModel : ObservableObject {
    @Published var countries : [Country]  = []
    init() {
        loadData()
    }
    
    func loadData() {
        guard let url = Bundle.main.url(forResource: "ISDCode", withExtension: "json") else {
            print("ISDCode.json file not found")
            return
        }
        
        do {
            let jsondata = try Data(contentsOf: url)
            let isds = try JSONDecoder().decode([Country].self, from: jsondata)
            self.countries = isds
        } catch {
            print("Error decoding JSON: \(error)")
            
            }
}}



extension String {
    func formatPhoneNumber() -> String {
        let cleanNumber = components(separatedBy: CharacterSet.decimalDigits.inverted).joined()
        
        let mask = "XXXXX-XXXXX"
        
        var result = ""
        var startIndex = cleanNumber.startIndex
        let endIndex = cleanNumber.endIndex
        
        for char in mask where startIndex < endIndex {
            if char == "X" {
                result.append(cleanNumber[startIndex])
                startIndex = cleanNumber.index(after: startIndex)
            } else {
                result.append(char)
            }
        }
        
        return result
    }
}



struct UploadProgressView: View {
    @Binding var progress: CGFloat // Value between 0 and 1

    var body: some View {
        ZStack(alignment: .leading) {
            // Background track
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.gray.opacity(0.2))
                .frame(maxWidth: .infinity)
                .frame(height : 8)

            // Progress bar with gradient
            
                
                RoundedRectangle(cornerRadius: 8)
                    .fill(LinearGradient(
                        gradient: Gradient(colors: [Color.blue, Color.purple]),
                        startPoint: .leading,
                        endPoint: .trailing
                    ))
                    .frame(maxWidth : max(0, UIScreen.main.bounds.width * progress) )
                    .frame(height: 8)
                    .clipped() // Ensures it never visually exceeds bounds
                    .animation(.easeInOut(duration: 0.4), value: progress)
            
            
        }
        .frame(maxWidth: .infinity)
        .frame(height : 8)
    }
}
struct ContentView11 : View {
    var imageString : String = "checkmark.seal.fill"
    var text : String = "checkmark.seal.fill"
    var body: some View {
        
        HStack (spacing: 0){
            Image(systemName: imageString )
                .foregroundStyle(Color.green)
            Text(text)
                .padding()
                    
            }
            .foregroundStyle(Color.black)
            .frame(maxWidth: .infinity)
            .background(.white ,in : RoundedRectangle(cornerRadius: 20))
            
        
       
    }
}

struct ContentView10: View {
    @State private var progress: CGFloat = 0.0
    @State private var isUploaded = false

    var body: some View {
        ZStack {
            Color.black
                .ignoresSafeArea()

            VStack {
                

                if isUploaded {
                    ContentView11()
                        .transition(.opacity) // Smooth slide-in effect
                } else {
                    VStack(spacing: 10) {
                        Text("Syncing...")
                            .foregroundStyle(Color.white)
                            .frame(height: 20) // Fixed height to avoid collapsing

                        UploadProgressView(progress: $progress)
                            .frame(height: 8) // Maintain the height of progress bar
                    }
                    .frame(maxHeight: .infinity, alignment: .center) // Prevents collapsing
                    .transition(.opacity) // Fade out smoothly
                }

               
            }
            .animation(.easeInOut(duration: 0.5), value: isUploaded) // Ensure smooth transitions
        }
       
        .onAppear {
            simulateUpload()
        }
    }

    func simulateUpload() {
        progress = 0
        Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { timer in
            if progress < 0.3 {
                progress = min(progress + 0.04, 1.0)
            } else if progress < 0.5 {
                progress = min(progress + 0.02, 1.0)
            } else if progress < 0.8 {
                progress = min(progress + 0.2, 1.0)
            } else {
                timer.invalidate()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    withAnimation(.easeInOut(duration: 0.5)) {
                        isUploaded = true
                    }
                }
            }
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView10()
    }
}
