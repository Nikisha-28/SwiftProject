//
//
// ImagePicker.swift
// ChatApp
//
// Created by Shubh Magdani on 03/02/25
// Copyright © 2025 Differenz System Pvt. Ltd. All rights reserved.
//


import Foundation
import UIKit
import MobileCoreServices
import SwiftUI

struct CustomImagePickerView: UIViewControllerRepresentable {
    var sourceType: UIImagePickerController.SourceType = .photoLibrary
    @Binding var image: UIImage?
    @Binding var isPresented: Bool
    var completion: (() -> Void)?  // ✅ Completion Handler

    func makeCoordinator() -> ImagePickerViewCoordinator {
        return ImagePickerViewCoordinator(image: self.$image, isPresented: self.$isPresented, completion: completion)
    }

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let pickerController = UIImagePickerController()
        pickerController.sourceType = self.sourceType
        pickerController.mediaTypes = ["public.image"]
        pickerController.delegate = context.coordinator
        pickerController.allowsEditing = false
        return pickerController
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {
        // Nothing to update here
    }
}

// MARK: - Image Picker View Coordinator
class ImagePickerViewCoordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    @Binding var image: UIImage?
    @Binding var isPresented: Bool
    var completion: (() -> Void)?  // ✅ Completion Handler

    init(image: Binding<UIImage?>, isPresented: Binding<Bool>, completion: (() -> Void)?) {
        self._image = image
        self._isPresented = isPresented
        self.completion = completion
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.originalImage] as? UIImage {
            self.image = image
        }
        
        picker.dismiss(animated: true) {
            self.isPresented = false
            self.completion?()  // ✅ Call Completion Here
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true) {
            self.isPresented = false
            self.completion?()  // ✅ Call Completion Here
        }
    }
}
