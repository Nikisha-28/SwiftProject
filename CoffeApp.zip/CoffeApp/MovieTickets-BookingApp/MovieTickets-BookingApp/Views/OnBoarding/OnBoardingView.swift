//
//  OnBoardingView.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 22/04/24.
//

import SwiftUI

struct OnBoardingView: View {
    @State var moveToLoginView = false
    var body: some View {
        VStack {
            ScrollView {
                HeaderView()
                    .padding(.vertical,Constant.setSpace._20Padding)
                    .padding(.bottom,Constant.setSpace._20Padding)
                MiddleView()
                    .padding(.bottom,Constant.setSpace._25Padding)
                CommonButton(title: "Get Started", action: {self.moveToLoginView = true})
                    .padding(.horizontal,Constant.setSpace._40Padding)
                }
            }
        .navigationDestination(isPresented: $moveToLoginView, destination: {
            LoginView()
        })
        .navigationBarBackButtonHidden(true)
           
            
            
            
        }
    }


#Preview {
    OnBoardingView()
}

extension OnBoardingView {
    func HeaderView() -> some View {
        VStack {
            Image(Constant.Image.kOnBoardingHeader)
            Image(Constant.Image.kCoffeeImage)
        }
    }
}
extension OnBoardingView {
    func MiddleView() ->some View {
        VStack(spacing: Constant.setSpace._9Padding){
            CommonText(
                title: "Find your favorite",
                fontSize: Constant.FontSize._30FontSize,
                fontStyle: .Medium,
                foregroundColor: Color.AppDarkBlue
            )
            CommonText(
                title: "Coffee Taste!",
                fontSize: Constant.FontSize._34FontSize,
                fontStyle: .BoldItalic,
                foregroundColor: Color.AppDarkBlue
            )
            CommonText(
                title: "We’re coffee shop, beer and wine bar,\n & event space for performing arts",
                fontSize: Constant.FontSize._14FontSize,
                fontStyle: .Medium,
                foregroundColor: Color.AppBlue
            )
        }
    }
}
