//
//  RegisterView.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 23/04/24.
//

import SwiftUI

struct RegisterView: View {
    @StateObject var registerVM : RegisterViewModel = RegisterViewModel()
    @EnvironmentObject private var viewRouter: ViewRouter

    @Environment(\.dismiss) var dismiss
    var body: some View {
        VStack{
            VStack(){
                HStack(alignment:.top){
                    Image(Constant.Image.kLoginBack)
                }
                .ignoresSafeArea()
                
            }
            ScrollView(showsIndicators:false){
                VStack{
                    
                   headerView()
                        .padding(.bottom,Constant.setSpace._80Padding)
                        .onTapGesture {
                            setDataIfDebug()
                        }
                    middleView()
                        .padding(.bottom,Constant.setSpace._20Padding)
                    CommonButton(title: Constant.Buttons.kSignUp, action: {
                        registerVM.onBtnSignUp_Click {
                            DispatchQueue.main.async {
                                self.viewRouter.isLoggedIn = true
                            }
                        }
                    })
                    .padding()
                    HStack {
                        Text(Constant.AppString.kAlreadyHaveAnAccount)
                        Text(Constant.AppString.kSignIn)
                            .underline(true,color: Color.AppCream)
                            .foregroundStyle(Color.AppCream)
                            .font(.setFont(style: .Medium,size: 16))
                    }
                    .background(Color.appBlue.opacity(0.01))
                    .onTapGesture {
                        dismiss()
                    }
                    .font(.setFont(style: .Medium,size: 15 ))
                }
            }
            .navigationBarBackButtonHidden(true)
        }
       
        
        
    }
}

#Preview {
    RegisterView()
}
#Preview {
    LoginView()
}
extension RegisterView {
    func headerView() -> some View{
        VStack{
            Text(Constant.AppString.kSignUp)
                .font(.setFont(style: .Bold,size: 40))
                .padding(.bottom,Constant.setSpace._5Padding)
            Text(Constant.AppString.kLetCreateYouAnAccount)
                .foregroundStyle(Color.AppBlue)
                .font(.setFont(style: .Regular,size: 14))
                
        }
    }
}

extension RegisterView {
    func middleView() -> some View {
        VStack {
            CommonTextField(
                ImageOnLeft:Constant.Image.kEmailicon,
                heading: Constant.AppString.kEmail,
                width: 30,
                height: 20,
                placeholder: Constant.AppString.kEmailPlacerHolder,
                text: $registerVM.txtEmail
            )
            .keyboardType(.emailAddress)
                .padding()
            CommonSecureField(ImageOnLeft:Constant.Image.kPasswordIcon,heading: Constant.AppString.kPassword, placeholder: Constant.AppString.kPasswordPlacerHolder, text: $registerVM.txtPassword)
                .padding()
            CommonSecureField(ImageOnLeft:Constant.Image.kPasswordIcon,heading: Constant.AppString.kRePassword, placeholder: Constant.AppString.kPasswordPlacerHolder, text: $registerVM.txtRePassword)
                .padding()
        }
    }
}

extension RegisterView {
    func setDataIfDebug() {
        #if DEBUG
        registerVM.txtEmail = registerVM.txtEmail.isEmpty ? "jaymeen@yopmail.com" : ""
        registerVM.txtPassword = registerVM.txtPassword.isEmpty ? "Test@123" : ""
        registerVM.txtRePassword = registerVM.txtRePassword.isEmpty ? "Test@123" : ""
        #endif
    }
}
