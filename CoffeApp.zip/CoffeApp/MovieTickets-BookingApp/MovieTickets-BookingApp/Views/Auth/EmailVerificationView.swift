

import SwiftUI

struct EmailVerificationView: View {
    @Environment(\.dismiss) var dismiss
    @State var txtEmail : String = ""
    @State var selection : String = "+91"
    var body: some View {
        VStack{
            VStack(){
                HStack(alignment:.top){
                    Image(Constant.Image.kLoginBack)
                        .resizable()
                        .frame(maxWidth: .infinity)
                        .frame(height: 250)
                }
                .ignoresSafeArea()
                
            }
            
            ScrollView(showsIndicators:false){
                VStack{
                    headerView()
                        .padding(.top,Constant.setSpace._25Padding)
                        .padding(.bottom,Constant.setSpace._80Padding)
                    VStack{
                        CommonTextField(
                            ImageOnLeft: Constant.Image.kTextFieldIconLeft,
                            heading: Constant.AppString.kEmail,
                            placeholder: Constant.AppString.kEmailPlacerHolder,
                            text: $txtEmail
                        )
                            .keyboardType(.emailAddress)
                            .padding()

                        CommonText(title: Constant.AppString.kBackToLogin, fontSize: Constant.FontSize._16FontSize, fontStyle: .Medium, foregroundColor: Color.AppCream)
                            .onTapGesture {
                                dismiss()
                            }
                            .padding()
                            .underline(true,color: Color.AppCream)
                    }
                    .padding(.bottom,Constant.setSpace._80Padding)
                    CommonButton(title: Constant.Buttons.kVerify, action: {
                        
                    })
                    .padding()
                    
                }
            }
            
        }
        .navigationBarBackButtonHidden(true)
    }
}

#Preview {
    EmailVerificationView()
}
extension EmailVerificationView {
    func headerView() -> some View{
        VStack{
            Text(Constant.AppString.kForgetPassword)
                .font(.setFont(style: .Bold,size: 40))
                .padding(.bottom,Constant.setSpace._5Padding)
            Text(Constant.AppString.kdontWorryWeWillFix)
                .foregroundStyle(Color.AppBlue)
                .font(.setFont(style: .Regular,size: 14))
                
        }
    }
}
