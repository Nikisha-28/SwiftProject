//
//  LoginView.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 22/04/24.
//

import SwiftUI

struct LoginView: View {
    @StateObject private var loginVM: LoginViewModel = LoginViewModel()
    @EnvironmentObject private var viewRouter: ViewRouter

    var body: some View {
        VStack{
            VStack(){
                HStack(alignment:.top){
                    Image(Constant.Image.kLoginBack)
                }
                .ignoresSafeArea()
                
            }
            
            ScrollView(showsIndicators:false){
                VStack{
                    
                   headerView()
                        .padding(.bottom,Constant.setSpace._80Padding)
                        .onTapGesture {
                            setDataIfDebug()
                        }
                    middleView()
                        .padding(.bottom,Constant.setSpace._50Padding)
                    
                    CommonButton(title: Constant.Buttons.kSignIn, action: {
                        loginVM.onBtnSignIn_Click {
                            DispatchQueue.main.async {
                                self.viewRouter.isLoggedIn = true
                            }
                        }
                    })
                    
                    .padding()
                    HStack {
                        Text(Constant.AppString.kDontHaveAnAccount)
                        Text(Constant.AppString.kSignUp)
                            .underline(true,color: Color.AppCream)
                            .foregroundStyle(Color.AppCream)
                            .font(.setFont(style: .Medium,size: 16))
                    }
                    .background(Color.AppBlue.opacity(0.01))
                    .onTapGesture {
                        loginVM.moveToReigsterView = true
                    }
                    .font(.setFont(style: .Medium,size: 15 ))
                    
                    
                    
                }
            }
            .navigationDestination(isPresented: $loginVM.moveToReigsterView, destination: {
                RegisterView()
            })
            .navigationBarBackButtonHidden(true)
        }
        
        
    }
}

#Preview {
    LoginView()
}
extension LoginView {
    func headerView() -> some View{
        VStack{
            Text(Constant.AppString.kSignIn)
                .font(.setFont(style: .Bold,size: 40))
                .padding(.bottom,Constant.setSpace._5Padding)
            Text(Constant.AppString.kWeHaveAlreadyMet)
                .foregroundStyle(Color.AppBlue)
                .font(.setFont(style: .Regular,size: 14))
                
        }
    }
}

extension LoginView{
    func middleView() -> some View {
        VStack {
            CommonTextField(
                ImageOnLeft:Constant.Image.kEmailicon,
                heading: Constant.AppString.kEmail,
                width: 30,
                height: 20,
                placeholder: Constant.AppString.kEmailPlacerHolder,
                text: $loginVM.txtEmail
            )
            
                .padding()
                .keyboardType(.emailAddress)
            CommonSecureField(ImageOnLeft:Constant.Image.kPasswordIcon,heading: Constant.AppString.kPassword, placeholder: Constant.AppString.kPasswordPlacerHolder, text: $loginVM.txtPassword)
                .padding()
            CommonText(title: Constant.AppString.kForgetPassword, fontSize: Constant.FontSize._16FontSize, fontStyle: .Medium, foregroundColor: Color.appCream, action: {
                
            })
                .padding()
                .underline(true,color: Color.AppCream)
        }
    }
}

extension LoginView {
    func setDataIfDebug() {
        #if DEBUG
        loginVM.txtEmail = loginVM.txtEmail.isEmpty ? "jaymeen@yopmail.com" : ""
        loginVM.txtPassword = loginVM.txtPassword.isEmpty ? "Test@123" : ""
        #endif
    }
}
