//
//  SplashView.swift
//  HailBooks
//
//  Created by Pooja Sadariwala on 26/02/24.

//

import SwiftUI

struct SplashView: View {
    
    var body: some View {
        VStack {
            GifImageView("CoffeeGIF")
                .frame(
                    width: ScreenSize.SCREEN_WIDTH,
                    height: 450,
                    alignment: .center
                )
        }
        .ignoresSafeArea()
    }
}

struct SplashView_Previews: PreviewProvider {
    static var previews: some View {
        SplashView()
    }
}

