//
//  WelcomeView.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 22/04/24.
//

import Foundation
import SwiftUI

struct WelcomeView: View {
    @EnvironmentObject var viewRouter: ViewRouter
    @State var showSplash: Bool = true
    
    
    var body: some View {
            if showSplash {
                SplashView()
                    .onAppear(perform: {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5, execute: {
                            withAnimation(.smooth){
                                self.showSplash = false
                            }
                            
                        })
                    })
            } else {
                if viewRouter.isLoggedIn || UserDefaults.isLoggedIn || UserDefaults.standard.loginUser != nil {
//                        DashboardView()
                    NavigationStack {
                        HomeScreen()
                    }
                } else {
                    NavigationStack {
                        OnBoardingView()
                    }
                }
            }
    }
}
