//
//  ProfileView.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 25/04/24.
//

import SwiftUI

struct ProfileView: View {
    
    @StateObject var profileVM: ProfileViewModel = ProfileViewModel()
    
    private var editImage = true
    
    var body: some View {
        VStack {
            mainView()
        }
        .ignoresSafeArea(.container, edges: .top)
    }
}


struct Curveshape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: .zero)
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY))
        //path.addCurve(to: CGPoint(x: rect.minX, y: rect.maxY), control1: CGPoint(x: rect.maxX * 0.70, y: rect.minY), control2: CGPoint(x: rect.maxX * 0.0, y: rect.maxY * 0.50))
        path.addCurve(to: CGPoint(x: rect.minX, y: rect.maxY),
                              control1: CGPoint(x: rect.maxX * 0.70, y: rect.midY),
                              control2: CGPoint(x: rect.maxX * 0.25, y: rect.maxY * 1.25))
        path.closeSubpath()
        return path
    }
}

#Preview {
    ProfileView()
}


extension ProfileView
{
    func mainView() -> some View {
        VStack {
            
            ZStack {
                Curveshape()
                    .fill(Color.appBrown)
                    .frame(height: 200)

                Image(Constant.Image.kProfileIcon)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 120, height: 120)
                    .clipShape(Circle())
                    .overlay(
                        Circle().stroke(Color.white, lineWidth: 4)
                    )
                    .offset(x: 0, y: 80)
                
                if editImage {
                    Image(Constant.Image.kCamera)
                        .resizable()
                        .frame(width: 20, height: 20)
                        .padding(.all, 5)
                        .background(Color.appGray)
                        .clipShape(Circle())
                        .overlay(
                            Circle().stroke(Color.appBrown, lineWidth: 1)
                        )
                        .offset(x: 40, y: 120)
                        .fullScreenCover(isPresented: $profileVM.isShowingImagePicker) {
                            CommonImagePickerView(
                                sourceType: self.profileVM.isPresentCamera ? (
                                    UIImagePickerController.isSourceTypeAvailable(
                                        .camera
                                    ) ? .camera : .photoLibrary
                                ) : .photoLibrary,
                                image: self.$profileVM.selectedImage,
                                isPresented: self.$profileVM.isShowingImagePicker
                            )
                            .ignoresSafeArea()
                        }
                        .onTapGesture {
                            self.profileVM.isShowingImagePicker = true
                        }
                }
                
            }
            
            VStack {
                
                CommonText(title: Constant.AppString.kEditProfile, fontSize: Constant.setSpace._30Padding, fontStyle: .Bold, foregroundColor: Color.appBrown)
                    
                ScrollView {
                    VStack(alignment: .leading){
                        
                        CommonTextField(ImageOnLeft: Constant.Image.kProfile, heading: Constant.AppString.kProfileName, placeholder: Constant.AppString.kProfileName, text: $profileVM.txtName)
                            .frame(maxWidth: .infinity)
                        
                        CommonTextField( ImageOnLeft: Constant.Image.kProfile, heading: Constant.AppString.kProfileEmail, placeholder: Constant.AppString.kProfileEmail, text: $profileVM.txtEmail)
                            .frame(maxWidth: .infinity)
                            
                        CommonTextField(ImageOnLeft: Constant.Image.kProfile, heading: Constant.AppString.kProfileAddress, placeholder: Constant.AppString.kProfileAddress, text: $profileVM.txtAddress)
                            .frame(maxWidth: .infinity)
                        
                        CommonTextField(ImageOnLeft: Constant.Image.kProfile, heading: Constant.AppString.kProfileContactNo, placeholder: Constant.AppString.kProfileContactNo, text: $profileVM.txtContactNo)
                            .frame(maxWidth: .infinity)
                        
                        CommonTextField(ImageOnLeft: Constant.Image.kProfile, heading: Constant.AppString.kProfileGender, placeholder: Constant.AppString.kProfileGender, text: $profileVM.txtGender)
                            .frame(maxWidth: .infinity)
                        
                        CommonTextField(ImageOnLeft: Constant.Image.kProfile, heading: Constant.AppString.kProfileCity, placeholder: Constant.AppString.kProfileCity, text: $profileVM.txtCity)
                            .frame(maxWidth: .infinity)
                        
                        CommonButton(title: Constant.AppString.kSubmit, action: {
                            self.profileVM.editProfileClick()
                        })
                        .frame(maxWidth: .infinity)
                        .padding(.bottom, 70)

                    }
                    .padding()
                //.padding(.bottom, Constant.setSpace._30Padding)
                }
                .scrollIndicators(.hidden)
            }
            .offset(x: 0, y: 40)
            //.offset(y: -80)
        }
        .edgesIgnoringSafeArea(.top)
    }
}






