import SwiftUI

struct MessageCell: View {
    var contentMessage: String
    var isCurrentUser: Bool
    
    var body: some View {
//        CommonText(title: contentMessage, fontSize: Constant.FontSize._16FontSize, fontStyle: .Medium, foregroundColor: Color.white)
        Text(contentMessage)
            .foregroundStyle(Color.white)
            .setFont(style: .Medium, size: Constant.FontSize._16FontSize)
            .lineSpacing(10)

            .padding(10)
            .background(isCurrentUser ? Color.AppBrown : Color.AppCream)
            .cornerRadius(10)
    }
}

#Preview {
    MessageCell(contentMessage: "This is a single message cell.", isCurrentUser: false)
}
