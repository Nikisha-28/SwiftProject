import Combine
import SwiftUI
import SwiftData

import GoogleGenerativeAI

struct ChatView: View {
    @Environment(\.dismiss) var dismiss
    @Environment(\.modelContext) var modelContext
    @Query(sort:[SortDescriptor(\MessageModel.timestamp,order: .forward)], animation: .smooth) var messages : [MessageModel]
    
    @State var showingAlert = false
    @State var newMessage: String = ""
    @State var newMessageTemp: String = ""
    @State var isLoading: Bool = false
    
    private let model = GenerativeModel(name: "gemini-pro", apiKey: "AIzaSyBmfBH2-6tqqdJ-SNUsLiUt0zFYMGYpgm8")
    
    var body: some View {
        VStack {
            VStack {
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack {
                            if messages.isEmpty {
                                PlaceHolderView()
                            } else {
                                ForEach(messages, id: \.self) { message in
                                    MessageView(currentMessage: message)
                                        .id(message)
                                }
                            }
                        }
                        .onReceive(Just(messages)) { _ in
                            withAnimation {
                                proxy.scrollTo(messages.last, anchor: .bottom)
                            }
                            
                        }.onAppear {
                            withAnimation {
                                proxy.scrollTo(messages.last, anchor: .bottom)
                            }
                        }
                    }
                    
                    .onTapGesture {
                        hideKeyboard()
                        proxy.scrollTo(messages.last, anchor: .bottom)
                    }
                    
                    BottomTextFieldView()
//                        .padding(.bottom, 70)
                }
            }
            
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarBackButtonHidden()
            .alert("Are you sure you want to clear chat history?", isPresented: $showingAlert) {
                Button("Cancel", role: .cancel) { }
                Button("Delete", role: .destructive) {
                    messages.forEach { element in
                        self.modelContext.delete(element)
                    }
                }
            }
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        self.dismiss()
                    } label: {
                        HStack {
                            Image(systemName: "chevron.left")
                                .bold()
                                .foregroundStyle(Color.AppCream)
                        }
                    }
                }
                ToolbarItem(placement: .principal) {
                    CommonText(
                        title: "CoffeeApp ",
                        fontSize: Constant.FontSize._18FontSize,
                        fontStyle: .Bold,
                        foregroundColor: .AppBrown
                    )
                    .padding(.top, 5)
                }
                
                ToolbarItem (placement: .topBarTrailing){
                    Button(action: {
                        showingAlert = true
                    }, label: {
                        Image(systemName: "trash")
                    })
                }
            }
        }
    }
    
    func sendMessage() {
        if !newMessage.isEmpty{
            addMessage(chatText: newMessage, currentUser: true)
            Task {
                do{
                    let prompt = newMessage
                    let response = try await model.generateContent(prompt)
                    if let text = response.text {
                        addMessage(chatText: text, currentUser: false)
                        newMessage = ""
                        isLoading = false
                    }
                } catch {
                    addMessage(chatText: "Sorry, didn't get that. Can you please try again?", currentUser: false)
                    newMessage = ""
                    isLoading = false
                }
            }
        }
    }
    
    
    func addMessage(chatText: String, currentUser: Bool){
        let newMessage = MessageModel(id: UUID(), content: chatText, isCurrentUser: currentUser, timestamp: Date())
        modelContext.insert(newMessage)
    }
}

extension View {
    func hideKeyboard() {
        let resign = #selector(UIResponder.resignFirstResponder)
        UIApplication.shared.sendAction(resign, to: nil, from: nil, for: nil)
    }
}

#Preview {
    ChatView()
}

struct TextFieldView:View {
    var placeholder :String
    @Binding var text : String
    var body: some View {
        
        
        TextField("", text: $text,prompt:Text(placeholder).foregroundStyle(Color.AppBlack.opacity(0.5)))
            .frame(height: 30)
            .foregroundColor(Color.AppBrown)
            .font(.setFont(style: .Medium, size: 18))
            .background(Color.AppWhite.opacity(0.1))
            .clipShape(RoundedRectangle(cornerRadius: 10 ))
            .autocorrectionDisabled()
        
    }
}

///`PlaceHolderView`
extension ChatView {
    func PlaceHolderView() -> some View {
        VStack {
            Image(Constant.Image.kChatBot)
                .resizable()
                .background(.black)
                .clipShape(Circle())
                .overlay {
                    Circle().stroke(Color.AppBrown, lineWidth: 5)
                }
                .frame(width: 150, height: 150, alignment: .center)
                .padding(.top, 100)
            
            CommonText(
                title: "Hi, how can I help you today?",
                fontSize: Constant.FontSize._25FontSize,
                fontStyle: .Medium,
                foregroundColor: Color.AppBrown
            )
            
            .font(.title)
            .padding()
            
        }
    }
}

extension ChatView {
    func BottomTextFieldView() -> some View {
        HStack {
            TextFieldView(placeholder: "Ask me anything", text: isLoading ? $newMessageTemp : $newMessage)
            
            if isLoading {
                ProgressView()
                    .padding(.leading, 3.0)
            }
            else{
                Button(action: {
                    sendMessage()
                    isLoading = true
                    
                }, label: {
                    Image(systemName: "paperplane")
                        .bold()
                        .foregroundStyle(Color.AppCream)
                        .scaleEffect(1.2)
                }).disabled(newMessage.isEmpty)
            }
            
        }
        .padding()
        .padding(.horizontal, 10)
        .overlay {
            RoundedRectangle(cornerRadius: 20)
                .stroke(lineWidth: 0.5)
        }
        .padding(.horizontal, 10)
    }
}
