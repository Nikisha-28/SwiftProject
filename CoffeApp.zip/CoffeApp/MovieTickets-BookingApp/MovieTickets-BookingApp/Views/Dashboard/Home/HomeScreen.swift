//
//  HomeScreen.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 25/04/24.
//

import SwiftUI

struct HomeScreen: View {
    @EnvironmentObject private var viewRouter: ViewRouter
    
    var body: some View {
        ZStack(alignment: .bottom) {
            
            TabView(selection: $viewRouter.tabSelecteionIndex) {
                DashboardView()
                    .tag(0)
            
                FavouriteView()
                    .tag(1)
                
                CartView()
                    .tag(2)
                
                ProfileView()
                    .tag(3)
            }
            .toolbar(.hidden, for: .tabBar)
            
//            .tabViewStyle(.page(indexDisplayMode: .always))  // <--- here

            ZStack {
                BottomBarView()
                    .frame(width: ScreenSize.SCREEN_WIDTH, height: 55, alignment: .center)
                    .background(Color.AppWhite)
                    .shadow(color: .black, radius: 0.2, x: 0, y: 0)
            }
        }
        .navigationBarBackButtonHidden(true)
//        .ignoresSafeArea(.container, edges: .vertical)
    }
}

#Preview {
    HomeScreen()
        .environmentObject(ViewRouter())
}

extension HomeScreen {
    func BottomBarView() -> some View {
        HStack{
            ForEach((TabBarItems.allCases), id: \.self){ item in
                TabbarItemCell(
                    image: item.imageIcon,
                    isSelected: viewRouter.tabSelecteionIndex == item.rawValue
                )
//                .padding(.bottom, 5)
                .onTapGesture {
                    viewRouter.tabSelecteionIndex = item.rawValue
                    NavigationUtil.popTabIndexViews(to: item.rawValue)
                }

                .frame(maxWidth: .infinity, alignment: .center)
//                .frame(height: 20)
            }
//            
        }
        .frame(width: ScreenSize.SCREEN_WIDTH, height: 30, alignment: .center)
        .foregroundStyle(Color.red)
    }
    
    func TabbarItemCell(image: String, isSelected: Bool) -> some View {
        VStack(alignment: .center, spacing: Constant.setSpace._8Padding) {
            
            Image(image)
                .resizable()
                .renderingMode(.template)
                .frame(
                    width: Constant.setFrame._20Size,
                    height: Constant.setFrame._20Size,
                    alignment: .center
                )
                .foregroundColor(
                    isSelected ?
                        .AppWhite :
                            .AppDarkerGray
                )
                
//                .frame(height: Constant.setFrame._15Size)
//            .opacity(isSelected ? 1 : 0)
        }
        
    }
}

extension HomeScreen {
    enum TabBarItems: Int, CaseIterable {
        case Home = 0
        case Favourite = 1
        case Cart = 2
        case Profile = 3

        var imageIcon: String {
            switch self {
            case .Home:
                return Constant.Image.kdashboard
            case .Favourite:
                return Constant.Image.kFavourite
            case .Cart:
                return Constant.Image.kCart
            case .Profile:
                return Constant.Image.kProfile
            }
        }
    }
}
