//
//  CartView.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 25/04/24.
//

import SwiftUI
import SDWebImageSwiftUI

struct CartView: View {
    @EnvironmentObject var dashBoardVM: DashboardViewModel

    var body: some View {
        ZStack(alignment: .top) {
            VStack {
                ImageView()
                VStack {
                    HeaderView()
                        .padding(.bottom, Constant.setSpace._18Padding)
                    
                    mainView()
                }
                .padding(Constant.setSpace._20Padding)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)

        }
        .gesture(false ? DragGesture() : nil)
        .onAppear{
            self.dashBoardVM.updateCartList()
        }
        .ignoresSafeArea(.container, edges: .top)
        .navigationBarBackButtonHidden(true)
    }
}

#Preview {
    CartView()
}


extension CartView {
    func ImageView() -> some View {
        Image(Constant.Image.kDashboardHeader)
    }
}

extension CartView {
    func HeaderView() -> some View {
        HStack {
            CommonText(title: Constant.AppString.kCart, fontSize: Constant.FontSize._20FontSize, fontStyle: .Bold)
            
            Spacer()
            
            Image(Constant.Image.kProfileIcon)
                .resizable()
                .frame(width: Constant.setFrame._40Size, height: Constant.setFrame._40Size)
        }
    }
}

extension CartView {
    func mainView() -> some View {
        VStack(alignment: .leading) {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 15.0) {
                    ForEach(0..<dashBoardVM.arrCartItems.count, id: \.self) { i in
                        HStack(alignment: .top) {
                            WebImage(url: URL(string: dashBoardVM.arrCartItems[i].image ?? ""))
                                
                                .placeholder(Image("CoffeeMockup1"))
                                .resizable()
                                .frame(width: Constant.setFrame._70Size, height: Constant.setFrame._70Size)
//                                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                                .clipShape(Circle())
                                .padding(.trailing, Constant.setSpace._10Padding)
                            
                            VStack(alignment: .leading) {
                                CommonText(title: "\(dashBoardVM.arrCartItems[i].title ?? "")", fontSize: Constant.FontSize._15FontSize, fontStyle: .SemiBold, foregroundColor: Color.AppWhite)
                                    .padding(.bottom, Constant.setSpace._2Padding)
                                

                                CommonText(title: "$ \(dashBoardVM.arrCartItems[i].price ?? 0)", fontSize: Constant.FontSize._11FontSize, fontStyle: .SemiBold, foregroundColor: Color.AppWhite)
                                    .padding(.bottom, Constant.setSpace._2Padding)
                            }
                            .padding()
                        }
                        
                        
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                        .background(Color.AppBrown)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .contextMenu {
                            Button(action: {
                                dashBoardVM.addToCartTapped(selectedDrink: dashBoardVM.arrCartItems[i])
                            }) {
                                Text("Remove From Cart")
                            }
                         }
                        .swipeActions(iconLast: (self.dashBoardVM.userModel?.favourites ?? "")
                            .contains("\(ProductType(rawValue: dashBoardVM.arrCartItems[i].productType ?? 1)?.title ?? "") - \(dashBoardVM.arrCartItems[i].id ?? 0)") ? "trash.fill" : "trash" ,  iconSecondLast: ""){ event in
                            dashBoardVM.addToCartTapped(selectedDrink: dashBoardVM.arrCartItems[i])
                        }
                    }
                }
            }
        }
    }
}

extension CartView {
    func ListView() -> some View {
        VStack {
            CommonText(title: "this is a list view text...")
        }
    }
}
