//
//  DashboardView.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 23/04/24.
//

import SwiftUI
import VisionKit
import UIKit
import Vision
import SDWebImageSwiftUI

struct DashboardView: View {
    @State var selectedCategory = 0
    @State var showsheet = false
    @State var heart = false
    @EnvironmentObject var dashBoardVM: DashboardViewModel 
    @EnvironmentObject private var viewRouter: ViewRouter
    @EnvironmentObject private var globalVM: GlobalViewModel
    @State var shouldMoveChatScreen: Bool = false
    
    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            ZStack(alignment: .top) {
                VStack {
                    ScrollView {
                        VStack {
                            ImageView()
                            VStack{
                                HeaderView()
                                    .padding([.bottom, .horizontal], Constant.setSpace._18Padding)
                                TextView()
                                    .padding([.bottom, .horizontal], Constant.setSpace._10Padding)
                                
                                mainView()
                            }
                            .padding(.vertical, Constant.setSpace._20Padding)
                            .padding(.bottom, Constant.setSpace._20Padding * 3)
                        }
                    }
                    .scrollIndicators(.hidden)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
            }
            ChatBotView()
        }
        .gesture(false ? DragGesture() : nil)
        .ignoresSafeArea(.container, edges: .top)
        .onAppear {
            dashBoardVM.getProductData()
            dashBoardVM.getUserDataInRealTime() 
        }
        .sheet(isPresented: $showsheet, content: {
            BottomSheetView()
        })
        .navigationDestination(isPresented: $dashBoardVM.moveToListViewFromBeers, destination: {
            ListView(ListData: $dashBoardVM.arrBeers)
        })
        .navigationDestination(isPresented: $dashBoardVM.moveToListViewFromWines, destination: {
            ListView(ListData: $dashBoardVM.arrWines)
        })
        .navigationDestination(isPresented: $dashBoardVM.moveToListViewFromCoffee, destination: {
            ListView(ListData: $dashBoardVM.arrCoffees)
        })
        .navigationDestination(isPresented: $shouldMoveChatScreen, destination: {
            ChatView()
        })
    }
}

#Preview {
    DashboardView()
}

extension DashboardView {
    func ImageView() -> some View {
        Image(Constant.Image.kDashboardHeader)
    }
}
extension DashboardView {
    func HeaderView() -> some View {
        HStack{
            Image(Constant.Image.kProfileIcon)
                .resizable()
                .frame(width: Constant.setFrame._40Size,height: Constant.setFrame._40Size)
            Spacer()
            Image(Constant.Image.kMenuIcon)
                .resizable()
                .frame(width: Constant.setFrame._30Size,height: Constant.setFrame._10Size)
                .onTapGesture {
        //            FIBDataStore.shared.saveCoffeesData()
        //            FIBDataStore.shared.saveBeersData()
        //            FIBDataStore.shared.saveWinesData()
                    self.logoutUser()
                }
        }
        
    }
}
extension DashboardView {
    func TextView() ->some View {
        LazyVStack(alignment:.leading){
            HStack{
                CommonText(title: "Hi,", fontSize: Constant.setSpace._30Padding, fontStyle: .Medium, foregroundColor: Color.AppBlack)
                CommonText(title: "\(UserDefaults.standard.loginUser?.email?.split(separator: "@").first ?? "")", fontSize: Constant.setSpace._30Padding, fontStyle: .Bold, foregroundColor: Color.AppBlack)
            }
        }
    }
}



///`logoutUser`
extension DashboardView {
    func logoutUser() {
        FIBAuthService.shared.logoutUser {
            UserDefaults.standard.loginUser = nil
            UserDefaults.isLoggedIn = false
            DispatchQueue.main.async {
                self.viewRouter.isLoggedIn = false
            }
        }
    }
}


extension DashboardView {
    func ChatBotView() -> some View {
        Button {
            self.shouldMoveChatScreen = true
        } label: {
            Image(Constant.Image.kChatBot)
                .resizable()
                .frame(width: 60, height: 60, alignment: .center)
                .padding(.all)
                .padding(.bottom, 50)
        }
    }
}
