//
//  ProductDetailView.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 01/05/24.
//

import SwiftUI
import UIKit
import SDWebImageSwiftUI

struct ProductDetailView: View {
    
    @EnvironmentObject var dashboardVM: DashboardViewModel
    @EnvironmentObject private var viewRouter : ViewRouter
    
    var product: ProductModel? = nil
    @State var like = false
    @Environment(\.dismiss) var dismiss

    @State var bacToListView = false
    
    var body: some View {
        ZStack(alignment:.bottom){
            ZStack(alignment:.top) {
                
                ImageView()
                    .padding(.bottom,Constant.setSpace._20Padding)
                
                VStack(alignment:.leading){
                    ZStack(alignment: .topLeading){
                        WebImage(url: URL(string: product?.image ?? ""))
                            .resizable()
                            .placeholder(Image("CoffeeMockup0"))
                            .frame(maxWidth: .infinity)
                            .frame( height: 350)
                            .background(Color.AppWhite)
                            .clipShape(Rectangle())
                            .shadow(color: .AppBrown, radius: 10)
                            .padding(.bottom,Constant.setSpace._20Padding)
                        BackImage()
                           
                    }
                    
                    LazyVStack(){
                        ScrollView{
                            CommonText(title: "\(product?.title ?? "")", fontSize: Constant.FontSize._20FontSize, fontStyle: .Bold, foregroundColor: Color.AppWhite)
                                .multilineTextAlignment(.leading)
                            CommonText(title: "\(product?.description ?? "")", fontSize: Constant.FontSize._12FontSize, fontStyle: .Medium, foregroundColor: Color.AppWhite)
                                .frame(minHeight: 80)
                                .multilineTextAlignment(.leading)
                            Divider()
                                .foregroundColor(.AppWhite)
                            if !(product?.ingredients?.isEmpty ?? true) {
                                CommonText(title: "Ingredients :- ", fontSize: Constant.FontSize._20FontSize, fontStyle: .SemiBold, foregroundColor: Color.AppCream)
                                                   .padding(.bottom, Constant.setSpace._10Padding)
                                                   .frame(maxWidth: .infinity, alignment: .leading)
                                if let ingredients = product?.ingredients {
                                    ForEach(ingredients, id: \.self){ i in
                                        VStack(spacing:2){
                                            HStack{
                                                Image(systemName: "circle.dotted.circle.fill")
                                                    .resizable()
                                                    .frame(width: 5,height: 5)
                                                    .foregroundColor(Color.AppWhite)
                                                CommonText(title: (i), fontSize: Constant.FontSize._14FontSize, fontStyle: .SemiBold, foregroundColor: Color.appWhite)
                                                                   .frame(maxWidth: .infinity, alignment: .leading)
                                            }
                                        }
                                        
                                    }
                                }
                                    
                            }
                        }
                        
                        .padding(.bottom,30)
                        
                        
                       
                                           
                    }
                    .padding()
                   
                    
                    
                }
                
            }
           
            
            VStack{
                HStack{
                    CommonText(title: "$ \(product?.price ?? 0)", fontSize: Constant.FontSize._20FontSize, fontStyle: .Bold, foregroundColor: Color.AppWhite)
                        .shadow(color: Color.AppGray,radius: 10)
                        .frame(width: ScreenSize.SCREEN_WIDTH * 0.20)
                    Button(action: {
                        self.dashboardVM.addToCartTapped(selectedDrink: product)
                    }) {
                        Text((self.dashboardVM.userModel?.cartItems ?? "")
                          .contains("\(ProductType(rawValue: product?.productType ?? 1)?.title ?? "") - \(product?.id ?? 0)") ? "Added ✔" : "Add to cart")
                            .foregroundColor(.AppBrown)
                            .padding()
                            .frame(width: ScreenSize.SCREEN_WIDTH * 0.60)
                            .background(Color.AppWhite)
                            .cornerRadius(8)
                            .font(.setFont(style: .Medium,size: 18))
                            
                    }
                    Button(action: {
                        self.dashboardVM.addToFavouritesTapped(selectedDrink: product)
                    }) {
                        Image(systemName: (self.dashboardVM.userModel?.favourites ?? "")
                          .contains("\(ProductType(rawValue: product?.productType ?? 1)?.title ?? "") - \(product?.id ?? 0)") ? "heart.fill" : "heart")
                            .resizable()
                            .foregroundColor((self.dashboardVM.userModel?.favourites ?? "")
                              .contains("\(ProductType(rawValue: product?.productType ?? 1)?.title ?? "") - \(product?.id ?? 0)") ? Color.red.opacity(0.8) : Color.AppWhite.opacity(0.7))
                            .frame(width: 30,height: 30)
                            
                            
                    }
                    .frame(width: ScreenSize.SCREEN_WIDTH * 0.10)
                }
               
                
            }
           
        
            .frame(maxWidth: .infinity)
            .frame(height: 80)
            .background(Color.AppBrown.opacity(0.3))
            
        }
        
        
       
        .navigationBarBackButtonHidden(true)

    }
}

//#Preview {
//    ProductDetailView(coffee: CoffeeModel(from: ""))
//}

extension ProductDetailView {
    func ImageView() -> some View {
        ZStack {
            WebImage(url: URL(string:product?.image ?? ""))
                .resizable()
                .placeholder(Image("CoffeeMockup0"))
                .ignoresSafeArea()
                .blendMode(.darken)
                .blur(radius: 10, opaque: true)
//                    .opacity(0.6)
            ZStack{
                Color.black.opacity(0.7)
            }
           
                
        }
        .ignoresSafeArea()
            
        
    }
    
    func BackImage() -> some View {
        Button(action: {
            dismiss()
        }, label: {
           
            Image(systemName:  "xmark")
                .resizable()
                .frame(width: Constant.setFrame._20Size, height: Constant.setFrame._20Size)
                .foregroundColor(Color.AppWhite)
                .padding()
                .clipShape(Circle())
        })
    }
}


#Preview {
    ProductDetailView()
}
