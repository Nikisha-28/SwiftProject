//
//  ListView.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 01/05/24.
//

import SwiftUI
import SDWebImageSwiftUI

struct ListView: View {
    
    @EnvironmentObject private var viewRouter: ViewRouter
    @Binding var ListData : [ProductModel]
    @EnvironmentObject var dashBoardVM : DashboardViewModel     //@State private var isProductDetailPresented: Bool = false
    @State private var selectedItem: ProductModel? = nil
    @Environment(\.dismiss) var dismiss

    let coffeeArr = ["Black Coffee", "Latte", "Caramel Latte", "Cappuccino"]
    let priceArr = ["$85.00", "$22.00", "$60.00", "$90.00", "$75.00"]
    
    var body: some View {
        ZStack(alignment: .top) {
            VStack {
                ImageView()
                VStack {
                    HeaderView()
                        .padding(.bottom, Constant.setSpace._18Padding)
                    
                    mainView()
                        
                }
                .padding(Constant.setSpace._20Padding)
            }
        }
        .ignoresSafeArea(.container, edges: .bottom)
        .navigationBarBackButtonHidden(true)
            .toolbar(content: {
            ToolbarItem(placement: .topBarLeading) {
                Button {
                    self.dismiss()
                } label: {
                    HStack {
                        Image(systemName: "chevron.left")
                            .bold()
                            .foregroundStyle(Color.AppCream)
                    }
                }
            }
        })
        .sheet(item: $selectedItem) { selectedItem in
            ProductDetailView(product: selectedItem)
                .ignoresSafeArea()
                .presentationDetents([.height(400),.fraction(0.9)])
        }
        
    }
}

#Preview {
    ListView(ListData: .constant(DashboardViewModel().arrCoffees))
}

extension ListView {
    func ImageView() -> some View {
        Image(Constant.Image.kDashboardHeader)
    }
    
    func HeaderView() -> some View {
        HStack {
            CommonText(title: Constant.AppString.kProduct, fontSize: Constant.FontSize._20FontSize, fontStyle: .Bold)
            
            Spacer()
            
            Image(Constant.Image.kProfileIcon)
                .resizable()
                .frame(width: Constant.setFrame._40Size, height: Constant.setFrame._40Size)
        }
    }
}



extension ListView {
    func mainView() -> some View {
        NavigationStack {
            VStack(alignment: .leading) {
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 20.0) {
                        ForEach(0 ..< ListData.count,id:\.self) { i in
                            HStack(alignment: .top) {
                                 WebImage(url: URL(string: ListData[i].image ?? ""))
                                    .resizable()
                                    .placeholder(Image("CoffeeMockup0"))
                                    .frame(width: Constant.setFrame._100Size, height: Constant.setFrame._100Size)
                                    .background(Color.AppWhite)
                                    .clipShape(Circle())
                                    
                               
                                
                                VStack(alignment: .leading) {
                                    CommonText(title: "\(ListData[i].title ?? "")",fontSize: Constant.FontSize._20FontSize, fontStyle: .SemiBold, foregroundColor: Color.AppCream)
                                        .padding(.bottom, Constant.setSpace._2Padding)
                                    
                                    CommonText(title: "\(ListData[i].description ?? "")", fontSize: Constant.FontSize._18FontSize, fontStyle: .SemiBold, foregroundColor: Color.AppWhite.opacity(0.5))
                                        .lineLimit(2)
                                        .padding(.bottom, Constant.setSpace._2Padding)
                                    
                                    CommonText(title: "Price :- $ \(ListData[i].price ?? 0)", fontSize: Constant.FontSize._15FontSize, fontStyle: .SemiBold, foregroundColor: Color.AppWhite)
                                        .padding(.bottom, Constant.setSpace._2Padding)
                                    
                                }
    //                            .onTapGesture {
    //                                selectedItem = dashboardVM.arrCoffees[i]
    //                            }
                                .padding()
                                
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding()
                            .background(Color.AppBrown)
                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                            
                            .onTapGesture {
                                selectedItem = ListData[i]
                            }
                            .swipeActions(iconLast: (self.dashBoardVM.userModel?.favourites ?? "")
                                .contains("\(ProductType(rawValue: ListData[i].productType ?? 1)?.title ?? "") - \(ListData[i].id ?? 0)") ? "heart.fill" : "heart" ,  iconSecondLast: ""){ event in
                                dashBoardVM.addToFavouritesTapped(selectedDrink: ListData[i])
                            }
                        }
                    }
                   
                }
                .ignoresSafeArea(edges: .bottom)
            }
        }
    }
}


