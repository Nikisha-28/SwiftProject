//
//  DashboardViewExtensions.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 02/05/24.
//

import Foundation
import SwiftUI
import SDWebImageSwiftUI

// MARK: - MainView

extension DashboardView {
    func mainView() -> some View {
        VStack {
//            CategorySelectionView()
            HStack{
                Spacer()
                Button(action: {
                    self.dashBoardVM.moveToListViewFromCoffee = true
                }, label: {
                    CommonText(title: "See All", fontSize: Constant.FontSize._14FontSize, fontStyle: .SemiBold, foregroundColor: Color.AppCream,action: {})
                        .underline(true,color:Color.AppCream)
                })
            }
            .padding([.horizontal],Constant.setSpace._10Padding)
            FirstLayerView()
            SecondLayerView()
            ThirdLayerView()
        }
    }
}

// MARK: - BottomSheetView
extension DashboardView {
    func BottomSheetView() -> some View {
        ZStack{
            ZStack {
                WebImage(url: URL(string: dashBoardVM.selectedDrink?.image ?? ""))
                    .resizable()
                    .placeholder(Image("CoffeeMockup0"))
                    .ignoresSafeArea()
                    .blendMode(.darken)
//                    .opacity(0.6)
                Color.black.opacity(0.7)
                    .ignoresSafeArea()
            }
            VStack{
                ScrollView (showsIndicators:false){
                      VStack{
                          WebImage(url: URL(string: dashBoardVM.selectedDrink?.image ?? ""))
                              .resizable()
                              .placeholder(Image("CoffeeMockup0"))
                              .frame(width: Constant.setFrame._100Size, height: Constant.setFrame._100Size)
                              .background(Color.AppWhite)
                              .clipShape(RoundedRectangle(cornerRadius: 25.0))
                              .shadow(color: .gray, radius: 10)
                          CommonText(title: "\(dashBoardVM.selectedDrink?.title ?? "")", fontSize: Constant.setSpace._20Padding, fontStyle: .Bold, foregroundColor: Color.AppWhite)
                              .multilineTextAlignment(.center)
                          CommonText(title: "\(dashBoardVM.selectedDrink?.description ?? "")", fontSize: Constant.setSpace._12Padding, fontStyle: .Medium, foregroundColor: Color.AppWhite)
                              .frame(minHeight: 80)
                              .multilineTextAlignment(.center)
                            
                          HStack {
                              
                              Button(action: {
                                  self.dashBoardVM.addToCartTapped(selectedDrink: dashBoardVM.selectedDrink)
                              }) {
                                  Text((self.dashBoardVM.userModel?.cartItems ?? "")
                                    .contains("\(ProductType(rawValue: dashBoardVM.selectedDrink?.productType ?? 1)?.title ?? "") - \(dashBoardVM.selectedDrink?.id ?? 0)") ? "Added ✔" : "Add to cart")
                                      .foregroundColor(.AppBrown)
                                      .padding()
                                      .frame(width: ScreenSize.SCREEN_WIDTH * 0.80)
                                      .background(Color.AppWhite)
                                      .cornerRadius(8)
                                      .font(.setFont(style: .Medium,size: 18))
                                      
                              }
                              Button(action: {
                                  self.dashBoardVM.addToFavouritesTapped(selectedDrink: dashBoardVM.selectedDrink)
                              }) {
                                  Image(systemName: (self.dashBoardVM.userModel?.favourites ?? "")
                                    .contains("\(ProductType(rawValue: dashBoardVM.selectedDrink?.productType ?? 1)?.title ?? "") - \(dashBoardVM.selectedDrink?.id ?? 0)") ? "heart.fill" : "heart")
                                      .resizable()
                                      .foregroundColor((self.dashBoardVM.userModel?.favourites ?? "")
                                        .contains("\(ProductType(rawValue: dashBoardVM.selectedDrink?.productType ?? 1)?.title ?? "") - \(dashBoardVM.selectedDrink?.id ?? 0)") ? Color.red.opacity(0.8) : Color.AppWhite.opacity(0.7))
                                      .frame(width: 30,height: 30)
                                      
                                      
                              }
                              .frame(width: ScreenSize.SCREEN_WIDTH * 0.10)
                              
                          }
                          .padding(.bottom)
                        }
                        .padding()

                    
                        
                        
                }
                .padding(.top,Constant.setSpace._16Padding)
                .onAppear{
                    UIScrollView.appearance().bounces = false
                }
                
            }

        }
             
        .presentationDetents([.height(300)])
    }
}

#Preview(body: {
    DashboardView()
})

///`FirstLayerView`
extension DashboardView {
    func FirstLayerView() -> some View {
        ScrollView(.horizontal,showsIndicators: false) {
            
            LazyHStack(spacing: 10){
                ForEach(0 ..< dashBoardVM.arrCoffees.count,id:\.self) {i in
                    ZStack(alignment: .top) {
                        VStack{
                            VStack{}
                                .frame(width: 60,height: 60, alignment: .center)
                            CommonText(title: "\(dashBoardVM.arrCoffees[i].title ?? "")", fontSize: Constant.FontSize._13FontSize, fontStyle: .SemiBold, foregroundColor: dashBoardVM.selectedDrink?.id == dashBoardVM.arrCoffees[i].id && dashBoardVM.selectedDrink?.productType == dashBoardVM.arrCoffees[i].productType ? Color.AppWhite : Color.AppBlack)
                                .padding(.bottom,Constant.setSpace._2Padding)
                            CommonText(title: "$\(dashBoardVM.arrCoffees[i].price ?? 0)", fontSize: Constant.FontSize._11FontSize, fontStyle: .SemiBold, foregroundColor: dashBoardVM.selectedDrink?.id == dashBoardVM.arrCoffees[i].id && dashBoardVM.selectedDrink?.productType == dashBoardVM.arrCoffees[i].productType ? Color.AppWhite : Color.AppCream)
                            
                        }
                        .frame(width: 100,height: 100, alignment: .center)
                        .padding([.horizontal,.bottom],Constant.setSpace._20Padding)
                        .background(dashBoardVM.selectedDrink?.id == dashBoardVM.arrCoffees[i].id && dashBoardVM.selectedDrink?.productType == dashBoardVM.arrCoffees[i].productType ? Color.AppBrown : Color.AppGray)
                        .cornerRadius(12)
                        
                        WebImage(url: URL(string: dashBoardVM.arrCoffees[i].image ?? ""))
                            .resizable()
                            .placeholder(Image("CoffeeMockup0"))
                            .frame(width: Constant.setFrame._70Size,height: Constant.setFrame._70Size)
                        
                        
                            .background(Color.AppWhite)
                            .clipShape(Circle())
                            .offset(y:dashBoardVM.selectedDrink?.id == dashBoardVM.arrCoffees[i].id && dashBoardVM.selectedDrink?.productType == dashBoardVM.arrCoffees[i].productType   ? -25 : -20)
                        
                    }
                    .onTapGesture {
                        withAnimation(){
                            dashBoardVM.selectedDrink = dashBoardVM.arrCoffees[i]
                            showsheet = true
                        }
                    }
                    .padding(.top, 40)
                }
            }
            .padding(.horizontal, 12)
        }
        .fixedSize(horizontal: false, vertical: true)
        .padding(.bottom,Constant.setSpace._30Padding)
    }
}

///`SecondLayerView`
extension DashboardView {
    func SecondLayerView() -> some View {
        VStack {
            HStack{
                CommonText(title: "Beers", fontSize: Constant.FontSize._16FontSize, fontStyle: .SemiBold, foregroundColor: Color.AppDarkBlue)
                Spacer()
                Button(action: {
                    self.dashBoardVM.moveToListViewFromBeers = true
                }, label: {
                    CommonText(title: "See All", fontSize: Constant.FontSize._14FontSize, fontStyle: .SemiBold, foregroundColor: Color.AppCream,action: {})
                        .underline(true,color:Color.AppCream)
                })
            }
            .padding([.bottom, .horizontal],Constant.setSpace._10Padding)
            
            HStack{
                //ScrollView(showsIndicators: false) {
                ScrollView(.horizontal,showsIndicators: false) {
                    LazyHStack(spacing: 10) {
                        ForEach(0..<dashBoardVM.arrWines.count,id: \.self) { k in
                            HStack {
                                VStack {
                                    WebImage(url: URL(string: dashBoardVM.arrWines[k].image ?? ""))
                                        .resizable()
                                        .placeholder(Image("CoffeeMockup0"))
                                        .frame(width: Constant.setFrame._70Size, height: Constant.setFrame._70Size)
                                        .background(Color.AppWhite)
                                        .clipShape(Circle())
                                    
                                }
                                
                                VStack {
                                    CommonText(title: "\(dashBoardVM.arrWines[k].title ?? "")", fontSize: Constant.FontSize._13FontSize, fontStyle: .SemiBold, foregroundColor: dashBoardVM.selectedDrink?.id == dashBoardVM.arrWines[k].id && dashBoardVM.selectedDrink?.productType == dashBoardVM.arrWines[k].productType ? Color.AppWhite : Color.AppBlack)
                                        .padding(.bottom, 3)
                                    
                                    // Spacer()
                                    
                                    CommonText(title: "$\(dashBoardVM.arrWines[k].price ?? 0)", fontSize: Constant.FontSize._11FontSize, fontStyle: .SemiBold, foregroundColor: dashBoardVM.selectedDrink?.id == dashBoardVM.arrWines[k].id && dashBoardVM.selectedDrink?.productType == dashBoardVM.arrWines[k].productType ? Color.AppWhite : Color.AppCream)
                                    
                                }
                            }
                            .frame(width: 180, height: 100, alignment: .center)
                            //.padding(Constant.setSpace._10Padding)
                            .padding([.leading,.trailing], Constant.setSpace._8Padding)
                            .background(dashBoardVM.selectedDrink?.id == dashBoardVM.arrWines[k].id && dashBoardVM.selectedDrink?.productType == dashBoardVM.arrWines[k].productType ? Color.AppBrown : Color.AppGray)
                            .cornerRadius(12)
                            .onTapGesture {
                                withAnimation() {
                                    dashBoardVM.selectedDrink = dashBoardVM.arrWines[k]
                                    showsheet = true
                                }
                            }
                        }
                    }
                    .frame(height: 100)
                    .padding(.horizontal, Constant.setSpace._10Padding)
                }
                //}
            }
            .padding(.bottom, Constant.setSpace._30Padding)
        }
    }
}

extension DashboardView {
    func ThirdLayerView() -> some View {
        VStack {
            HStack {
                CommonText(title: "Wines", fontSize: Constant.FontSize._16FontSize, fontStyle: .SemiBold, foregroundColor: .AppDarkBlue)
                
                Spacer()
                
                Button(action: {
                    self.dashBoardVM.moveToListViewFromWines = true
                }, label: {
                    CommonText(title: "See All", fontSize: Constant.FontSize._14FontSize, fontStyle: .SemiBold, foregroundColor: Color.AppCream,action: {})
                        .underline(true,color:Color.AppCream)
                })
            }
            .padding([.bottom, .horizontal], Constant.setSpace._10Padding)
            
            HStack {
                ScrollView(.horizontal, showsIndicators: false) {
                    LazyHStack(spacing: 10) {
                        ForEach(0..<dashBoardVM.arrBeers.count, id: \.self) { i in
                            HStack {
                                VStack {
                                    WebImage(url: URL(string: dashBoardVM.arrBeers[i].image ?? ""))
                                        .resizable()
                                        .placeholder(Image("CoffeeMockup0"))
                                        .frame(width: Constant.setFrame._70Size, height: Constant.setFrame._70Size)
                                        .background(Color.AppWhite)
                                        .clipShape(Circle())
                                }
                                
                                VStack {
                                    CommonText(title: "\(dashBoardVM.arrBeers[i].title ?? "")", fontSize: Constant.FontSize._13FontSize, fontStyle: .SemiBold, foregroundColor: dashBoardVM.selectedDrink?.id == dashBoardVM.arrBeers[i].id && dashBoardVM.selectedDrink?.productType == dashBoardVM.arrBeers[i].productType ? Color.appWhite : Color.AppBlack)
                                        .padding(.bottom, 3)
                                    
                                    CommonText(title: "$\(dashBoardVM.arrBeers[i].price ?? 0)", fontSize: Constant.FontSize._11FontSize, fontStyle: .SemiBold, foregroundColor: dashBoardVM.selectedDrink?.id == dashBoardVM.arrBeers[i].id && dashBoardVM.selectedDrink?.productType == dashBoardVM.arrBeers[i].productType ? Color.AppWhite : Color.AppCream)
                                }
                            }
                            .frame(width: 180, height: 100, alignment: .center)
                            .padding([.leading,.trailing], Constant.setSpace._8Padding)
                            .background(dashBoardVM.selectedDrink?.id == dashBoardVM.arrBeers[i].id && dashBoardVM.selectedDrink?.productType == dashBoardVM.arrBeers[i].productType ? Color.AppBrown : Color.AppGray)
                            .cornerRadius(12)
                            .onTapGesture {
                                withAnimation() {
                                    dashBoardVM.selectedDrink = dashBoardVM.arrBeers[i]
                                    showsheet = true
                                }
                            }
                        }
                    }
                    .frame(height: 100)
                    .padding(.horizontal, 10)
                }
            }
        }
    }
}

extension DashboardView {
    func CategorySelectionView() -> some View {
        HStack{
            ScrollView(.horizontal,showsIndicators: false){
                LazyHStack{
                    ForEach(ProductType.allCases, id: \.self) { type in
                        HStack{
                            CommonText(
                                title: "\(type.title)",
                                fontSize: Constant.FontSize._14FontSize,
                                fontStyle: .SemiBold,
                                foregroundColor: selectedCategory == type.rawValue ? Color.AppWhite : Color.AppDarkerGray
                            )
                        }
                        .padding(Constant.setSpace._10Padding)
                        .background(selectedCategory == type.rawValue ? Color.AppBrown : Color.AppGray)
                        
                        .clipShape(.capsule)
                        .onTapGesture {
                            withAnimation(){
                                selectedCategory = type.rawValue
                            }
                            
                        }
                    }
                }
                .padding(.horizontal, 10)
            }
            .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.bottom,Constant.setSpace._20Padding)

    }
}
