//
//  FavouriteView.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 25/04/24.
//

import SwiftUI
import SDWebImageSwiftUI
struct FavouriteView: View {
    
    @EnvironmentObject var dashBoardVM: DashboardViewModel
    
    var body: some View {
        ZStack(alignment: .top) {
            VStack {
                ImageView()
                VStack {
                    HeaderView()
                        .padding(.bottom, Constant.setSpace._18Padding)
                    mainView()
                }
                .padding(Constant.setSpace._20Padding)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        }
        .onAppear{
            self.dashBoardVM.updateFavouriteList()
        }
        .ignoresSafeArea(.container, edges: .top)
        .navigationBarBackButtonHidden(true)
        .gesture(false ? DragGesture() : nil)
        
    }
}

#Preview {
    FavouriteView()
        
}

extension FavouriteView {
    func ImageView() -> some View {
        Image(Constant.Image.kDashboardHeader)
    }
}

extension FavouriteView {
    func HeaderView() -> some View{
        HStack {
            
            CommonText(title: Constant.AppString.kFavourite, fontSize: Constant.FontSize._20FontSize, fontStyle: .Bold)
            
            Spacer()
            
            Image(Constant.Image.kProfileIcon)
                .resizable()
                .frame(width: Constant.setFrame._40Size, height: Constant.setFrame._40Size)
            
            
        }
    }
}


extension FavouriteView {
    func mainView() -> some View {
        VStack(alignment: .leading) {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 15.0) {
                    ForEach(0..<dashBoardVM.arrFavourites.count, id: \.self) { i in
                        HStack(alignment: .top) {
                            WebImage(url: URL(string: dashBoardVM.arrFavourites[i].image ?? ""))
                                .resizable()
                                .placeholder(Image("CoffeeMockup"))
                                .frame(width: Constant.setFrame._70Size, height: Constant.setFrame._70Size)
                                .background(Color.appWhite)
                                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                                .padding(.trailing, Constant.setSpace._10Padding)
                            
                            VStack(alignment: .leading) {
                                CommonText(title: "\(dashBoardVM.arrFavourites[i].title ?? "")", fontSize: Constant.FontSize._15FontSize, fontStyle: .SemiBold, foregroundColor: Color.AppWhite)
                                    .padding(.bottom, Constant.setSpace._2Padding)
                               

                                CommonText(title: "$ \(dashBoardVM.arrFavourites[i].price ?? 0)", fontSize: Constant.FontSize._11FontSize, fontStyle: .SemiBold, foregroundColor: Color.AppWhite)
                                    .padding(.bottom, Constant.setSpace._2Padding)
                            }
                            .padding()
                        }
                        
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                        .background(Color.AppBrown)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .contextMenu {
                            Button(action: {
                                dashBoardVM.addToFavouritesTapped(selectedDrink: dashBoardVM.arrFavourites[i])
                            }) {
                                Text("Remove From Favourites")
                            }
                         }
                        .swipeActions(iconLast: (self.dashBoardVM.userModel?.favourites ?? "")
                            .contains(dashBoardVM.arrFavourites[i].productStr) ? "heart.fill" : "heart" ,  iconSecondLast: ""){ event in
                            dashBoardVM.addToFavouritesTapped(selectedDrink: dashBoardVM.arrFavourites[i])
                        }
                    }
                }
            }
        }
    }
}



//
//extension FavouriteView {
//    func validView() -> some View {
//        VStack(alignment: .leading) {
//            ScrollView(showsIndicators: false) {
//                LazyVStack(spacing: 10.0) {
//                    ForEach(0..<coffeeArr.count, id: \.self) { i in
//                        ZStack(alignment: .top) {
//                            Image("CoffeeMockup\(i)")
//                                .resizable()
//                                .frame(width: Constant.setFrame._70Size,height: Constant.setFrame._70Size)
//                                .background(Color.appCream)
//                                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
//                                .padding(.trailing, Constant.setSpace._10Padding)
//                            
//                            Spacer()
//                            
//                            Image("CoffeeMockup\(-i)")
//                                .resizable()
//                                .frame(width: Constant.setFrame._70Size, height: Constant.setFrame._70Size)
//                                .background(Color.pink)
//                                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
//                                .padding(.trailing, Constant.setSpace._10Padding)
//                        }
//                        .background(Color.appGray)
//                        .onTapGesture {
//                            withAnimation {
//                                scrollID = 0
//                            }
//                        }
//                    }
//                }
//                .scrollTargetLayout()
//            }
//            .contentMargins(10.0, for: .scrollContent)
//            .scrollPosition(id: $scrollID)
//        }
//    }
//}


