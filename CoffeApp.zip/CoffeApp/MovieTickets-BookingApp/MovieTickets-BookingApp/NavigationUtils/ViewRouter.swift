//
//  ViewRouter.swift
//  HailBooks
//
//  Created by differenz210 on 22/04/24.
//

import SwiftUI

/// `AppRouter`
///     - description: app router by which navigation is possible in swiftui
class ViewRouter<Page>: ObservableObject where Page: Hashable {
    
    @Published var root: Page
    @Published var path: [Page] = []
    @Published var popToPage: Page?
    
    /// `at initialization set the root view`
    init(root: Page) {
        self.root = root
    }
    
    /// `push to a specific view`
    func push(page appPage: Page) -> Void {
        self.path.append(appPage)
    }
    
    /// `pops back to previous view`
    func pop() -> Void {
        if !self.path.isEmpty {
            DispatchQueue.main.async {
                self.path.removeLast()
            }
        } else {
            print("Already in root")
        }
    }
    
    /// `pops back to a specific view`
    func pop(to appPage: Page) -> Void {
        guard let foundIdx = self.path.firstIndex(where: { $0 == appPage }) else { return }
        let idxToPop = (foundIdx ..< self.path.endIndex).count - 1
        
        self.path.removeLast(idxToPop)
    }
    
    ///`pops back to root view`
    func popToRoot() -> Void {
        self.path.removeAll()
    }
    
    /// `update root`
    func updateRoot(to root: Page) -> Void {
        self.path.removeAll()
        self.root = root
    }
    
    /// `build app page`
    func build(page appPage: AppPage) -> AnyView {
        
        switch appPage {
            
        case .splash:
            return AnyView(SplashView())
        }
    }
}

/// `AppPage`
/// - description: app route in the form of enum
enum AppPage: Hashable {
    
    case splash


    func hash(into hasher: inout Hasher) {
        
        switch self {
            
        case .splash:
            hasher.combine(1)
        }
    }
    
    static func == (lhs: AppPage, rhs: AppPage) -> Bool {
        if lhs.hashValue == rhs.hashValue {
            return true
        } else {
            return false
        }
    }
}

