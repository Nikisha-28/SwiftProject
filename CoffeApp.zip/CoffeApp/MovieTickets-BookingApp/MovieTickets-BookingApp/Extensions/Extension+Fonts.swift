//
//  Extension+Fonts.swift
//  ULeap
//
//  Created by Jaymeen on 14/12/23.
//

import Foundation
import UIKit
import SwiftUI

///`UIFont`
extension UIFont {
    static let alertTitle = UIFont(name: "HelveticaNeue-Medium", size: 17)
    static let alertMessage = UIFont(name: "HelveticaNeue", size: 13)
    static let alertTitleiPad = UIFont(name: "HelveticaNeue-Medium", size: 22)
    static let alertMessageiPad = UIFont(name: "HelveticaNeue", size: 18)
    static let regularTitle = UIFont(name: "HelveticaNeue", size: 17)
    static let regularTitleiPad = UIFont(name: "HelveticaNeue", size: 22)
    static let navigationBarTitle = UIFont(name: "HelveticaNeue-Light", size: 21)
    static let navigationBarTitleiPad = UIFont(name: "HelveticaNeue-Light", size: 26)
}

///`FontStyle`
enum FontStyle: String {
    case Black                            =  "Gilroy-Black"
    case BlackItalic                      =  "Gilroy-BlackItalic"
    case Bold                             =  "Gilroy-Bold"
    case BoldItalic                       =  "Gilroy-BoldItalic"
    case ExtraBold                        =  "Gilroy-ExtraBold"
    case ExtraBoldItalic                  =  "Gilroy-ExtraBoldItalic"
    case ExtraLight                       =  "Gilroy-UltraLight"
    case ExtraLightItalic                 =  "Gilroy-UltraLightItalic"
//    case Italic                           =  "Gilroy-Italic"
    case Light                            =  "Gilroy-Light"
//    case LightItalic                      =  "Gilroy-LightItalic"
    case Medium                           =  "Gilroy-Medium"
    case MediumItalic                     =  "Gilroy-MediumItalic"
    case Regular                          =  "Gilroy-Regular"
    case SemiBold                         =  "Gilroy-SemiBold"
    case SemiBoldItalic                   =  "Gilroy-SemiBoldItalic"
    case Thin                             =  "Gilroy-Thin"
    case ThinItalic                       =  "Gilroy-ThinItalic"
}

///`SetFont`
extension Font {
    static func setFont(style: FontStyle = .Regular, size: CGFloat = Constant.FontSize._16FontSize) -> Font {
        return .custom(style.rawValue, size: size)
    }
}

///`SetFont Function`
extension View {
    func setFont(style: FontStyle = .Regular, size: CGFloat = Constant.FontSize._16FontSize) -> some View {
        self
        .font(.setFont(style: style, size: size))
    }
}

