//
//  MessageModel.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 02/05/24.
//

import Foundation
import SwiftData

@Model
class MessageModel {
    var id: UUID
    var content: String
    var isCurrentUser: Bool
    var timestamp: Date

    init(id: UUID, content: String, isCurrentUser: Bool, timestamp: Date) {
        self.id = id
        self.content = content
        self.isCurrentUser = isCurrentUser
        self.timestamp = timestamp
    }
}
