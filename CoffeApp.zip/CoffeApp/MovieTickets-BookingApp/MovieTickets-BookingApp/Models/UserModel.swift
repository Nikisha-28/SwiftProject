//
//  UserModel.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 25/04/24.
//

import Foundation

struct UserModel: Codable {
    
    var uid : String?
    var name : String?
    var email : String?
    var password : String?
    var phoneNumber : String?
    var age : String?
    var city : String?
    var createdDate : String?
    var profileURL : String?
    var favourites : String?
    var cartItems : String?
    
    enum CodingKeys: CodingKey {
        case uid, name, email, password, phoneNumber, age, city, createdDate, profileURL, favourites, cartItems
    }
    
    init?(dictionary : [String : Any]) {
        
        self.uid = dictionary["uid"] as? String ?? ""
        self.name = dictionary["name"] as? String ?? ""
        self.password = dictionary["password"] as? String ?? ""
        self.email = dictionary["email"] as? String ?? ""
        self.phoneNumber = dictionary["phoneNumber"] as? String ?? ""
        self.age = dictionary["age"] as? String ?? ""
        self.city = dictionary["city"] as? String ?? ""
        self.createdDate = dictionary["createdDate"] as? String ?? ""
        self.favourites = dictionary["favourites"] as? String ?? ""
        self.cartItems = dictionary["cartItems"] as? String ?? ""
    }
}

/** Converts model into dictionary **/
extension UserModel {
    static func getUserInput(
        uid : String? = nil,
        name : String? = nil,
        email : String? = nil,
        password : String? = nil,
        phoneNumber : String? = nil,
        age : String? = nil,
        city : String? = nil,
        createdDate : String? = nil,
        profileURL : String? = nil
    ) -> [String:Any] {
        var dict: [String:Any] = [:]
        dict["uid"] = uid ?? ""
        dict["name"] = name ?? ""
        dict["email"] = email ?? ""
        dict["password"] = password ?? ""
        dict["phoneNumber"] = phoneNumber ?? ""
        dict["age"] = age ?? ""
        dict["city"] = city ?? ""
        dict["createdDate"] = createdDate ?? ""
        dict["profileURL"] = profileURL ?? ""
        return dict
    }
}

