//
//  CoffeeModel.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 26/04/24.
//

import Foundation

///ProductType 1 -- Coffee
///ProductType 2 -- Wine
///ProductType 3-- Beer

enum ProductType: Int, CaseIterable {
    case Coffee = 1
    case Wine = 2
    case Beer = 3
    
    var title: String {
        switch self {
        case .Coffee:
            "Coffee"
        case .Wine:
            "Wine"
        case .Beer:
            "Beer"
        }
    }
}

///`CoffeeModel
struct ProductModel: Codable, Identifiable {
    let title, description: String?
    let ingredients: [String]?
    let image: String?
    let id: Int?
    let productType: Int?
    let price: Int?
    var type: ProductType {
        return ProductType(rawValue: productType ?? 1)!
    }
    var productStr: String {
        return "\(type.title) - \(id ?? 0)"
    }
    
    init(
        title: String? = nil,
        description: String? = nil,
        ingredients: [String]? = nil,
        image: String? = nil,
        id: Int? = nil,
        productType: Int? = nil,
        price: Int? = nil
    ) {
        self.title = title
        self.description = description
        self.ingredients = ingredients
        self.image = image
        self.id = id
        self.productType = productType
        self.price = price
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.title = try container.decodeIfPresent(String.self, forKey: .title)
        self.description = try container.decodeIfPresent(String.self, forKey: .description)
        if let ing = try? container.decode(String.self, forKey: .ingredients) {
            self.ingredients = ing.components(separatedBy: ",").filter({!$0.isEmpty})
        } else {
            self.ingredients = try container.decodeIfPresent([String].self, forKey: .ingredients)
        }
        self.image = try container.decodeIfPresent(String.self, forKey: .image)
        self.id = try container.decodeIfPresent(Int.self, forKey: .id)
        self.productType = try container.decodeIfPresent(Int.self, forKey: .productType)
        self.price = try container.decodeIfPresent(Int.self, forKey: .price)
    }
}

extension ProductModel {
    func getDictionary(docID: String, for productType: ProductType) -> [String: Any] {
        let dict: [String: Any] = [
            "uid": docID,
            "id": self.id ?? "",
            "title": self.title ?? "",
            "ingredients": self.ingredients?.joined(separator: ",") ?? "",
            "image": self.image ?? "",
            "description": self.description ?? "",
            "productType": productType.rawValue,
            "price": Int.random(in: 40...60)
        ]
        return dict
    }
}

///`Decoding of JSON and conversion into ProductModel`
extension ProductModel {
    static func decodeFromJSONBundle() -> [ProductModel]? {
        guard let url = Bundle.main.url(forResource: "Wines", withExtension: "json") else {
            print("Coffee.json file not found")
            return nil
        }
        
        do {
            let jsonData = try Data(contentsOf: url)
            let coffees = try JSONDecoder().decode([ProductModel].self, from: jsonData)
            return coffees
        } catch {
            print("Error decoding JSON: \(error)")
        }
        return nil
    }
    
    static func decodeWinesJSONBundle() -> [ProductModel]? {
        guard let url = Bundle.main.url(forResource: "Wines", withExtension: "json") else {
            print("Coffee.json file not found")
            return nil
        }
        
        do {
            let jsonData = try Data(contentsOf: url)
            let wines = try JSONDecoder().decode([WinesModel].self, from: jsonData)
            return wines.map { wine in
                ProductModel(
                    title: wine.title,
                    description: wine.description,
                    ingredients: [],
                    image: wine.image,
                    id: wine.id,
                    productType: 2
                )
            }
        } catch {
            print("Error decoding JSON: \(error)")
        }
        return nil
    }  
    
    static func decodeBeersJSONBundle() -> [ProductModel]? {
        guard let url = Bundle.main.url(forResource: "Beers", withExtension: "json") else {
            print("Coffee.json file not found")
            return nil
        }
        
        do {
            let jsonData = try Data(contentsOf: url)
            let wines = try JSONDecoder().decode([WinesModel].self, from: jsonData)
            return wines.map { wine in
                ProductModel(
                    title: wine.title,
                    description: wine.description,
                    ingredients: [],
                    image: wine.image,
                    id: wine.id,
                    productType: 2
                )
            }
        } catch {
            print("Error decoding JSON: \(error)")
        }
        return nil
    }
}



