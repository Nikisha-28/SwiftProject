//
//  IsdModel.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 23/04/24.
//

import Foundation


// MARK: - Country
struct Country: Codable, Hashable {
    var code, name: String?
}

class IsdViewModel : ObservableObject {
    @Published var countries : [Country]  = []
    init() {
        loadData()
    }
    
    func loadData() {
        guard let url = Bundle.main.url(forResource: "ISDCode", withExtension: "json") else {
            print("isdCode.json file not found")
            return
        }
        
        do {
            let jsondata = try Data(contentsOf: url)
            let isds = try JSONDecoder().decode([Country].self, from: jsondata)
            self.countries = isds
        } catch {
            print("Error decoding JSON: \(error)")
            self.countries = []
        }
}}




