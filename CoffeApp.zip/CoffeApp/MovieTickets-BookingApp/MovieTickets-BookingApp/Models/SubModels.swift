//
//  SubModels.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 01/05/24.
//

import Foundation

// MARK: - WinesModel
struct WinesModel: Codable {
    let price: String?
    let title, description: String
    let rating: Rating
    let image: String
    let id: Int
}

// MARK: - Rating
struct Rating: Codable {
    let average: Double
    let reviews: Int
}
