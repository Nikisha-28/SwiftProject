//
//  MovieTickets_BookingAppApp.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 22/04/24.
//

import SwiftUI

@main
struct MovieTickets_BookingAppApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    @State private var alert: AlertData = AlertData.empty
    @State private var showAlert: Bool = false
    @State private var showLoader: Bool = false
    @StateObject var viewRouter = ViewRouter()
    @StateObject var globalVM: GlobalViewModel = GlobalViewModel.shared
    @StateObject var dashBoardVM : DashboardViewModel = DashboardViewModel()
    var body: some Scene {
        WindowGroup {
            WelcomeView()
                .onReceive(NotificationCenter.default.publisher(for: .showAlert)) { result in
                    if let alert = result.object as? AlertData {
                        self.alert = alert
                        self.showAlert = true
                    }
                }
                .onReceive(NotificationCenter.default.publisher(for: .showLoader)) { result in
                    if let loaderData = result.object as? [Any], let showLoader = loaderData.first as? Bool {
                        self.showLoader = showLoader
                    }
                }
                .activityIndicator(show: self.showLoader)

                .alert(isPresented: $showAlert) {
                    if self.alert.isLogOut == true {
                        return Alert(title: Text(alert.title), message: Text(alert.message), dismissButton: alert.dismissButton)
                    } else
                    {
                        return Alert(title: Text(alert.title), message: Text(alert.message), dismissButton: alert.dismissButton)
                    }
                    
                }
                .environmentObject(self.viewRouter)
                .environmentObject(self.globalVM)
                .environmentObject(self.dashBoardVM)
                .modelContainer(for: MessageModel.self)

        }
    }
}
