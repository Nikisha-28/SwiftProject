//
//  GifImageView.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 22/04/24.
//

import WebKit
import SwiftUI

struct GifImageView: UIViewRepresentable {
    private let name: String
    init(_ name: String) {
        self.name = name
    }
    
    func makeUIView(context: Context) -> WKWebView {
        let webview = WKWebView()
        let url = Bundle.main.url(forResource: name, withExtension: "gif")!
        let data = try! Data(contentsOf: url)
        webview.scrollView.setContentOffset(CGPoint(x: 0, y: (ScreenSize.SCREEN_HEIGHT - 260)/2), animated: false)
        webview.load(data,mimeType: "image/gif",characterEncodingName: "UTF-8", baseURL: url.deletingLastPathComponent())
        webview.scrollView.bounces = false
        webview.scrollView.showsVerticalScrollIndicator = false
        return webview
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {
        uiView.reload()
        uiView.scrollView.setContentOffset(CGPoint(x: 0, y: (ScreenSize.SCREEN_HEIGHT - 260)/2), animated: false)
    }
}
