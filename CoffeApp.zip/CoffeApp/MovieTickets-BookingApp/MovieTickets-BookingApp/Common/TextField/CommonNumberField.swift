//
//  CommonNumberField.swift
//  ULeap
//
//  Created by Jaymeen Unadkat on 15/12/23.
//

import SwiftUI

///`CommonNumberField`
struct CommonNumberField:View {
    @StateObject var isdVM : IsdViewModel = IsdViewModel()
    @Binding var shouldHavePicker : Bool
    @State var pickerIsThere = false
    @State var search : String = ""
    var font : FontStyle = .Bold
   @Binding var selection : Country
    var ImageOnLeft : String
    var heading : String
    var placeholder :String
    @Binding var text : String
    var body: some View {
        ZStack(alignment:.leading){
            HStack{
                Image(ImageOnLeft)
                if shouldHavePicker {
                    Text ("\(selection.code ?? "")")
                        .onTapGesture {
                            pickerIsThere = true
                        }
                }
                TextField("", text: $text,prompt:Text(placeholder).foregroundStyle(Color.black.opacity(0.5)))
                    .font(.setFont(style: font))
                    
            }
            .onChange(of: text) { i in
                text = String(self.text.prefix(10))
            }
            .frame(height: Constant.setSpace._30Padding)
            .bold()
            .padding()
            .overlay(RoundedRectangle(cornerRadius: 10.0).strokeBorder(Color.AppGray, style: StrokeStyle(lineWidth: 1.0)))
            
            HStack(spacing:0){
                Text(heading)
                    .font(.setFont(style: font,size: 13))
                    
                    .padding(.leading,Constant.setSpace._5Padding)
                    .textCase(.uppercase)
                Text("*")
                    .foregroundStyle(Color.red)
                    .padding(.trailing,Constant.setSpace._5Padding)
            }
            
            .background(.white)
            .padding(.horizontal)
            .padding(.top,-40)
            
                
           
            
            
        }
       
        .sheet(isPresented: $pickerIsThere, content: {
            PickerView()
                .presentationDetents([.height(250), .fraction(0.50)])
                .searchable(text: $search,placement:.navigationBarDrawer(displayMode: .always), prompt: "Your Country")
                .navigationBarTitle("Search", displayMode: .large)
                
                
        })
        
        
    }
}
#Preview {
    CommonNumberField(shouldHavePicker : .constant(false),selection: .constant(Country()), ImageOnLeft:Constant.Image.kTextFieldIconLeft,heading: "Name", placeholder: "test", text: .constant(""))
}

/**
 `DealerPickerView`
 */
extension CommonNumberField {
    func PickerView() -> some View {
        NavigationStack{
//        VStack {
//            if !isdVM.countries.isEmpty {
//                Picker("", selection: self.$selection) {
//                    
//                    ForEach(self.isdVM.countries, id: \.self) { country in
//                        Text("\(country.code ?? "")")
//                            .tag(country.code)
//                            .foregroundColor(.AppCream)
//                            .tint(.black)
//                    }
//                }
//                .pickerStyle(WheelPickerStyle())
//            }
//        }
        
            
            
            List(search.isEmpty ? self.isdVM.countries : self.isdVM.countries.filter{($0.name ?? "").localizedStandardContains(search)}, id: \.self){ country in
            HStack{
                Text("\(country.name ?? "")")
                    .foregroundStyle(Color.AppBrown)
                Spacer()
                Text("\(country.code ?? "")")
            }
            .background(Color.AppWhite.opacity(0.01))
            .foregroundColor(Color.AppCream)
            .onTapGesture {
               
                    
                    selection = country
                    
                    pickerIsThere = false
                    search = ""
                
                
            }
        }
            
        }
        
       
        
    }
}
