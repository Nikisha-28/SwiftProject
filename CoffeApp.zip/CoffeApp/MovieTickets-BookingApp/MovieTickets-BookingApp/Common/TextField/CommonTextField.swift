//
//  CommonTextField.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 25/04/24.
//

import SwiftUI

struct CommonTextField: View {
    @State var search : String = ""
    var font : FontStyle = .Bold
    var ImageOnLeft : String
    var heading : String
    var width : Double = 20
    var height : Double = 20
    var placeholder :String
    @Binding var text : String
    var body: some View {
        ZStack(alignment:.leading){
            HStack{
                Image(ImageOnLeft)
                    .resizable()
                    .scaledToFit()
                    .frame(width: width,height: height)
                TextField("", text: $text,prompt:Text(placeholder).foregroundStyle(Color.black.opacity(0.5)))
                    .font(.setFont(style: font))
                    .textInputAutocapitalization(.never)
                
            }
           
            .frame(height: Constant.setSpace._30Padding)
            .bold()
            .padding()
            .overlay(RoundedRectangle(cornerRadius: 10.0).strokeBorder(Color.AppGray, style: StrokeStyle(lineWidth: 1.0)))
            
            HStack(spacing:0){
                Text(heading)
                    .font(.setFont(style: font,size: 13))
                
                    .padding(.leading,Constant.setSpace._5Padding)
                    .textCase(.uppercase)
                Text("*")
                    .foregroundStyle(Color.red)
                    .padding(.trailing,Constant.setSpace._5Padding)
            }
            
            .background(.white)
            .padding(.horizontal)
            .padding(.top,-40)
            
            
            
            
        }
            
        }
}

#Preview {
    CommonTextField(ImageOnLeft: Constant.Image.kEmailicon, heading: "Email", placeholder: "Email@gmail.com", text: .constant(""))
}
