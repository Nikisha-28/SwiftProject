//
//  CommonSecureField.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 22/04/24.
//

import SwiftUI

struct CommonSecureField: View {
    @State var isHidden = true
    var font : FontStyle = .Bold
    var ImageOnLeft : String
    var heading : String
    var placeholder :String
    @Binding var text : String
    var body: some View {
        ZStack(alignment:.leading){
            HStack{
                Image(ImageOnLeft)
                if isHidden {
                    SecureField("", text: $text,prompt:Text(placeholder).foregroundStyle(Color.black.opacity(0.5)))
                        .font(.setFont(style: font))
                        .textInputAutocapitalization(.never)
                }
                else {
                    TextField("", text: $text,prompt:Text(placeholder).foregroundStyle(Color.black.opacity(0.5)))
                        .font(.setFont(style: font))
                        .textInputAutocapitalization(.never)
                }
                Button(
                    action:{
                        isHidden.toggle()
                    }){
                    isHidden ? Image(systemName: "eye.slash.fill").font(.system(size: 20)) : Image(systemName: "eye.fill").font(.system(size: 20))
                        
                }
                .foregroundColor(Color.AppDarkerGray)
                
            }
            
            .frame(height: Constant.setSpace._30Padding)
            .bold()
            .padding()
            .overlay(RoundedRectangle(cornerRadius: 10.0).strokeBorder(Color.AppGray, style: StrokeStyle(lineWidth: 1.0)))
            
            HStack(spacing:0){
                Text(heading)
                    .font(.setFont(style: font,size: 13))
                    .padding(.leading,Constant.setSpace._5Padding)
                    .textCase(.uppercase)
                Text("*")
                    .foregroundStyle(Color.red)
                    .padding(.trailing,Constant.setSpace._5Padding)
            }
            
            .background(.white)
            .padding(.horizontal)
            .padding(.top,-40)
            
                
                
            
        }
        
        
    }
}

#Preview {
    CommonSecureField(ImageOnLeft: Constant.Image.kTextFieldIconLeft, heading: "Password", placeholder: "", text: .constant(""))
}
