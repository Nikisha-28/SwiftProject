//
//  CommonImagePickerView.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 29/04/24.
//

import Foundation
import UIKit
import MobileCoreServices
import SwiftUI

struct CommonImagePickerView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let pickerControlller = UIImagePickerController()
        pickerControlller.sourceType = self.sourceType
        pickerControlller.mediaTypes = ["public.image"]
        pickerControlller.delegate = context.coordinator
        return pickerControlller
    }
    
    var sourceType: UIImagePickerController.SourceType = .camera
    
    @Binding var image: UIImage?
    @Binding var isPresented: Bool
    
    func makeCoordinator() -> ImagePickerViewCoordinator {
        return ImagePickerViewCoordinator(image: self.$image, isPresented: self.$isPresented)
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {
        //Nothing to update here
    }
}

class ImagePickerViewCoordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    @Binding var image: UIImage?
    @Binding var isPresented: Bool
    
    init(image: Binding<UIImage?>, isPresented: Binding<Bool>) {
        self._image = image
        self._isPresented = isPresented
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let image = info[.originalImage] as? UIImage {
            self.image = image
        }
        self.isPresented = false
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.isPresented = false
    }
}
