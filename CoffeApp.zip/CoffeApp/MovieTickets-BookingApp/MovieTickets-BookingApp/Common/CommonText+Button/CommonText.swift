//
//  CommonText.swift
//  TestProject
//
//  Created by Jaymeen Unadkat on 22/02/24.
//

import SwiftUI

///`CommonText`
struct CommonText: View {
    var title: String
    var fontSize: Double = Constant.FontSize._16FontSize
    var fontStyle: FontStyle = .Regular
    var foregroundColor: Color = Color.AppBlack
    var action: (() -> ())?
    var body: some View {
        Text(title)
            .foregroundStyle(foregroundColor)
            .setFont(style: fontStyle, size: fontSize)
    }
}

#Preview {
    CommonText(title: "LOGIN") {}
}

