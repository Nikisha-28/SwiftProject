//
//  CommonButton.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 22/04/24.
//

import SwiftUI

struct CommonButton: View {
    var font : FontStyle = .Bold
    var title : String
    var action : (() -> ())
    var body: some View {
        Button(action: action) {
          HStack {
              Spacer()
            Text(title)
                  .foregroundColor(Color.AppWhite)
                  .font(.setFont(style: font,size: 18))
                  .padding(.leading,Constant.setSpace._30Padding)
              Spacer()
              Image(Constant.Image.kForwardArrow) 
              .foregroundColor(.white)
              .padding()
             
              .background(Color.AppCream)
              .cornerRadius(100)
              .padding([.vertical,.trailing],Constant.setSpace._5Padding)
          }
        }
        
        .frame(maxWidth: .infinity)
        .background(Color.AppBrown)
        .cornerRadius(100)
        .padding()
    }
}

#Preview {
    CommonButton(title: "hi", action: {})
}
