//
//  AppDelegate.swift
//  HailBooks
//
//  Created by Pooja Sadariwala on 26/02/24.
//

import UIKit

///`AppDelegate`
class AppDelegate: NSObject, UIApplicationDelegate {

    var window: UIWindow?
    var appRouter: ViewRouter<AppPage>?
    private let notificationCenter = UNUserNotificationCenter.current()

    static var orientationLock = UIInterfaceOrientationMask.portrait
    
    func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
        return AppDelegate.orientationLock
    }

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        /**if UserDefaults.standard.bool(forKey: Constants.UserDefaultsKey.kIsUserLoggedIn) {
            let user = UserDefaults.getCurrentUserFromDefault()
            AppInstance.loggedInUser = user
            AppInstance.isUserLogin = true
        }*/
        return true
    }

}
    
