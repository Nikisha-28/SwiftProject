//
//  NavigationUtils.swift
//  ULeap
//
//  Created by Jaymeen on 20/12/23.
//

import Foundation
import UIKit
///`NavigationUtil`
struct NavigationUtil {
    
    static func getNavigationController() -> UINavigationController? {
        guard let window = UIApplication.shared.keyWindow else { return nil }
        guard let rootViewController = window.rootViewController else { return nil }
        guard let navigationController = findNavigationController(viewController: rootViewController) else { return nil }
        return navigationController
      }
    
    static func popToView(_ identifier: String) -> Bool {
       guard let navigationController = getNavigationController() else {
           return false
       }
       
       for vc in navigationController.children {
           if vc.navigationItem.title == identifier {
               navigationController.popToViewController(vc, animated: true)
               return true
           }
       }
        return false
     }
    
    ///`PopToRootView`
    static func popToRootView() {
            findNavigationController(viewController: UIApplication.keyWindow?.rootViewController)?.popToRootViewController(animated: true)
    }
    
    static func findNavigationController(viewController: UIViewController?) -> UINavigationController? {
        
        guard let viewController = viewController else {
            return nil
        }
        
        if let navigationController = viewController as? UINavigationController {
            return navigationController
            
        }
        for childViewController in viewController.children {
            return findNavigationController(viewController: childViewController)
        }
        return nil
    }
}

// MARK: - UIApplication Extensions
extension UIApplication {
    /// `returns keyWindows from UIWindowScenes`
    static var keyWindow: UIWindow? {
        return self.shared.connectedScenes
            .filter({ $0.activationState == .foregroundActive })
            .first(where: { $0 is UIWindowScene })
            .flatMap({ $0 as? UIWindowScene })?.windows
            .first(where: \.isKeyWindow)
    }
}

extension NavigationUtil {
    static func popTabIndexViews(to index: Int) {
         let tabbarVC = findTabController(viewController: UIApplication.keyWindow?.rootViewController)
        
        guard index < tabbarVC?.viewControllers?.count ?? 0 else { return }
        
        if let navVC = (tabbarVC?.viewControllers ?? [])[index].children.first as? UINavigationController {
            navVC.popToRootViewController(animated: true)
        } else { return }
        
        /*?.popToRootViewController(animated: true)*/
        
    }
    
    static func findTabController(viewController: UIViewController?) -> UITabBarController? {
        
        guard let viewController = viewController else {
            return nil
        }
        
        if let navigationController = viewController as? UITabBarController {
            return navigationController
            
        }
        for childViewController in viewController.children {
            return findTabController(viewController: childViewController)
        }
        return nil
    }

}


extension UIApplication {
    var keyWindow: UIWindow? {
        connectedScenes
            .compactMap {
                $0 as? UIWindowScene
            }
            .flatMap {
                $0.windows
            }
            .first {
                $0.isKeyWindow
            }
    }
}
