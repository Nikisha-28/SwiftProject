//
//  ViewRouter.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 26/04/24.
//

import Foundation

///`ViewRouter`
class ViewRouter: ObservableObject {
    @Published var currentView: AppView = UserDefaults.standard.bool(forKey: UserDefaultsKey.kIsLogin) ? .Home : .Login
    @Published var isLoggedIn: Bool = false
    @Published var tabSelecteionIndex: Int = 0

}
    ///`AppView`
enum AppView {
    case Login, Home
}
