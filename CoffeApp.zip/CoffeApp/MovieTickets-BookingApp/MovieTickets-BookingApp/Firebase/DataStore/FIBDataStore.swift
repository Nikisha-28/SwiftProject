//
//  FIBDataStore.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 25/04/24.
//

import Foundation
import FirebaseFirestore

enum FireStoreCollections: String {
    case users  = "Users"
    case master = "Master"
}



class FIBDataStore {
    let db: Firestore = Firestore.firestore()
    private init() {}
    static let shared: FIBDataStore = FIBDataStore()
}

extension FIBDataStore {
    func getUserData(for userID: String, completion: @escaping ((UserModel?) -> ())) {
        self.db.getCollection(.users).document(userID).getDocument { snapshot, error in
            if let error = error as? NSError {
                print("error getting the chat room data with documentId: \(userID), error: \(error.localizedDescription)")
                Indicator.hide()
                completion(nil)
            } else {
                guard let document = snapshot else { return }
                
                do {
                    let messageModel = try document.data(as: UserModel.self)
                    Indicator.hide()
                    completion(messageModel)
                } catch DecodingError.keyNotFound(let key, let context) {
                    print("could not find key \(key) in JSON: \(context.debugDescription)")
                } catch DecodingError.valueNotFound(let type, let context) {
                    print("could not find type \(type) in JSON: \(context.debugDescription)")
                } catch DecodingError.typeMismatch(let type, let context) {
                    print("type mismatch for type \(type) in JSON: \(context.debugDescription)")
                } catch DecodingError.dataCorrupted(let context) {
                    print("data found to be corrupted in JSON: \(context.debugDescription)")
                } catch let error {
                    print("Error in read(from:ofType:) description= \(error.localizedDescription)")
                }
            }
        }
    }
}

extension FIBDataStore {
    func setUserData(for userID: String, userInfoDict: [String: Any], completion: @escaping (() -> ())) {
        self.db.getCollection(.users).document(userID).setData(userInfoDict) { error in
            if let error = error as? NSError {
                Indicator.hide()
                print("error getting the chat room data with documentId: \(userID), error: \(error.localizedDescription)")
            } else {
                completion()
            }
        }
    }
}

/// `returns collection from rawValue of enum`
extension Firestore {
    func getCollection(_ collectionPath: FireStoreCollections) -> CollectionReference {
        self.collection(collectionPath.rawValue)
    }
}

