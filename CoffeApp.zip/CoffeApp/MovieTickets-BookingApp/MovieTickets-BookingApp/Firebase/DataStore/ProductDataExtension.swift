//
//  ProductDataExtension.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 26/04/24.
//

import Foundation


extension FIBDataStore {
    func saveCoffeesData() {
        let masterCollectionRef = self.db.getCollection(.master)
        if let coffeesData: [ProductModel] = ProductModel.decodeFromJSONBundle() {
            let batch = self.db.batch()
            coffeesData.forEach { coffeeModel in
                let docID: String = "Coffee-\(UUID().uuidString)"
                let coffeeObject = masterCollectionRef.document(docID)
                batch.setData(coffeeModel.getDictionary(docID: docID, for: .Coffee), forDocument: coffeeObject)
            }
            batch.commit(completion: { (error) in
                if let error = error {
                    print("\(error)")
                } else {
                    print("success")
                }
            })
        }
    }
}

extension FIBDataStore {
    func saveWinesData() {
        let masterCollectionRef = self.db.getCollection(.master)
        if let coffeesData: [ProductModel] = ProductModel.decodeWinesJSONBundle() {
            let batch = self.db.batch()
            coffeesData.forEach { coffeeModel in
                let docID: String = "Wine-\(UUID().uuidString)"
                let coffeeObject = masterCollectionRef.document(docID)
                batch.setData(coffeeModel.getDictionary(docID: docID, for: .Wine), forDocument: coffeeObject)
            }
            batch.commit(completion: { (error) in
                if let error = error {
                    print("\(error)")
                } else {
                    print("success")
                }
            })
        }
    }
}


extension FIBDataStore {
    func saveBeersData() {
        let masterCollectionRef = self.db.getCollection(.master)
        if let coffeesData: [ProductModel] = ProductModel.decodeBeersJSONBundle() {
            let batch = self.db.batch()
            coffeesData.forEach { coffeeModel in
                let docID: String = "Beer-\(UUID().uuidString)"
                let coffeeObject = masterCollectionRef.document(docID)
                batch.setData(coffeeModel.getDictionary(docID: docID, for: .Beer), forDocument: coffeeObject)
            }
            batch.commit(completion: { (error) in
                if let error = error {
                    print("\(error)")
                } else {
                    print("success")
                }
            })
        }
    }
    
    func getProducts(productType: ProductType, completion: @escaping (_ coffees: [ProductModel]?) -> ()) {
        self.db.getCollection(.master).whereField("productType", isEqualTo: productType.rawValue).addSnapshotListener { querySnapshot, error -> Void in
            Indicator.hide()
            guard let documents = querySnapshot?.documents else { return }
            let coffeeList: [ProductModel] = documents.compactMap({ snapshot -> ProductModel? in
                do {
                    return try snapshot.data(as: ProductModel.self)
                } catch let error {
                    print("error decoding message data with documentId, error: \(error.localizedDescription)")
                    return nil
                }
            })
            completion(coffeeList)
        }
    }
    
    
}
