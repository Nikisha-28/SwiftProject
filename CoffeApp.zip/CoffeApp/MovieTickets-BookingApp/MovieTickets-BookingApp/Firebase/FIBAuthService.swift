//
//  FIBAuthService.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 25/04/24.
//

import Foundation
import FirebaseAuth
import SwiftUI

final class FIBAuthService: ObservableObject {
    static let shared: FIBAuthService = FIBAuthService()
    private var fibUser: User?
    private var currentUser: UserModel?
    private init() {}
}

/**
 `Auth functions of firebase`
 */
extension FIBAuthService {
    func signIn(with email: String, and password: String, completion: @escaping ((_ userModel: UserModel?) -> ())) {
        Auth.auth().signIn(withEmail: email, password: password) { (result, error) in
            guard error == nil
            else {
                self.handleError(error!)
                Indicator.hide()
                return
            }
            
            guard let user = result?.user else { Indicator.hide()
                return }
            self.fibUser = user
            FIBDataStore.shared.getUserData(for: user.uid) { userModel in
                Indicator.hide()
                UserDefaults.standard.loginUser = userModel
                UserDefaults.isLoggedIn = true
                completion(userModel)
            }
        }
    }
}

extension FIBAuthService {
    func signUp(
        email : String,
        password : String,
        completion: @escaping (_ userModel: UserModel?) -> Void
    ) {
        Auth.auth().createUser(withEmail: email, password: password) { (result, error) in
            guard error == nil
            else {
                Indicator.hide()
                self.handleError(error!)
                return
            }

            guard let user = result?.user else { Indicator.hide()
                return }
            
            print("User \(user.email ?? "") signed up with UID ===> \(user.uid)")
            let userDict: [String: Any] = UserModel.getUserInput(
                uid: user.uid,
                email: email,
                password: password,
                createdDate: Date().formatted()
            )

            FIBDataStore.shared.setUserData(for: user.uid, userInfoDict: userDict) {
                Indicator.hide()
                UserDefaults.standard.loginUser = UserModel(dictionary: userDict)
                UserDefaults.isLoggedIn = true
                completion(UserModel(dictionary: userDict))
            }
        }
    }
    
    func logoutUser(completion: (() -> ())) {
        do {
            try Auth.auth().signOut()
            completion()
        } catch {
            Alert.show(message: error.localizedDescription)
        }
    }
}

extension FIBAuthService {
    func handleError(_ error: Error) {
        print(error.localizedDescription)
        Alert.show(message: error.localizedDescription)
    }
}
