//
//  GlobalViewModel.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 02/05/24.
//

import Foundation
import Firebase

///`GlobalViewModel`
class GlobalViewModel: ObservableObject {
    private init() {}
    
    static var shared: GlobalViewModel = GlobalViewModel()
    @Published var userModel: UserModel? = nil
    var userListner: ListenerRegistration? = nil
}

extension GlobalViewModel {
    func getUserDataInRealTime(completion: @escaping ((UserModel) -> ())) {
        guard self.userListner == nil else { return }
        ///FIBDataStore.shared.db.getCollection(.users).whereField("uid", isEqualTo: UserDefaults.standard.loginUser?.uid ?? "").addSnapshotListener { snapshot, error -> Void in
            FIBDataStore.shared.db.getCollection(.users).document(UserDefaults.standard.loginUser?.uid ?? "").addSnapshotListener { snapshot, error -> Void in
            if let error = error as? NSError {
                print("error getting the chat room data with userID: \(UserDefaults.standard.loginUser?.uid ?? ""), error: \(error.localizedDescription)")
            } else {
                guard let document = snapshot else { return }
                do {
                    let userModel = try document.data(as: UserModel.self)
                    self.userModel = userModel
                    completion(userModel)
                } catch DecodingError.keyNotFound(let key, let context) {
                    print("could not find key \(key) in JSON: \(context.debugDescription)")
                } catch DecodingError.valueNotFound(let type, let context) {
                    print("could not find type \(type) in JSON: \(context.debugDescription)")
                } catch DecodingError.typeMismatch(let type, let context) {
                    print("type mismatch for type \(type) in JSON: \(context.debugDescription)")
                } catch DecodingError.dataCorrupted(let context) {
                    print("data found to be corrupted in JSON: \(context.debugDescription)")
                } catch let error {
                    print("Error in read(from:ofType:) description= \(error.localizedDescription)")
                }
            }
        }
    }
}

extension GlobalViewModel {
    func updateUserData(with dict: [String: Any], completion: @escaping (() -> ())) {
        FIBDataStore.shared.db.getCollection(.users).document(UserDefaults.standard.loginUser?.uid ?? "").updateData(dict) { error in
            print("Data update error >>> \(error?.localizedDescription ?? "")")
        }
    }
}

