//
//  RegisterViewModel.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 23/04/24.
//



import Foundation
import SwiftUI

class RegisterViewModel: ObservableObject {
    
    /// `Declarations`
    @Published var txtEmail: String = ""
    @Published var txtPassword: String = ""
    @Published var txtRePassword: String = ""
    
    
    
    func onBtnSignUp_Click(completion: @escaping (() -> Void)) {
        if self.inputValidate() {
            Indicator.show()
            FIBAuthService.shared.signUp(email: txtEmail, password: txtPassword) { userModel in
                completion()
            }
        }
    }
    
}
extension RegisterViewModel {
    
    func inputValidate() -> Bool {
        if txtEmail.isEmptyOrNull(txtEmail) {
            Alert.show(message: Constant.ErrorMessageString.kEmptyEmail)
            return false
        }
        if !txtEmail.isValidEmail() {
            Alert.show(message: Constant.ErrorMessageString.kValidEmail)
            return false
        }
        
        if txtPassword.isEmptyOrNull(txtPassword) {
            Alert.show(message: Constant.ErrorMessageString.kEmptyPassword)
            return false
        }
        
        if (txtPassword.count < 8)  {
            Alert.show(message: Constant.ErrorMessageString.kValidPasswordLength)
            return false
        }
        
        if !txtPassword.isValidPassword()  {
            Alert.show(message: Constant.ErrorMessageString.kValidPassword)
            return false
        }
        if txtPassword != txtRePassword  {
            Alert.show(message: Constant.ErrorMessageString.kPasswordDoesNotMatch)
            return false
        }
        return true
    }

}
