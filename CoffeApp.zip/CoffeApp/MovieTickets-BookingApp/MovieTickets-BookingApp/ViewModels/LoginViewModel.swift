//
//  LoginViewModel.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 23/04/24.
//

import Foundation
import SwiftUI

class LoginViewModel: ObservableObject {
    
    /// `Declarations`
    @Published var txtEmail: String = ""
    @Published var txtPassword: String = ""
    @Published var moveToReigsterView = false
    
    func onBtnSignIn_Click(completion: @escaping (() -> Void)) {
        if self.inputValidate() {
            Indicator.show()
            FIBAuthService.shared.signIn(with: txtEmail, and: txtPassword) { userModel in
                completion()
            }
        }
    }
    
}
extension LoginViewModel {
    
    func inputValidate() -> Bool {
        if txtEmail.isEmptyOrNull(txtEmail) {
            Alert.show(message: Constant.ErrorMessageString.kEmptyPhoneNumber)
            return false
        }
        if !txtEmail.isValidEmail() {
            Alert.show(message: Constant.ErrorMessageString.kValidEmail)
            return false
        }
        
        if txtPassword.isEmptyOrNull(txtPassword) {
            Alert.show(message: Constant.ErrorMessageString.kEmptyPassword)
            return false
        }
        
        if (txtPassword.count < 8)  {
            Alert.show(message: Constant.ErrorMessageString.kValidPasswordLength)
            return false
        }
        
        if !txtPassword.isValidPassword()  {
            Alert.show(message: Constant.ErrorMessageString.kValidPassword)
            return false
        }
        return true
    }

}
