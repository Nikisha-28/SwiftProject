//
//  DashboardViewModel.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 01/05/24.
//

import Foundation

class DashboardViewModel: ObservableObject {
    @Published var arrCoffees: [ProductModel] = []
    @Published var arrWines: [ProductModel] = []
    @Published var arrBeers: [ProductModel] = []
    @Published var arrFavourites: [ProductModel] = []
    @Published var arrCartItems: [ProductModel] = []
    
    @Published var moveToListViewFromBeers = false
    @Published var moveToListViewFromWines = false
    @Published var moveToListViewFromCoffee = false
    @Published var moveToDetailView = false

    @Published var selectedDrink: ProductModel? = nil
    @Published var favourites : String = ""
    @Published var userModel: UserModel? = nil
}

extension DashboardViewModel {
    func getProductData() {
        Indicator.show()
        self.getCoffees {
            self.getWines {
                self.getBeers {
                    
                }
            }
        }
    }
}

///`Getting subproducts`
extension DashboardViewModel {
    ///`getCoffees`
    func getCoffees(completion: @escaping () -> Void) {
        FIBDataStore.shared.getProducts(productType: .Coffee) { coffees in
            self.arrCoffees = coffees ?? []
            completion()
        }
    }
    
    ///`getCoffees`
    func getWines(completion: @escaping () -> Void) {
        FIBDataStore.shared.getProducts(productType: .Wine) { coffees in
            self.arrWines = coffees ?? []
            completion()
        }
    }

    ///`getCoffees`
    func getBeers(completion: @escaping () -> Void) {
        FIBDataStore.shared.getProducts(productType: .Beer) { coffees in
            self.arrBeers = coffees ?? []
            completion()
        }
    }

}

extension DashboardViewModel {
    func addToFavouritesTapped(selectedDrink: ProductModel?) {
        let type = ProductType(rawValue: selectedDrink?.productType ?? 1) ?? .Coffee
        let productID = selectedDrink?.id ?? 0
        let productStr = "\(type) - \(productID)"

        if  (userModel?.favourites ?? "").contains(productStr) { /// `Product is in favourites`
            deleteProductFromFavourites(productID: productStr)
        }
        else {
            addProductToFavourites(productID: productStr) ///`Product is not in favourites`
        }
    }
    
    func addToCartTapped( selectedDrink: ProductModel?) {
        let type = ProductType(rawValue: selectedDrink?.productType ?? 1) ?? .Coffee
        let productID = selectedDrink?.id ?? 0
        let productStr = "\(type) - \(productID)"

        if  (userModel?.cartItems ?? "").contains(productStr) { /// `Product is in favourites`
            deleteProductFromCart(productID: productStr)
        }
        else {
            addProductToCart(productID: productStr) ///`Product is not in favourites`
        }
    }
}

///`getUserDataInRealTime`
extension DashboardViewModel {
    func getUserDataInRealTime() {
        GlobalViewModel.shared.getUserDataInRealTime { userModel in
            self.userModel = userModel
            self.updateFavouriteList()
            self.updateCartList()
        }
    }
}

extension DashboardViewModel {
    func deleteProductFromFavourites(productID: String) {
        var commaSeparatedArray: [String] = (self.userModel?.favourites?.commaSeparatedArray ?? [])
        commaSeparatedArray.removeAll(where: {$0 == productID})
        let newSeparetedString: String = commaSeparatedArray.joined(separator: ",")
        
        let dictionaryToUpdate: [String: Any] = [
            "favourites": newSeparetedString
        ]
        GlobalViewModel.shared.updateUserData(with: dictionaryToUpdate) {}

    }
    
    func addProductToFavourites(productID: String) {
        var commaSeparatedArray: [String] = (self.userModel?.favourites?.commaSeparatedArray ?? [])
        commaSeparatedArray.append(productID)
        let newSeparetedString: String = commaSeparatedArray.joined(separator: ",")
        
        let dictionaryToUpdate: [String: Any] = [
            "favourites": newSeparetedString
        ]
        GlobalViewModel.shared.updateUserData(with: dictionaryToUpdate) {}
    }

    func deleteProductFromCart(productID: String) {
        var commaSeparatedArray: [String] = (self.userModel?.cartItems?.commaSeparatedArray ?? [])
        commaSeparatedArray.removeAll(where: {$0 == productID})
        let newSeparetedString: String = commaSeparatedArray.joined(separator: ",")
        
        let dictionaryToUpdate: [String: Any] = [
            "cartItems": newSeparetedString
        ]
        GlobalViewModel.shared.updateUserData(with: dictionaryToUpdate) {}

    }
    
    func addProductToCart(productID: String) {
        var commaSeparatedArray: [String] = (self.userModel?.cartItems?.commaSeparatedArray ?? [])
        commaSeparatedArray.append(productID)
        let newSeparetedString: String = commaSeparatedArray.joined(separator: ",")
        
        let dictionaryToUpdate: [String: Any] = [
            "cartItems": newSeparetedString
        ]
        GlobalViewModel.shared.updateUserData(with: dictionaryToUpdate) {}
    }

}

extension String {
    var commaSeparatedArray: [String] {
        return self.components(separatedBy: ",").filter({!$0.isEmpty})
    }
}

extension DashboardViewModel {
    func updateFavouriteList() {
        let totalProducts = self.arrCoffees + self.arrBeers + self.arrWines
        let arrProdctStr = self.userModel?.favourites?.commaSeparatedArray ?? []
        self.arrFavourites  = totalProducts.filter { product in
            let productStr = product.productStr
            return arrProdctStr.contains(productStr)
        }
        let d = 0
    }
    
    func updateCartList() {
        let totalProducts = self.arrCoffees + self.arrBeers + self.arrWines
        let arrProdctStr = self.userModel?.cartItems?.commaSeparatedArray ?? []
        self.arrCartItems  = totalProducts.filter { product in
            let productStr = product.productStr
            return arrProdctStr.contains(productStr)
        }
        let d = 0
    }
}
