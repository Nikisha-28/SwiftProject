//
//  ProfileViewModel.swift
//  MovieTickets-BookingApp
//
//  Created by Jaymeen Unadkat on 29/04/24.
//

import Foundation
import SwiftUI

class ProfileViewModel: ObservableObject {
    
    @Published var txtName: String = "Willium John"
    @Published var txtEmail: String = "William@gmail.com"
    @Published var txtAddress: String = "09 Surf Parade, Alaska Street"
    @Published var txtContactNo: String = "+91 9745612389"
    @Published var txtGender: String = "Male"
    @Published var txtCity: String = "Pune"
    @Published var isPresentCamera = false
    @Published var isShowingImagePicker = false
    @Published var selectedImage: UIImage?
}

extension ProfileViewModel {
    
    func inputValidate() -> Bool {
        if self.txtName.trimWhiteSpace.isEmpty {
            Alert.show(message: Constant.ErrorMessageString.kEmptyName)
            return false
        } else if !self.txtName.isValidString() {
            Alert.show(message: Constant.ErrorMessageString.kValidName)
            return false
        } else if self.txtEmail.trimWhiteSpace.isEmpty {
            Alert.show(message: Constant.ErrorMessageString.kEmptyEmail)
            return false
        } else if !self.txtEmail.isValidEmail() {
            Alert.show(message: Constant.ErrorMessageString.kValidEmail)
            return false
        } else if self.txtAddress.trimWhiteSpace.isEmpty {
            Alert.show(message: Constant.ErrorMessageString.kEmptyAddress)
            return false
        } else if self.txtContactNo.trimWhiteSpace.isEmpty {
            Alert.show(message: Constant.ErrorMessageString.kEmptyNo)
            return false
        } else if !self.txtContactNo.isValidPhoneNumber() {
            Alert.show(message: Constant.ErrorMessageString.kValidNo)
            return false
        } else if self.txtGender.trimWhiteSpace.isEmpty {
            Alert.show(message: Constant.ErrorMessageString.kEmptyGender)
            return false
        } else if !self.txtGender.isValidString() {
            Alert.show(message: Constant.ErrorMessageString.kValidGender)
            return false
        } else if self.txtCity.trimWhiteSpace.isEmpty {
            Alert.show(message: Constant.ErrorMessageString.kEmptyCity)
            return false
        } else if !self.txtCity.isValidString() {
            Alert.show(message: Constant.ErrorMessageString.kValidCity)
            return false
        }
        return true
    }
    
}

extension ProfileViewModel {
    func editProfileClick() {
        if self.inputValidate() {
            
        }
    }
}

