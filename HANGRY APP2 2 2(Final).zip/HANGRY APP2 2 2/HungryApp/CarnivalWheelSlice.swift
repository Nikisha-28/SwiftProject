//
//  CarnivalWheelSlice.swift
//  HungryApp
//
//  Created by differenz152 on 31/03/23.
//

import Foundation
import TTFortuneWheel

public class CarnivalWheelSlice: FortuneWheelSliceProtocol {
    
    public enum Style {
        case brickRed
        case sandYellow
        case babyBlue
        case deepBlue
        case green
    }
    
    public var title: String
    public var degree: CGFloat = 0.0
    
    public var backgroundColor: UIColor? {
        switch style {
        case .sandYellow: return TTUtils.uiColor(from:0xFF9900)//0xF7D565 - orange  #4863A0
        case .brickRed: return TTUtils.uiColor(from:0x4863A0) //0xE27230  - blue
        case .babyBlue: return TTUtils.uiColor(from:0x800080)//0x93D0C4   - purple  6600CC
        case .green: return TTUtils.uiColor(from: 0x008000) // - green
        case .deepBlue: return TTUtils.uiColor(from:0xFF3399)//0x2A7F7F   - pink
        }
    }
    
    public var fontColor: UIColor {
        return UIColor.white
    }
    
    public var offsetFromExterior:CGFloat {
        return 25.0
    }
    
    public var font: UIFont {
        return UIFont.systemFont(ofSize: 19)
    }
    
    public var stroke: StrokeInfo? {
        return StrokeInfo(color: UIColor.white, width: 0.0)
    }
    
    public var style:Style = .brickRed
    
    public init(title:String) {
        self.title = title
    }
    
    public convenience init(title:String, degree:CGFloat) {
        self.init(title:title)
        self.degree = degree
    }
    
}
