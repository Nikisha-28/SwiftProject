//
//  JSONMODEL.swift
//  HungryApp
//
//  Created by differenz152 on 10/04/23.
//

import Foundation
import UIKit
// MARK: - MyData

struct MyData: Codable {
    let htmlAttributions: [String]
    let results: [Result]
    let status: String

    enum CodingKeys: String, CodingKey {
        case htmlAttributions = "html_attributions"
        case results, status
    }
}

// MARK: - Result
struct Result: Codable {
    let businessStatus: BusinessStatus
    let geometry: Geometry
    let icon: String
    let iconBackgroundColor: IconBackgroundColor
    let iconMaskBaseURI: String
    let name: String
    let openingHours: OpeningHours?
    let placeID: String
    let plusCode: PlusCode?
    let rating: Double
    let reference: String
    let scope: Scope
    let types: [TypeElement]
    let userRatingsTotal: Int
    let vicinity: String
    let photos: [Photo]?
    let priceLevel: Int?

    enum CodingKeys: String, CodingKey {
        case businessStatus = "business_status"
        case geometry, icon
        case iconBackgroundColor = "icon_background_color"
        case iconMaskBaseURI = "icon_mask_base_uri"
        case name
        case openingHours = "opening_hours"
        case placeID = "place_id"
        case plusCode = "plus_code"
        case rating, reference, scope, types
        case userRatingsTotal = "user_ratings_total"
        case vicinity, photos
        case priceLevel = "price_level"
    }
}

enum BusinessStatus: String, Codable {
    case operational = "OPERATIONAL"
}
// MARK: - Geometry
struct Geometry: Codable {
    let location: Location
    let viewport: Viewport
}

// MARK: - Location
struct Location: Codable {
    let lat, lng: Double
}

// MARK: - Viewport
struct Viewport: Codable {
    let northeast, southwest: Location
}

enum IconBackgroundColor: String, Codable {
    case ff9E67 = "#FF9E67"
}

// MARK: - OpeningHours
struct OpeningHours: Codable {
    let openNow: Bool

    enum CodingKeys: String, CodingKey {
        case openNow = "open_now"
    }
}

// MARK: - Photo
struct Photo: Codable {
    let height: Int
    let htmlAttributions: [String]
    let photoReference: String
    let width: Int

    enum CodingKeys: String, CodingKey {
        case height
        case htmlAttributions = "html_attributions"
        case photoReference = "photo_reference"
        case width
    }
}

// MARK: - PlusCode
struct PlusCode: Codable {
    let compoundCode, globalCode: String

    enum CodingKeys: String, CodingKey {
        case compoundCode = "compound_code"
        case globalCode = "global_code"
    }
}

enum Scope: String, Codable {
    case google = "GOOGLE"
}

enum TypeElement: String, Codable {
    case cafe = "cafe"
    case establishment = "establishment"
    case food = "food"
    case groceryOrSupermarket = "grocery_or_supermarket"
    case mealDelivery = "meal_delivery"
    case mealTakeaway = "meal_takeaway"
    case pointOfInterest = "point_of_interest"
    case restaurant = "restaurant"
    case store = "store"
}
