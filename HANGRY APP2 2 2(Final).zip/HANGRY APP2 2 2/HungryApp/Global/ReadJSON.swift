//
//  ReadJSON.swift
//  HungryApp
//
//  Created by differenz152 on 10/04/23.
//

import Foundation
import UIKit

public class DataLoader{
    
    func readLocalFile(forName: String) -> Data? {
        do {
            if let bundlePath = Bundle.main.path(forResource: forName, ofType: "json"),
                let jsonData = try String(contentsOfFile: bundlePath).data(using: .utf8) {
                return jsonData
            }
        } catch {
            print(error)
        }
        return nil
    }

    func parse(jsonData: Data) -> MyData? {
        do {
            let decodedData = try JSONDecoder().decode(MyData.self,
                                                       from: jsonData)
            return decodedData
            
        } catch {
            print("decode error")
        }
        return nil
    }
   
}
