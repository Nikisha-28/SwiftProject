//
//  Extension.swift
//  HungryApp
//
//  Created by differenz152 on 22/03/23.
//

import Foundation
import UIKit

extension UIViewController {
    
    func alert(message: String, title: String = "") {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
        
    }
    
    func isValidPhone(phno : String) -> Bool {  //Check Phone Number
        let mobileTrimmedString = phno.trimmingCharacters(in: .whitespaces) //Trim white spaces
        let phoneNumberRegex = "^[6-9]\\d{9}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", phoneNumberRegex)
        let isValidPhone = phoneTest.evaluate(with: mobileTrimmedString)
        return isValidPhone
    }
    
    
    func isvalidateEmail(email : String) -> Bool {  //Check Email address
        let string = email.trimmingCharacters(in: .whitespaces)
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let validatestring = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
        let validateOther = validatestring.evaluate(with: string)
        return validateOther
    }
    
    func isvalidPassword(password : String) -> Bool{  //Check password
        let passWordRegEx = "^(?=.*[a-z])(?=.*[$@$#!%*?&])[A-Za-z\\d$@$#!%*?&]{8,}"
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", passWordRegEx)
        return passwordTest.evaluate(with: password)
    }
    
    func isValidName(name: String) -> Bool {    // check firstname
        //Declaring the rule of characters to be used. Applying rule to current state. Verifying the result.
        let regex = "[A-Za-z]{2,}"
        let test = NSPredicate(format: "SELF MATCHES %@", regex)
        let result = test.evaluate(with: name)
        return result
        
    }
    
    func showToast(message : String) // display toast
    {
        let toastLabel = UILabel(frame: CGRect(x: self.view.frame.width/2 - 75, y: self.view.frame.height - 130 , width: 180, height: 40))
        toastLabel.textAlignment = .center
        toastLabel.font.withSize(30.0)
        toastLabel.textColor = UIColor.black
        toastLabel.backgroundColor = UIColor.white
        toastLabel.layer.cornerRadius = 20
        toastLabel.alpha = 1.0
        toastLabel.text = message
        toastLabel.clipsToBounds = true
        self.view.addSubview(toastLabel)
        UIView.animate(withDuration: 100.0, delay: 5.0, options: .curveEaseInOut, animations:
        {
            toastLabel.alpha = 0.0
        }){ (isCompleted) in
            toastLabel.removeFromSuperview()
        }
        
    }
   /*
    func CheckUsernamePassword()
    {
        var register = [TblRegister]()
        var username = ""
        var passString = ""
        var checkRecord = false
        for item in register
        {
            username = (item as AnyObject).value(forKeyPath: "email") as! String
            passString = (item as AnyObject).value(forKeyPath: "password") as! String
            UserData.shared.id = item.id
            print(item)
            print(username)
            print(passString)
            if username == txtemail.text && txtpwd.text == passString
            {
                UserData.shared.id = item.id ?? UUID()
                checkRecord = true;
            }
        }
        if checkRecord == true
        {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let mainTB = storyboard.instantiateViewController(identifier: "tabbarViewController")
            (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.changeRootViewController(mainTB)
        }
        else
        {
            alert(message: "Enter Valid Email and Password", title: "Invalid Email and Password")
            
        }
        
    }
    */
    
  }
