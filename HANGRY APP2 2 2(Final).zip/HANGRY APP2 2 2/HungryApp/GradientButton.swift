//
//  GradientButton.swift
//  HungryApp
//
//  Created by differenz152 on 20/03/23.
//

import UIKit

class GradientButton: UIButton {

    override open class var layerClass: AnyClass {
        return CAGradientLayer.classForCoder()
        
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        let gradientLayer = layer as! CAGradientLayer
        gradientLayer.colors = [UIColor(red: 133/255 , green: 61/255, blue: 210/255, alpha: 1).cgColor, UIColor(red: 40/255, green: 48/255, blue: 110/255, alpha: 1).cgColor]
        // Horizontal: left to right.
        gradientLayer.startPoint = CGPoint(x: 0, y: 0.5) // Left side.
        gradientLayer.endPoint = CGPoint(x: 1, y: 0.5) // Right side.
        self.layer.cornerRadius = 10
        self.clipsToBounds = true
    }

}
