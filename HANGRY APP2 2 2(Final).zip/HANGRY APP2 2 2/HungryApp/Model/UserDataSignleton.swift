//
//  UserDataSignleton.swift
//  HungryApp
//
//  Created by differenz152 on 27/03/23.
//

import Foundation

class UserData {
    var id: UUID?
    var Fname: String = ""
    var Lname: String = ""
    var PhoneNo: String = ""
    var Email: String = ""
    var Address: String = ""
    var Password: String = ""
    var Image: Data?
    var isFirstTime: Bool = true
    static let shared = UserData()
    private init() {}
    func setData(fName: String, lName: String, pNumber: String, email: String, address: String, password: String,image:Data) {
        
    }
}
