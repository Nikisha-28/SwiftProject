//
//  CurrentUser.swift
//  HungryApp
//
//  Created by differenz152 on 19/04/23.
//

import Foundation

struct CurrentUser{
    
    var id: UUID
    var email: String?
    var fname: String?
    var lname: String?
    var address: String?
    var password: String?
    var phoneno: String?
    var image : Data?
    
    init(id: UUID, dictionary: [String:Any]){
        self.id = id
        self.email = dictionary["email"] as? String ?? ""
        self.fname = dictionary["fname"] as? String ?? ""
        self.lname = dictionary["lname"] as? String ?? ""
        self.address = dictionary["address"] as? String ?? ""
        self.password = dictionary["password"] as? String ?? ""
        self.phoneno = dictionary["phoneno"] as? String ?? ""
    //    self.image = dictionary["image"] as? Data()

    }
}
