//
//  foodItemModel.swift
//  HungryApp
//
//  Created by differenz152 on 25/04/23.
//

import Foundation

struct foodItemModel{
    var image : String?
    var foodname : String?
    
    init(dictionary: [String:Any]){
        self.image = dictionary["itemImage"] as? String ?? ""
        self.foodname = dictionary["itemName"] as? String ?? ""
    }
}
