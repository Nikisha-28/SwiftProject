//
//  ItemModel.swift
//  HungryApp
//
//  Created by differenz152 on 30/03/23.
//

import Foundation

struct ItemModel {
    
    var image : Data?
    var itemName : String?
}
