//
//  PaymentViewController.swift
//  HungryApp
//
//  Created by differenz152 on 13/02/23.
//

import UIKit

class PaymentViewController: UIViewController {


    @IBOutlet weak var btnPayNow: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "PAYMENT"
    

    }
//    @IBAction func back(_ sender: Any) {
//        self.navigationController?.popViewController(animated: true)
//    }
    
    
  

}
