//
//  LaunchMoneyViewController.swift
//  HungryApp
//
//  Created by differenz152 on 13/02/23.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore

class LaunchMoneyViewController: UIViewController{

    @IBOutlet weak var btnStripe: UIButton!
    @IBOutlet weak var btnPay: UIButton!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var btnPayout: UIButton!
    
    let uid : String = (Auth.auth().currentUser?.uid)!

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "LUNCH MONEY"
        
        //let data = DBHelper.share.getUserData(byIdentifier: UserData.shared.id ?? UUID())
        //self.lblName.text = "\(data?.fname ?? "")   \(data?.lname ?? "")"
        
        setCustomNavbar()    /// Call function Gradient Color in navigation
        
        if Auth.auth().currentUser != nil{
            
            let db = Firestore.firestore()
            
            db.collection("users").document(uid).getDocument { data , error in
                
                print("This is your Data :: \(data?.data())")
                let userData = data?.data()
                self.lblName.text = "\(userData?["firstname"] as? String ?? "")  \(userData?["lastname"] as? String ?? "")"
            }
        }
    }
    // MARK: - Action Methods

    @IBAction func btnback(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let MainTB = storyboard.instantiateViewController(withIdentifier: "tabbarViewController")

        (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.changeRootViewController(MainTB)
    }
    
    @IBAction func btnPayTouchupInside(_ sender: Any) {
        let signUp = self.storyboard?.instantiateViewController(withIdentifier: "PaymentViewController") as! PaymentViewController
        self.navigationController?.pushViewController(signUp, animated: true)

    }
}


