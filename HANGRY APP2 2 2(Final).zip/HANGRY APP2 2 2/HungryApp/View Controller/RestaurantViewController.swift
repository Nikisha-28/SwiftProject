//
//  RestaurantViewController.swift
//  HungryApp
//
//  Created by differenz152 on 11/04/23.
//

import UIKit

class RestaurantViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
        
    var list : [Result] = [Result]()
   
    @IBOutlet weak var myTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "ARABIC"
  
        myTableView.reloadData()
        
        let data = DataLoader().readLocalFile(forName: "MyJSON") ?? Data()
        let myVar = DataLoader().parse(jsonData: data)
        guard let dataOfModel = myVar else { return }
       // print("My New Model >>>>>>>>>>> \(dataOfModel)")
        list = dataOfModel.results
        
        let nibcell = UINib(nibName: "RestaurantTableViewCell", bundle: nil)
        myTableView.register(nibcell, forCellReuseIdentifier: "table")
//        myTableView.register(nibcell, forCellReuseIdentifier: "table")
//        //myTableView.register(nibcell, forCellReuseIdentifier: "table")

    }
    //MARK: - Table View
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "table", for: indexPath) as! RestaurantTableViewCell
        cell.lblName.text = list[indexPath.row].name
        cell.lblAddress.text = list[indexPath.row].vicinity
        cell.cosmosView.rating = list[indexPath.row].rating
        
        cell.completion = { bool in
            if bool {
                if let mainTB = self.storyboard?.instantiateViewController(identifier: "GoogleMapViewController") as? GoogleMapViewController {
                    mainTB.fromBackCordinate = .init(latitude: self.list[indexPath.row].geometry.location.lat, longitude: self.list[indexPath.row].geometry.location.lng)
        
                    mainTB.modalTransitionStyle = .crossDissolve
                    mainTB.modalPresentationStyle = .overFullScreen
                    self.present(mainTB, animated: false) {
                        
                    }
//                self.navigationController?.pushViewController(mainTB, animated: true)
                }
//                (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.changeRootViewController(mainTB)
            }
        }
        
        var flag = 0
        if list[indexPath.row].openingHours?.openNow == true{
            flag = 1
        }
        else{
            flag = 0
        }
        if flag == 1 {
            cell.lblOpen.text = "Open Now"
        }
        else{
            cell.lblOpen.text = "Currently Closed"
        }
        return cell
    }

}
