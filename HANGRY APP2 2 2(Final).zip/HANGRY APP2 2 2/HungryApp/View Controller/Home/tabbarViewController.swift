//
//  tabbarViewController.swift
//  HungryApp
//
//  Created by differenz152 on 20/02/23.
//

import UIKit

class tabbarViewController: UITabBarController,UITabBarControllerDelegate{

    
    @IBOutlet weak var tabbar: UITabBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.delegate = self
                
        setGradientbackgrond(startColor: .magenta, endColor: .blue)
        
        let pressedTintColor = UIColor.white
        tabbar.unselectedItemTintColor = UIColor.systemGray2
        
        UITabBar.appearance().barTintColor = UIColor.white
        UITabBar.appearance().tintColor = pressedTintColor
        
    }

    func setGradientbackgrond(startColor: UIColor,endColor: UIColor){
        let gradientlayer = CAGradientLayer()
        var bounds = tabbar.bounds
        bounds.size.height += UIApplication.shared.statusBarFrame.size.height
        bounds.size.width += UIApplication.shared.statusBarFrame.size.width
        gradientlayer.frame = bounds
        gradientlayer.colors = [startColor.cgColor,endColor.cgColor]
        gradientlayer.locations  = [0.0,1.0]
        gradientlayer.startPoint = CGPoint(x: 0.0, y: 5.0)
        gradientlayer.endPoint = CGPoint(x: 4.5, y: 2.0)
        
        self.tabbar.layer.insertSublayer(gradientlayer, at: 0)
        
    }
       
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController)-> Bool {
 
        guard viewController is RatingViewController else { return true }
  
    return true
    }
}
