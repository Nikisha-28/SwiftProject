//
//  PopUPVCViewController.swift
//  HungryApp
//
//  Created by differenz152 on 22/02/23.
//

import UIKit
import Cosmos

class PopUPVCViewController: UIViewController {

    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var imglogo: UIImageView!
    @IBOutlet weak var cosmosView: CosmosView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imglogo.layer.cornerRadius = 30
        imglogo.clipsToBounds = true
        backView.layer.cornerRadius = 15
        backView.clipsToBounds = true
        
        cosmosView.settings.starSize = 33
        cosmosView.settings.starMargin = 10
        cosmosView.settings.fillMode = .precise
        cosmosView.settings.filledColor = UIColor.systemOrange
        
    }
    
    @IBAction func btnSubmitTouchupInside(_ sender: Any) {
        //self.alert(message: "Successfully Done", title: "Success")
        showToast(message: "SuccsessFully Done")
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0)
        {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let MainTB = storyboard.instantiateViewController(withIdentifier: "tabbarViewController")
            
            (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.changeRootViewController(MainTB)
        }
    }
    
    @IBAction func btncancelTouchUpInside(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let MainTB = storyboard.instantiateViewController(withIdentifier: "tabbarViewController")
        
        (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.changeRootViewController(MainTB)
    }
    

}
