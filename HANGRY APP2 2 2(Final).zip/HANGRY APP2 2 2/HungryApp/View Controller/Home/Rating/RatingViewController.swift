//
//  RatingViewController.swift
//  HungryApp
//
//  Created by differenz152 on 20/02/23.
//

import UIKit

class RatingViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        //view.backgroundColor = .red
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PopUPVCViewController") as! PopUPVCViewController
        vc.modalTransitionStyle = .coverVertical
        vc.modalPresentationStyle = .overCurrentContext
        self.present(vc, animated: true)

    }
  
}
