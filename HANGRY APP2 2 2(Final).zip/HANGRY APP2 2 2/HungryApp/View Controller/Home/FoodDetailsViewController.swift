//
//  FoodDetailsViewController.swift
//  HungryApp
//
//  Created by differenz152 on 08/02/23.
//

import UIKit
import CoreData
import Foundation
import FirebaseFirestore

class FoodDetailsViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    //var fi = ""
    var selectedItem : [String] = []
    
  //  var dataArray :[TblFoodItem] = [TblFoodItem]()
    let allDataArray : NSMutableArray = []
    

    @IBOutlet weak var myCollectionView: UICollectionView!
    
    var foodImages:[String] = ["american","barbeque","chinese","french","humburger","indian","italian","japanese","mexican","pizza","seafood","steak","sushi","thai"]
    
    var foodNames:[String] = ["American","Barbaque","Chinese","French","Humburger","Indian","Italian","Japanese","Mexican","Pizza","Seafood","Steak","Sushi","Thai"]
    
    var selectedIndex: [Int] = []
    
    var foodItem : [foodItemModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "HANGRY APP"
        setCustomNavbar()
                
        let nibcell = UINib(nibName: "MyCollectionCell", bundle: nil)
        myCollectionView.register(nibcell, forCellWithReuseIdentifier: "cell")
        
     //   saveDataCollection()
        
        let db = Firestore.firestore()
        db.collection("foodItems").getDocuments() { quarysnapshot, error in
            if let error = error{
                print("Error")
            }
            else{
                for document in quarysnapshot!.documents{
                    print("\(document.data())")
                    let data = document.data()
                    let foodItemModel = foodItemModel(dictionary: data)
                    self.foodItem.append(foodItemModel)
                }
                self.myCollectionView.reloadData()
            }
        }
    }
    
//    override func viewWillAppear(_ animated: Bool) {
//        fetchDataFromCoreData {
//            if self.dataArray.count > 0{
//                print("Total Data = \(self.dataArray)")
//            }
//            else{
//                self.saveDataCollection()
//            }
//        }
//    }
    
    
    // MARK: - VIEW DID APPEAR METHOD
//    override func viewDidAppear(_ animated: Bool) {
//        if UIDevice.current.orientation.isLandscape{
//            myCollectionView.reloadData()
//
//        }
//    }
    
    // MARK: - COLLECTION VIEW

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return (foodItem.count)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = myCollectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! MyCollectionCell
       // let allData = dataArray[indexPath.row]
        cell.lblName.text = foodItem[indexPath.row].foodname ?? ""
        let url = URL(string: self.foodItem[indexPath.row].image ?? "")
        if let data = try? Data(contentsOf: url!)
        {
            cell.imgfood.image = UIImage(data: data) ?? UIImage()
        }
        //cell.imgfood.image = UIImage(data: dataArray[indexPath.row].image ?? Data())
        
        
        
        if self.selectedIndex.contains(indexPath.row){
            cell.btnCheck.setImage(UIImage(named: "check"), for: .normal)
        }
        else{
            cell.btnCheck.setImage(UIImage(named: "empty"), for: .normal)
        }
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
//        if UIDevice.current.orientation.isLandscape{
//            return UIEdgeInsets(top: 50.0, left: 200.0, bottom: 50.0, right: 200.0)
//        }
        return UIEdgeInsets(top: 8.0, left: 14.0, bottom: 8.0, right: 14.0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let padding: CGFloat = 40
        let collectionViewSize = collectionView.frame.size.width - padding
        return CGSize(width: collectionViewSize/2, height: collectionViewSize/2)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 12
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if selectedItem.contains(foodItem[indexPath.row].foodname ?? "" ){
            
            if let indx = self.selectedItem.firstIndex(where: {$0 == foodItem[indexPath.row].foodname}) {
                    self.selectedItem.remove(at: indx)
                   // print(dataArray)
            }
        }
        else {
            selectedItem.append(foodItem[indexPath.row].foodname ?? "" )
            print(selectedItem)
            //print("INDEX PATH : \(selectedItem[indexPath.row])")
        }

        if self.selectedIndex.contains(indexPath.row){
            self.selectedIndex.remove(at: selectedIndex.firstIndex(of: indexPath.row)!)
//           let cell = myCollectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! MyCollectionCell
//            fi = cell.lblName.text!
//            print(fi)
            
            
        }
        else{
            self.selectedIndex.append(indexPath.row)
            
            print("INDEX :: \(selectedIndex)")
        }
        myCollectionView.reloadData()
        
    }
    
    // MARK: - ACTION METHODS
    
    @IBAction func setting(_ sender: Any) {
        let setting = self.storyboard?.instantiateViewController(withIdentifier: "SettingViewController") as! SettingViewController
        self.navigationController?.pushViewController(setting, animated: true)
    }
    
    @IBAction func btnDoneTouchUpInside(_ sender: Any) {
        let done = self.storyboard?.instantiateViewController(withIdentifier: "SpinViewController") as! SpinViewController
        done.arrayAStr = selectedItem
        done.index = selectedIndex
        self.navigationController?.pushViewController(done, animated: true)
    }
     
//    // MARK: - SET FOOTER IN COLLECTION VIEW
//
//    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
//        let fView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "footer", for: indexPath)
//        return fView
//    }
    
//    //MARK: -Gradient Nav-Bar
//    override func viewDidLayoutSubviews() {
//        super.viewDidLayoutSubviews()
//    }

//MARK: - Save Collection View Data

//func saveDataCollection(){
//
//    let context = DBHelper.share.context
//    allDataArray.add(["image": UIImage(named: foodImages[0])?.pngData() ?? Data(),"itemName": foodNames[0]])
//    allDataArray.add(["image": UIImage(named: foodImages[1])?.pngData() ?? Data(),"itemName": foodNames[1]])
//    allDataArray.add(["image": UIImage(named: foodImages[2])?.pngData() ?? Data(),"itemName": foodNames[2]])
//    allDataArray.add(["image": UIImage(named: foodImages[3])?.pngData() ?? Data(),"itemName": foodNames[3]])
//    allDataArray.add(["image": UIImage(named: foodImages[4])?.pngData() ?? Data(),"itemName": foodNames[4]])
//    allDataArray.add(["image": UIImage(named: foodImages[5])?.pngData() ?? Data(),"itemName": foodNames[5]])
//    allDataArray.add(["image": UIImage(named: foodImages[6])?.pngData() ?? Data(),"itemName": foodNames[6]])
//    allDataArray.add(["image": UIImage(named: foodImages[7])?.pngData() ?? Data(),"itemName": foodNames[7]])
//    allDataArray.add(["image": UIImage(named: foodImages[8])?.pngData() ?? Data(),"itemName": foodNames[8]])
//    allDataArray.add(["image": UIImage(named: foodImages[9])?.pngData() ?? Data(),"itemName": foodNames[9]])
//    allDataArray.add(["image": UIImage(named: foodImages[10])?.pngData() ?? Data(),"itemName": foodNames[10]])
//    allDataArray.add(["image": UIImage(named: foodImages[11])?.pngData() ?? Data(),"itemName": foodNames[11]])
//    allDataArray.add(["image": UIImage(named: foodImages[12])?.pngData() ?? Data(),"itemName": foodNames[12]])
//    allDataArray.add(["image": UIImage(named: foodImages[13])?.pngData() ?? Data(),"itemName": foodNames[13]])
//
//
//    for item in (allDataArray){
//        do{
//            let newitem = NSEntityDescription.insertNewObject(forEntityName: "TblFoodItem", into: context)
//            guard let name = item as? [String:Any] else {
//                return
//            }
//            let nameStr = name["itemName"] as! String
//            let img = name["image"] as! Data
//            newitem.setValue(nameStr, forKey: "itemName")
//            newitem.setValue(img, forKey: "image")
//            try context.save()
//            self.fetchDataFromCoreData {
//            }
//        }
//        catch
//        {
//        }
//    }
//}



/*  //MARK: - Fetch images
                      
func fetchDataFromCoreData(completion: () -> ()){
    
    let context = DBHelper.share.context
    let fetchRequest = NSFetchRequest<TblFoodItem>(entityName: "TblFoodItem")
    dataArray.removeAll()
    do
    {
        dataArray = try context.fetch(fetchRequest)
        self.myCollectionView.reloadData()
        completion()
    }
    catch
    {
        print("fetch from Coredata",error)
    }
        
}
*/
}
    
//MARK: -Extension Gradient Nav-BAR
extension UIViewController {
    public func setCustomNavbar() {
        if #available(iOS 13.0, *) {
            let navAppearance: UINavigationBarAppearance = UINavigationBarAppearance()
            navAppearance.configureWithDefaultBackground()
            navAppearance.titleTextAttributes = [.foregroundColor: UIColor.white, .font : UIFont.systemFont(ofSize: 19)]
            let purpleBtnColor:UIColor = UIColor(hex: "#A16AE8")  //purple  A16AE8
            let blueBtnColor:UIColor = UIColor(hex: "#3F33BD")  //blue
            let gradient = CAGradientLayer()
            guard var bounds = self.navigationController?.navigationBar.bounds
            else {
                return
                
            }
            bounds.size.height += view.window?.windowScene?.statusBarManager?.statusBarFrame.height ?? 0
            gradient.frame = bounds
            gradient.colors = [purpleBtnColor.cgColor, blueBtnColor.cgColor]//            gradient.startPoint = CGPoint(x: 0.0, y: 0.0)//
            gradient.endPoint = CGPoint(x: 1.0, y: 0.0)
            gradient.startPoint = CGPoint(x: 0.0, y: 0.0)
            gradient.endPoint = CGPoint(x: 1.0, y: 0.0)
            if let image = self.navigationController?.navigationBar.getImageFrom(gradientLayer: gradient) {
                navAppearance.backgroundImage = image
                
                }
            self.navigationController?.navigationBar.standardAppearance = navAppearance
            self.navigationController?.navigationBar.scrollEdgeAppearance = navAppearance
        }
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.navigationBar.tintColor = UIColor.white
        let navigationTitleFont = UIFont.systemFont(ofSize: 19)
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.font: navigationTitleFont]
        
        let attrs = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.titleTextAttributes = attrs
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named: "back_arrow")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named: "back_arrow")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    
        
    }
}

    

