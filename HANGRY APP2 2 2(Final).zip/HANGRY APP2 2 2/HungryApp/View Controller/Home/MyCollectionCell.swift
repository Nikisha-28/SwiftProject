//
//  MyCollectionCell.swift
//  HungryApp
//
//  Created by differenz152 on 10/02/23.
//

import UIKit

class MyCollectionCell: UICollectionViewCell {
    
    
    
    @IBOutlet weak var imgfood: UIImageView!
  
    @IBOutlet weak var btnCheck: UIButton!
    
    @IBOutlet weak var lblName: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        imgfood.layer.cornerRadius = 20
        imgfood.clipsToBounds = true
        
    }
    
}
