//
//  ForgotPWDViewController.swift
//  HungryApp
//
//  Created by differenz152 on 24/02/23.
//

import UIKit
import FirebaseAuth

class ForgotPWDViewController: UIViewController {

    var register = [TblRegister]()

    @IBOutlet weak var txtemail: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        txtemail.layer.cornerRadius = 22
        txtemail.clipsToBounds = true
       // register = DBHelper.share.fetchUser()


        navigationController?.isNavigationBarHidden = true
    }
    
    //MARK: - Action Method
    
    @IBAction func btnContinueTouchUpInside(_ sender: Any) {
        if txtemail.text == "" {
            alert(message: "Please Enter Email Id", title: "Alert")
        }
        else{
           // CheckEmail()
            
            Auth.auth().sendPasswordReset(withEmail: txtemail.text!) { (error) in
                if let error = error{
                    let alert = self.alert(message: error.localizedDescription, title: "Error")
                    return
                }
                else{
                    self.alert(message: "Please Check Your Mail", title: "Message Info")
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5)
                    {
                        self.navigationController?.popViewController(animated: true)
//                        let navigate = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
//                        self.navigationController?.pushViewController(navigate, animated: true)
                    }
                }
            }
         /*   Auth.auth().currentUser?.sendEmailVerification(completion: { (error) in
                if let error = error {
                    let alert = self.alert(message: error.localizedDescription, title: "Error")
                }
                else{
                    let navigate = self.storyboard?.instantiateViewController(withIdentifier: "ResetViewController") as! ResetViewController
                    self.navigationController?.pushViewController(navigate, animated: true)
                }
            })*/
            
        }
    }
    
    //MARK: - Check Email Function
    func CheckEmail()
    {
        var username = ""
        var checkRecord = false
        for item in register
        {
            username = (item as AnyObject).value(forKey: "email") as! String
            if username == txtemail.text
            {
                UserData.shared.id = item.id ?? UUID()
                checkRecord = true;
            }
        }
        if checkRecord == true
        {
            let navigate = self.storyboard?.instantiateViewController(withIdentifier: "ResetViewController") as! ResetViewController
            self.navigationController?.pushViewController(navigate, animated: true)
        }
        else
        {
            alert(message: "No User Found", title: "Alert")
        }
    }
}
