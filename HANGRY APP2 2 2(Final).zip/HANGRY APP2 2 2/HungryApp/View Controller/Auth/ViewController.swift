//
//  ViewController.swift
//  HungryApp
//
//  Created by differenz152 on 06/02/23.
//

import UIKit
import GoogleSignIn
import FirebaseAuth
import FirebaseCore
import FirebaseFirestore
import AuthenticationServices
import CryptoKit
import FacebookCore
import FacebookLogin
import FBSDKLoginKit

class ViewController: UIViewController, ASAuthorizationControllerDelegate, ASAuthorizationControllerPresentationContextProviding {
    
    
    
//    @IBOutlet weak var btnFacebook: FBLoginButton!
    @IBOutlet weak var btnFacebook : UIButton!
    @IBOutlet weak var txtemail: UITextField!
    @IBOutlet weak var txtpwd: UITextField!
    @IBOutlet weak var btnSignIn: UIButton!
    @IBOutlet weak var imglogo: UIImageView!
    
    @IBOutlet weak var btnGoogle: UIButton!
    var register = [TblRegister]()
    
    fileprivate var currentNonce : String?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
       // register = DBHelper.share.fetchUser()
//        self.txtemail.text = "shriya@gmail.com"
//        self.txtpwd.text = "123456"
        
        txtemail.layer.cornerRadius = 25
        txtemail.clipsToBounds = true
        txtpwd.layer.cornerRadius = 25
        txtpwd.clipsToBounds = true
        btnSignIn.layer.cornerRadius = 25
        btnSignIn.clipsToBounds = true
        imglogo.layer.borderWidth = 5
        

        
        /////for use Facebook
//        if let token = AccessToken.current,
//           !token.isExpired {
//
//        }
//        btnFacebook.permissions = ["public_profile", "email"]

//        else{
//            btnFacebook.Permissions = ["public_profile","email"]
//            btnFacebook.delegate = self
//        }
    }
    
    
    
    // MARK: - Action Methods

    @IBAction func btnForgotTouchUpInside(_ sender: Any) {
        
        let forgot = self.storyboard?.instantiateViewController(withIdentifier: "ForgotPWDViewController") as! ForgotPWDViewController
        self.navigationController?.pushViewController(forgot, animated: true)
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let mainTB = storyboard.instantiateViewController(identifier: "ForgotPWDViewController")
//        (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.changeRootViewController(mainTB)
    }
    
    @IBAction func btnSigninTouchUpInside(_ sender: Any) {

 /*       //signIn(email: String, pass: String, completionBlock: true)
        if let username = txtemail.text,let password = txtpwd.text{
            if (username.isEmpty) || (password.isEmpty)
            {
                alert(message: "All Field Required to fill in", title: "Alert")
            }
            else if isvalidateEmail(email: username) == false {
                alert(message: "Enter Proper Email", title: "Alert")
           }
            else if isvalidPassword(password: password) == false {
                alert(message: "Password must be more than 8 characters, with at least one capital, numeric or special character", title: "Alert")
            }
            else{
                CheckUsernamePassword()
            }
        }*/
        
        guard let email = txtemail.text,
        email != "",
        let password = txtpwd.text,
        password != ""
        else{
            alert(message: "All Field Required to fill in", title: "Message Info")
            return
        }
        Auth.auth().signIn(withEmail: email, password: password) { user, error in

            if error == nil
            {
                
                print("CURRENT DATA UID >>> \(user?.user.uid ?? "")")
                //self.showToast(message: "Successfullt Login")
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5)
                {
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "tabbarViewController") as! tabbarViewController
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            }
            else
            {
                let alertcontroller = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
                let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                alertcontroller.addAction(defaultAction)
                self.present(alertcontroller, animated: true, completion: nil)
            }
        }
        
   /*     var credential : AuthCredential
        if let user = Auth.auth().currentUser{
            user.reauthenticate(with: credential) { data, error in
                if let error = error{
                    print("Error")
                }
                else{
                    user.updateEmail(to: "email") { error in
                        print("email updated")
                    }
                }
            }
        }*/
        
        
     /*   let user = Auth.auth().currentUser
        
        let credential = FIREmailPasswordAuthCredential.credential(withEmail: email, password: password)
        
        user?.reauthenticate(with: credential, completion: { user, error in
            if let error = error{
                print("Error Occure")
            }
            else{
                print("user Re-authenticated")
            }
        })*/
        
        
    }
    


    @IBAction func btnRegisterTouchUpInside(_ sender: Any) {
        let register = self.storyboard?.instantiateViewController(withIdentifier: "RegistrationViewController") as! RegistrationViewController
        self.navigationController?.pushViewController(register, animated: true)
    }
    
    @IBAction func btnGoogleTouchUpInside(_ sender: UIButton) {
        GIDSignIn.sharedInstance.signIn(withPresenting: self)
    }
    
    @IBAction func btnAppleLoginTouchUpInside(_ sender: UIButton) {
        let nonce = randomNonceString()
          currentNonce = nonce
          let appleIDProvider = ASAuthorizationAppleIDProvider()
          let request = appleIDProvider.createRequest()
          request.requestedScopes = [.fullName, .email]
          request.nonce = sha256(nonce)

          let authorizationController = ASAuthorizationController(authorizationRequests: [request])
          authorizationController.delegate = self
          authorizationController.presentationContextProvider = self
          authorizationController.performRequests()
    }
    
    @IBAction func btnFacebookLoginTouchUpInside(_ sender: Any) {
        let loginManager = LoginManager()
            loginManager.logIn(permissions: ["public_profile", "email"], from: self) { (result, error) in
                if let error = error {
                    print("Failed to login: \(error.localizedDescription)")
                    return
                }
                guard let accessToken = AccessToken.current else {
                    print("Failed to get access token")
                    return
                }
                let credential = FacebookAuthProvider.credential(withAccessToken: accessToken.tokenString)
                
                // Perform login by calling Firebase APIs

                Auth.auth().signIn(with: credential, completion: { (user, error) in
                    

                    if let error = error {
                        print("Login error: \(error.localizedDescription)")
                        let alertController = UIAlertController(title: "Login Error", message: error.localizedDescription, preferredStyle: .alert)
                        let okayAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                        alertController.addAction(okayAction)
                        
                        self.present(alertController, animated: true, completion: nil)
                        return
                    }else {
                        
                        //self.currentUserName()
                        print("fjhf")
                    }
                })
            }
        
        }
    
    
    // MARK: - Function
    func CheckUsernamePassword()
    {
        var username = ""
        var passString = ""
        var checkRecord = false
        for item in register
        {
            username = (item as AnyObject).value(forKey: "email") as! String
            passString = (item as AnyObject).value(forKey: "password") as! String
            print(item)
            print(username)
            print(passString)
            if username == txtemail.text && txtpwd.text == passString
            {
                UserData.shared.id = item.id ?? UUID()
                checkRecord = true;
            }
        }
        if checkRecord == true
        {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let mainTB = storyboard.instantiateViewController(identifier: "tabbarViewController")
            (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.changeRootViewController(mainTB)
        }
        else
        {
            alert(message: "Enter Valid Email and Password", title: "Invalid Email and Password")
        }
    }
    
    //Sign in with Facebook
    
    func firebaseFacebookLogin(accessToken: String){
        let credential = FacebookAuthProvider.credential(withAccessToken: accessToken)
        Auth.auth().signIn(with: credential) { (authResult, error) in
            if let error = error{
                print("facebookLogi Error")
                print(error)
                return
            }
            print("Log In Done")
        }
    }
    
    
    //Sign in with Googel
    
    func signInwithGoogle(){
        guard let clientID = FirebaseApp.app()?.options.clientID else { return }

        // Create Google Sign In configuration object.
        let config = GIDConfiguration(clientID: clientID)
        GIDSignIn.sharedInstance.configuration = config

        // Start the sign in flow!
        GIDSignIn.sharedInstance.signIn(withPresenting: self) { signResult, error in
                    
            if error != nil {
               return
            }
             guard let user = signResult?.user,
                   let idToken = user.idToken else { return }
             let accessToken = user.accessToken
             let credential = GoogleAuthProvider.credential(withIDToken: idToken.tokenString, accessToken: accessToken.tokenString)
            // Use the credential to authenticate with Firebase
        }
    }
    
    // Sign in with Apple

    private func randomNonceString(length: Int = 32) -> String {
        precondition(length > 0)
        var randomBytes = [UInt8](repeating: 0, count: length)
        let errorCode = SecRandomCopyBytes(kSecRandomDefault, randomBytes.count, &randomBytes)
        if errorCode != errSecSuccess {
            fatalError(
                "Unable to generate nonce. SecRandomCopyBytes failed with OSStatus \(errorCode)"
            )
        }
        let charset: [Character] =
            Array("0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz-._")
        let nonce = randomBytes.map { byte in
                // Pick a random character from the set, wrapping around if needed.
            charset[Int(byte) % charset.count]
            }
            return String(nonce)
        }
    
        private func sha256(_ input: String) -> String {
            let inputData = Data(input.utf8)
            let hashedData = SHA256.hash(data: inputData)
            let hashString = hashedData.compactMap {
                String(format: "%02x", $0)
        }.joined()
        return hashString
    }
    
    func authorizationController(controller: ASAuthorizationController, didCompleteWithAuthorization authorization: ASAuthorization) {
        
//        if let appleIDCredential = authorization.credential as? ASAuthorizationAppleIDCredential {
//          guard let nonce = currentNonce else {
//            fatalError("Invalid state: A login callback was received, but no login request was sent.")
//          }
//            guard let appleIDToken = appleIDCredential.identityToken else {
//            print("Unable to fetch identity token")
//            return
//          }
//          guard let idTokenString = String(data: appleIDToken, encoding: .utf8) else {
//            print("Unable to serialize token string from data: \(appleIDToken.debugDescription)")
//            return
//          }
//          // Initialize a Firebase credential, including the user's full name.
//          let credential = OAuthProvider.appleCredential(withIDToken: idTokenString,
//                                                            rawNonce: nonce,
//                                                            fullName: appleIDCredential.fullName)
//          // Sign in with Firebase.
//          Auth.auth().signIn(with: credential) { (authResult, error) in
//              if let error = error {
//              // Error. If error.code == .MissingOrInvalidNonce, make sure
//              // you're sending the SHA256-hashed nonce as a hex string with
//              // your request to Apple.
//                  print(error.localizedDescription)
//              return
//            }
//            // User is signed in to Firebase with Apple.
//            // ...
//          }
//        }

         if let nonce = currentNonce,
            let appleIDCredential = authorization.credential as? ASAuthorizationAppleIDCredential,
            let appleIDToken = appleIDCredential.identityToken,
            let appleIDTokenString = String(data : appleIDToken, encoding: .utf8)
            {
                let credential = OAuthProvider.credential(withProviderID: "apple.com", idToken: appleIDTokenString, rawNonce: nonce)
                //Auth.auth().signIn(with: credential)
             }

      }

      func authorizationController(controller: ASAuthorizationController, didCompleteWithError error: Error) {
        // Handle error.
        print("Sign in with Apple errored: \(error)")
      }
    
      func presentationAnchor(for controller: ASAuthorizationController) -> ASPresentationAnchor {
            return self.view.window!
        }
    }
    
// MARK: - NavigationBar Color
extension UINavigationBar{
    func setGradient()
    {
        let redBtnColor:UIColor = .red //UIColor(hex: "#f3ad98")
        let orangeBtnColor:UIColor = .green        //UIColor(hex: "#b8f1df")
        let gradient = CAGradientLayer()
        bounds = self.bounds      // view.window?.windowScene?.statusBarManager?.statusBarFrame.height ?? 0
        bounds.size.height += self.window?.windowScene?.statusBarManager?.statusBarFrame.height ?? 0
        gradient.frame = bounds
        gradient.colors = [redBtnColor.cgColor, orangeBtnColor.cgColor]
        gradient.startPoint = CGPoint(x: 0.0, y: 0.0)
        gradient.endPoint = CGPoint(x: 1.0, y: 0.0)
        
        if let image = getImageFrom(gradientLayer: gradient)
        {
            self.setBackgroundImage(image, for: UIBarMetrics.default)
        }
        
    }
    func getImageFrom(gradientLayer:CAGradientLayer) -> UIImage?
    {
        var gradientImage:UIImage?
        UIGraphicsBeginImageContext(gradientLayer.frame.size)
        
        if let context = UIGraphicsGetCurrentContext()
        {
            gradientLayer.render(in: context)
            gradientImage = UIGraphicsGetImageFromCurrentImageContext()?.resizableImage(withCapInsets: UIEdgeInsets.zero, resizingMode: .stretch)
        }
        UIGraphicsEndImageContext()
        return gradientImage
    }}
public extension UIColor{
    /**     Creates an immuatble UIColor instance specified by a hex string, CSS color name, or nil
     - parameter hexString: A case insensitive String? representing a hex or CSS value e.g.
     - **"abc"**
     - **"abc7"**
     - **"#abc7"**
     - **"00FFFF"**
     - **"#00FFFF"**
     - **"00FFFF77"**
     - **"Orange", "Azure", "Tomato"** Modern browsers support 140 color names     (<http://www.w3schools.com/cssref/css_colornames.asp>)
     - **"Clear"** [UIColor clearColor]     - **"Transparent"** [UIColor clearColor]
     - **nil** [UIColor clearColor]
     - **empty string** [UIColor clearColor]
     */
    
    public convenience init(hex: String?)
    {
        let normalizedHexString: String = UIColor.normalize(hex)
        var c: CUnsignedInt = 0
        Scanner(string: normalizedHexString).scanHexInt32(&c)
        self.init(red:UIColorMasks.redValue(c), green:UIColorMasks.greenValue(c), blue:UIColorMasks.blueValue(c), alpha:UIColorMasks.alphaValue(c))
        
    }
    /**     Returns a hex equivalent of this UIColor.     - Parameter includeAlpha:   Optional parameter to include the alpha hex.     color.hexDescription() -> "ff0000"     color.hexDescription(true) -> "ff0000aa"     - Returns: A new string with `String` with the color's hexidecimal value.     */
    
    public func hexDescription(_ includeAlpha: Bool = false) -> String {
        guard self.cgColor.numberOfComponents == 4
        else {
            return "Color not RGB."
            
        }
        let a = self.cgColor.components!.map { Int($0 * CGFloat(255)) }
        let color = String.init(format: "%02x%02x%02x", a[0], a[1], a[2])
        
        if includeAlpha
        {
            let alpha = String.init(format: "%02x", a[3])
            return "\(color)\(alpha)"
            
        }
        return color
        
    }
    fileprivate enum UIColorMasks: CUnsignedInt
    {
        case redMask    = 0xff000000
        case greenMask  = 0x00ff0000
        case blueMask   = 0x0000ff00
        case alphaMask  = 0x000000ff
        static func redValue(_ value: CUnsignedInt) -> CGFloat {
            return CGFloat((value & redMask.rawValue) >> 24) / 255.0
            
        }
        static func greenValue(_ value: CUnsignedInt) -> CGFloat {
            return CGFloat((value & greenMask.rawValue) >> 16) / 255.0
        }
        static func blueValue(_ value: CUnsignedInt) -> CGFloat {
            return CGFloat((value & blueMask.rawValue) >> 8) / 255.0
        }
        static func alphaValue(_ value: CUnsignedInt) -> CGFloat {
            return CGFloat(value & alphaMask.rawValue) / 255.0
        }
        
    }
    fileprivate static func normalize(_ hex: String?) -> String {
        guard var hexString = hex
        else {
            return "00000000"
        }
        if let cssColor = cssToHexDictionairy[hexString.uppercased()] {
            return cssColor.count == 8 ? cssColor : cssColor + "ff"
        }
        if hexString.hasPrefix("#") {
            hexString = String(hexString.dropFirst())
        }
        if hexString.count == 3 || hexString.count == 4 {
            hexString = hexString.map { "\($0)\($0)" } .joined()
        }
        let hasAlpha = hexString.count > 7
        if !hasAlpha {
            hexString += "ff"
            
        }
        return hexString
        
    }    /**     All modern browsers support the following 140 color names (see http://www.w3schools.com/cssref/css_colornames.asp)     */
    fileprivate static func hexFromCssName(_ cssName: String) -> String {
        let key = cssName.uppercased()
        if let hex = cssToHexDictionairy[key] {
            return hex
            
        }
        return cssName
        
    }
    fileprivate static let cssToHexDictionairy: [String: String] = [
        "CLEAR": "00000000",
        "TRANSPARENT": "00000000",
        "": "00000000",
        "ALICEBLUE": "F0F8FF",
        "ANTIQUEWHITE": "FAEBD7",
        "AQUA": "00FFFF",
        "AQUAMARINE": "7FFFD4",
        "AZURE": "F0FFFF",
        "BEIGE": "F5F5DC",
        "BISQUE": "FFE4C4",
        "BLACK": "000000",
        "BLANCHEDALMOND": "FFEBCD",
        "BLUE": "0000FF",
        "BLUEVIOLET": "8A2BE2",
        "BROWN": "A52A2A",
        "BURLYWOOD": "DEB887",
        "CADETBLUE": "5F9EA0",
        "CHARTREUSE": "7FFF00",
        "CHOCOLATE": "D2691E",
        "CORAL": "FF7F50",
        "CORNFLOWERBLUE": "6495ED",
        "CORNSILK": "FFF8DC",
        "CRIMSON": "DC143C",
        "CYAN": "00FFFF",
        "DARKBLUE": "00008B",
        "DARKCYAN": "008B8B",
        "DARKGOLDENROD": "B8860B",
        "DARKGRAY": "A9A9A9",
        "DARKGREY": "A9A9A9",
        "DARKGREEN": "006400",
        "DARKKHAKI": "BDB76B",
        "DARKMAGENTA": "8B008B",
        "DARKOLIVEGREEN": "556B2F",
        "DARKORANGE": "FF8C00",
        "DARKORCHID": "9932CC",
        "DARKRED": "8B0000",
        "DARKSALMON": "E9967A",
        "DARKSEAGREEN": "8FBC8F",
        "DARKSLATEBLUE": "483D8B",
        "DARKSLATEGRAY": "2F4F4F",
        "DARKSLATEGREY": "2F4F4F",
        "DARKTURQUOISE": "00CED1",
        "DARKVIOLET": "9400D3",
        "DEEPPINK": "FF1493",
        "DEEPSKYBLUE": "00BFFF",
        "DIMGRAY": "696969",
        "DIMGREY": "696969",
        "DODGERBLUE": "1E90FF",
        "FIREBRICK": "B22222",
        "FLORALWHITE": "FFFAF0",
        "FORESTGREEN": "228B22",
        "FUCHSIA": "FF00FF",
        "GAINSBORO": "DCDCDC",
        "GHOSTWHITE": "F8F8FF",
        "GOLD": "FFD700",
        "GOLDENROD": "DAA520",
        "GRAY": "808080",
        "GREY": "808080",
        "GREEN": "008000",
        "GREENYELLOW": "ADFF2F",
        "HONEYDEW": "F0FFF0",
        "HOTPINK": "FF69B4",
        "INDIANRED": "CD5C5C",
        "INDIGO": "4B0082",
        "IVORY": "FFFFF0",
        "KHAKI": "F0E68C",
        "LAVENDER": "E6E6FA",
        "LAVENDERBLUSH": "FFF0F5",
        "LAWNGREEN": "7CFC00",
        "LEMONCHIFFON": "FFFACD",
        "LIGHTBLUE": "ADD8E6",
        "LIGHTCORAL": "F08080",
        "LIGHTCYAN": "E0FFFF",
        "LIGHTGOLDENRODYELLOW": "FAFAD2",
        "LIGHTGRAY": "D3D3D3",
        "LIGHTGREY": "D3D3D3",
        "LIGHTGREEN": "90EE90",
        "LIGHTPINK": "FFB6C1",
        "LIGHTSALMON": "FFA07A",
        "LIGHTSEAGREEN": "20B2AA",
        "LIGHTSKYBLUE": "87CEFA",
        "LIGHTSLATEGRAY": "778899",
        "LIGHTSLATEGREY": "778899",
        "LIGHTSTEELBLUE": "B0C4DE",
        "LIGHTYELLOW": "FFFFE0",
        "LIME": "00FF00",
        "LIMEGREEN": "32CD32",
        "LINEN": "FAF0E6",
        "MAGENTA": "FF00FF",
        "MAROON": "800000",
        "MEDIUMAQUAMARINE": "66CDAA",
        "MEDIUMBLUE": "0000CD",
        "MEDIUMORCHID": "BA55D3",
        "MEDIUMPURPLE": "9370DB",
        "MEDIUMSEAGREEN": "3CB371",
        "MEDIUMSLATEBLUE": "7B68EE",
        "MEDIUMSPRINGGREEN": "00FA9A",
        "MEDIUMTURQUOISE": "48D1CC",
        "MEDIUMVIOLETRED": "C71585",
        "MIDNIGHTBLUE": "191970",
        "MINTCREAM": "F5FFFA",
        "MISTYROSE": "FFE4E1",
        "MOCCASIN": "FFE4B5",
        "NAVAJOWHITE": "FFDEAD",
        "NAVY": "000080",
        "OLDLACE": "FDF5E6",
        "OLIVE": "808000",
        "OLIVEDRAB": "6B8E23",
        "ORANGE": "FFA500",
        "ORANGERED": "FF4500",
        "ORCHID": "DA70D6",
        "PALEGOLDENROD": "EEE8AA",
        "PALEGREEN": "98FB98",
        "PALETURQUOISE": "AFEEEE",
        "PALEVIOLETRED": "DB7093",
        "PAPAYAWHIP": "FFEFD5",
        "PEACHPUFF": "FFDAB9",
        "PERU": "CD853F",
        "PINK": "FFC0CB",
        "PLUM": "DDA0DD",
        "POWDERBLUE": "B0E0E6",
        "PURPLE": "800080",
        "RED": "FF0000",
        "ROSYBROWN": "BC8F8F",
        "ROYALBLUE": "4169E1",
        "SADDLEBROWN": "8B4513",
        "SALMON": "FA8072",
        "SANDYBROWN": "F4A460",
        "SEAGREEN": "2E8B57",
        "SEASHELL": "FFF5EE",
        "SIENNA": "A0522D",
        "SILVER": "C0C0C0",
        "SKYBLUE": "87CEEB",
        "SLATEBLUE": "6A5ACD",
        "SLATEGRAY": "708090",
        "SLATEGREY": "708090",
        "SNOW": "FFFAFA",
        "SPRINGGREEN": "00FF7F",
        "STEELBLUE": "4682B4",
        "TAN": "D2B48C",
        "TEAL": "008080",
        "THISTLE": "D8BFD8",
        "TOMATO": "FF6347",
        "TURQUOISE": "40E0D0",
        "VIOLET": "EE82EE",
        "WHEAT": "F5DEB3",
        "WHITE": "FFFFFF",
        "WHITESMOKE": "F5F5F5",
        "YELLOW": "FFFF00",
        "YELLOWGREEN": "9ACD32"
    ]}

