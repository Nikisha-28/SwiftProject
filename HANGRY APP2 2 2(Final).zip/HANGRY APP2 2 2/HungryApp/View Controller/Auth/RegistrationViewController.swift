//
//  RegistrationViewController.swift
//  HungryApp
//
//  Created by differenz152 on 08/02/23.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase
import FirebaseFirestore

class RegistrationViewController: UIViewController, UINavigationControllerDelegate {

    //var register = [TblRegister]()
   
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var txtfname: UITextField!
    @IBOutlet weak var txtpnum: UITextField!
    @IBOutlet weak var txtlname: UITextField!
    @IBOutlet weak var txtemail: UITextField!
    @IBOutlet weak var txtaddress: UITextField!
    @IBOutlet weak var txtpwd: UITextField!
    @IBOutlet weak var btnSignUp: UIButton!
    @IBOutlet weak var btnLogin: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGestures = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        imgProfile.isUserInteractionEnabled = true
        imgProfile.addGestureRecognizer(tapGestures)
        
        //register = DBHelper.share.fetchUser()

        //print(register.count)

        txtfname.layer.cornerRadius = 20
        txtfname.clipsToBounds = true
        txtlname.layer.cornerRadius = 20
        txtlname.clipsToBounds = true
        txtpnum.layer.cornerRadius = 20
        txtpnum.clipsToBounds = true
        txtemail.layer.cornerRadius = 20
        txtemail.clipsToBounds = true
        txtaddress.layer.cornerRadius = 20
        txtaddress.clipsToBounds = true
        txtpwd.layer.cornerRadius = 20
        txtpwd.clipsToBounds = true
        btnSignUp.layer.cornerRadius = 20
        btnSignUp.clipsToBounds = true
        
        imgProfile.layer.borderWidth = 1.0
        imgProfile.layer.masksToBounds = false
        imgProfile.layer.borderColor = UIColor.white.cgColor
        imgProfile.layer.cornerRadius = imgProfile.frame.size.height/2
        imgProfile.clipsToBounds = true
    }
    @objc
    func imageTapped(tapGestureRecognizer: UITapGestureRecognizer){
        openGallery()
        //print("Image Tapped!!")
    }
    
    // MARK: - ACTION METHODS
    
    @IBAction func btnSignUpTouchUpInside(_ sender: Any) {
        
        let fname = txtfname.text!
        let lname = txtlname.text!
        let phoneno = txtpnum.text!
        let email = txtemail.text!
        let address = txtaddress.text!
        let password = txtpwd.text!
//        let id = UUID()

        func insert(){
        
            if let Fname = txtfname.text,let Lname = txtlname.text,let phone = txtpnum.text,let email = txtemail.text,let address = txtaddress.text,let password = txtpwd.text, let image = imgProfile.image?.pngData()
            {
                let newRecord = TblRegister(context: DBHelper.share.context)
                newRecord.fname = Fname
                print(Fname)
                newRecord.lname = Lname
                //print(lname)
                newRecord.phno = phone
                //print(newRecord.phoneno)
                newRecord.email = email
                ///print(email)
                newRecord.address = address
                //print(address)
                newRecord.pwd = password
                newRecord.id = UUID()
                newRecord.image = image
                DBHelper.share.saveContext()
            }
        }
        if (fname.isEmpty || lname.isEmpty || phoneno.isEmpty || email.isEmpty || address.isEmpty || password.isEmpty){
            
            alert(message: "All Fields Required to Fill in", title: "Error")
            return
       
        }
        else if isValidPhone(phno: phoneno ) == false {
            alert(message: "Please Enter valid Phone Number", title: "Error")
        }
//        else if isvalidateEmail(email: email) == false {
//            alert(message: "Enter Proper Email", title: "Alert")
//        }
//        else if isvalidPassword(password: password) == false {
//            alert(message: "Password must be more than 8 characters, with at least one capital, numeric or special character", title: "Alert")
//        }
        else if isValidName(name: fname) == false {
            alert(message: "Please enter only character in First name", title: "Error")
        }
        else if isValidName(name: lname) == false {
            alert(message: "Please enter only character in Last name", title: "Error")
        }
        else{
 //           insert()
//            guard let fname = txtfname.text else {return}
//            guard let lname = txtlname.text else {return}
//            guard let image = imgProfile.image else {return}

            if let email = txtemail.text, let password = txtpwd.text{
            
                Auth.auth().createUser(withEmail: email, password: password) { (user , error) in

                    if error == nil
                    {
                        let userData : [String:Any] = ["firstname":self.txtfname.text! as String,
                                        "lastname":self.txtlname.text ?? "",
                                        "phoneNumber":self.txtpnum.text ?? "",
                                        "email":self.txtemail.text ?? "",
                                        "address":self.txtaddress.text ?? "",
                                        "password":self.txtpwd.text ?? "",
                                        "image":(self.imgProfile.image?.pngData()) ?? Data()
                        ]
                        print(userData)
                        let db = Firestore.firestore()
                        db.collection("users").document(user?.user.uid ?? "").setData(userData) { error in
                            if error == nil {
                                print("DONE..")
                                
                            }
                        }
                        self.showToast(message: "Registration Successful")
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5)
                        {
                            self.navigationController?.popToRootViewController(animated: true)
                        }
                        
                       
                    }
                    else
                    {
                        let alertcontroller = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
                        let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                        alertcontroller.addAction(defaultAction)
                        self.present(alertcontroller, animated: true, completion: nil)
                    }
                }
            }
        }
    }
//        func uploadProfile(_ image:UIImage, completion: @escaping ((_ url: URL?) -> ())){
//            guard let uid = Auth.auth().currentUser?.uid else {return}
//            let storageRef = Storage.storage().reference().child("user/\(uid)")
//
//            guard let imageData = imgProfile.image?.jpegData(compressionQuality: 0.75) else {return}
//
//            let metaData = StorageMetadata()
//            metaData.contentType = "image/jpeg"
//            print("METADATA :: \(metaData)")
//
//            storageRef.putData(imageData, metadata: metaData) { metaData, error in
//                if let error = error {
//                    print("Oh no! Got an Error! \(error.localizedDescription)")
//                    return
//                    //success
//                }else{
//                    print("Put is complete and I got this back")
//                    //failed
//                    //completion(nil)
//                }
//            }
//        }
    
    
//    func createUser(fname : String,lname : String,email : String, phno: String,address : String, password : String, completionBlock : @escaping (_ success: Bool) -> Void) {
//        Auth.auth().createUser(withEmail: email, password: password) {(authResult, error) in
//            if let user = authResult?.user {
//                print(user)
//                completionBlock(true)
//            } else {
//                completionBlock(false)
//
//            }
//
//        }
//    }
    
    
    

    @IBAction func btnLoginTouchUpInside(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let MainTB = storyboard.instantiateViewController(withIdentifier: "login")
        
        (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.changeRootViewController(MainTB)
        
    }
}

//MARK: - Set Profile picture from gallery

extension RegistrationViewController: UIImagePickerControllerDelegate{
    
    func openGallery()
    {
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.sourceType = .savedPhotosAlbum
            picker.allowsEditing = false
            present(picker,animated: true,completion: nil)
        }
    }
    
    func imagePickerController(_ picker:UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey:Any]){
        if let img = info[.originalImage] as? UIImage{
            imgProfile.image = img
        }
        dismiss(animated: true)
        
    }
}
