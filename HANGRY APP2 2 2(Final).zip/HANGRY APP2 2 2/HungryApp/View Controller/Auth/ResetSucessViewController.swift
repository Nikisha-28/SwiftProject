//
//  ResetSucessViewController.swift
//  HungryApp
//
//  Created by differenz152 on 28/02/23.
//

import UIKit

class ResetSucessViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.isNavigationBarHidden = false

        // Do any additional setup after loading the view.
    }
   
    
//    @IBAction func btnback(_ sender: Any) {
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let MainTB = storyboard.instantiateViewController(withIdentifier: "ResetViewController")
//        
//        (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.changeRootViewController(MainTB)
//    }
    
    @IBAction func Login(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let login = storyboard.instantiateViewController(withIdentifier: "ViewController")
        
        (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.changeRootViewController(login)
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
