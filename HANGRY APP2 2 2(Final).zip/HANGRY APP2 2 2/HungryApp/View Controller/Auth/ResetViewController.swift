//
//  ResetViewController.swift
//  HungryApp
//
//  Created by differenz152 on 28/02/23.
//

import UIKit

class ResetViewController: UIViewController {

  
    
    @IBOutlet weak var txtphoneNo: UITextField!
    @IBOutlet weak var txtfname: UITextField!
    @IBOutlet weak var txtCpwd: UITextField!
    @IBOutlet weak var txtNewPwd: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.isNavigationBarHidden = false

//        let data = DBHelper.share.getUserData(byIdentifier: UserData.shared.id ?? UUID())
//        self.txtfname.text = data?.fname ?? ""
//        self.txtphone.text = data?.phoneno ?? ""
        
        txtfname.layer.cornerRadius = 22
        txtfname.clipsToBounds = true
        txtphoneNo.layer.cornerRadius = 22
        txtphoneNo.clipsToBounds = true
        txtNewPwd.layer.cornerRadius = 22
        txtNewPwd.clipsToBounds = true
        txtCpwd.layer.cornerRadius = 22
        txtCpwd.clipsToBounds = true
    }
    
    
    @IBAction func btnResetTouchUpInside(_ sender: Any) {
    
        if (txtNewPwd.text == "" || txtCpwd.text == ""){
            
            alert(message: "All Fields Required to Fill in", title: "Alert")
            return
        }
        else if isvalidPassword(password: txtNewPwd.text!) == false {
            alert(message: "Password must be more than 8 characters, with at least one capital, numeric or special character", title: "Alert")
        }
        else {
            if txtNewPwd.text! == txtCpwd.text!{
                   
                if let id  = UserData.shared.id {
                    let data = UserModel(
                        id: id,
                        //email: self.txtemail.text,
                        //fname: self.txtfname.text,
                        //lname: self.txtlname.text,
                        //address: self.txtaddress.text,
                        password: self.txtCpwd.text
                        //phoneno: self.txtpnum.text,
                        //image: self.imgProfile.image?.pngData()
                    )
                    DBHelper.share.addPassword(Identifier: id, data: data)
                    showToast(message: "Updated!")
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5)
                    {
                        let next = self.storyboard?.instantiateViewController(withIdentifier: "ResetSucessViewController") as! ResetSucessViewController
                        self.navigationController?.pushViewController(next, animated: true)
                        //self.navigationController?.popToRootViewController(animated: true)
                    }
                }
                
//                let next = self.storyboard?.instantiateViewController(withIdentifier: "ResetSucessViewController") as! ResetSucessViewController
//                self.navigationController?.pushViewController(next, animated: true)
            }
            else{
                alert(message: "Not Match", title: "Alert")

            }
        }
    }
    
    
    

}
