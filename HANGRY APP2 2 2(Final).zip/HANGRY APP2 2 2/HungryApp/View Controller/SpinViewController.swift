//
//  SpinViewController.swift
//  HungryApp
//
//  Created by differenz152 on 31/03/23.
//

import UIKit
import TTFortuneWheel

class SpinViewController: UIViewController {
    
    var arrayAStr: [String] = []
    var index : [Int] = []
    var angleArray = [CGFloat]()
//    var selectedCategory = ""
//    var angleItemsArray = [String]()
    
    @IBOutlet weak var spinningWheel: TTFortuneWheel!
    //    @IBOutlet weak var spinningWheel: TTFortuneWheel!
//    @IBOutlet weak var btnSpin: UIButton!
    //  @IBOutlet weak var btnSpin: GradientButton!
   // @IBOutlet weak var spinningWheel: TTFortuneWheel!
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "SPIN"
        setCustomNavbar()
        print(arrayAStr)
        print(index)
    
        spinningWheel.initialDrawingOffset = 270

        var slices: [CarnivalWheelSlice] = []
            for i in 0 ..< arrayAStr.count {
                let slice = CarnivalWheelSlice(title: "\(arrayAStr[i])")
                slices.append(slice)
                
            }
            spinningWheel.slices = slices
            spinningWheel.equalSlices = true
            spinningWheel.frameStroke.width = 0
            spinningWheel.titleRotation = CGFloat.pi
            spinningWheel.slices.enumerated().forEach { (pair) in
            let slice = pair.element as! CarnivalWheelSlice
            let offset = pair.offset
                switch offset % 5 {
                    case 0: slice.style = .brickRed
                    case 1: slice.style = .sandYellow
                    case 2: slice.style = .babyBlue
                    case 3: slice.style = .deepBlue
                    case 4: slice.style = .green
                default: slice.style = .brickRed
                }
            }
        }
/*
    lazy var Slice : [CarnivalWheelSlice] = {
        let Slice = arrayAStr.map({CarnivalWheelSlice.init(title: $0)})
        print(Slice)
        return Slice
    }()
    
    var finishIndex : Int{

        
        return Int.random(in: 0..<spinningWheel.slices.count)
    }
    */
//    func getCenterOffsetOfSliceWithIndex(forOffset offset: CGFloat) -> (offset: CGFloat, index: Int) {
//        let sliceSize = 360 / CGFloat(arrayAStr.count)
//        for i in (0..<arrayAStr.count) {
//            let lowerBound = CGFloat(i) * sliceSize
//            let upperBound = CGFloat(i+1) * sliceSize
//            let range = (lowerBound..<upperBound)
//            if range ~= offset {
//                return ((lowerBound + upperBound) / 2, i)
//            }
//        }
//        return (0, 0)
//    }
 /*
    func getRandomOffset() -> CGFloat {
        let offset = arc4random_uniform(360)
        if angleArray.contains(CGFloat(offset)) {
            return self.getRandomOffset()
        }
        return CGFloat(offset)
    }
    */
    
    @IBAction func btnSpinTouchUpInside(_ sender: UIButton) {
        
//        self.spinningWheel.startAnimating(fininshIndex: 5) { (finished) in
//            print(finished)
//            self.alert(message: "Finished..!!", title: "Alert")
//        }
 /*       spinningWheel.startAnimating()
        DispatchQueue.main.asyncAfter(deadline: .now() + 4.0) {
            //let _finishIndex = self.finishIndex
           // self.spinningWheel.startAnimating()
            let _finishIndex = self.finishIndex
            self.spinningWheel.startAnimating(fininshIndex: _finishIndex) { (finished) in
//                print("FINISH INDEX: \(finished)")
                //print(self.arrayAStr[_finishIndex])
//                print("Index == \(_finishIndex)")
                var name = self.arrayAStr[_finishIndex]
                //print(name)
            } completionIndex: { idx in
                print("MY CURRENT INDEX ============================== \(self.arrayAStr[idx])")
                //self.alert(message: "Item is :: \(self.arrayAStr[idx])", title: "Alert")
            }
    }*/

        print(arrayAStr)
        self.spinningWheel.startAnimating { isBool in
            print("++++ isBool :: \(isBool) ++++")
            
        } completionIndex: { idx in
            var newId = idx
            if idx == self.arrayAStr.count {
                newId = 0
                
            }
            print("MY CURRENT INDEX ===\(self.arrayAStr[newId])")
           
//            DispatchQueue.main.asyncAfter(deadline: .now() + 4.7 )
//            {
//                self.alert(message: "Selected Item is : \(self.arrayAStr[newId])", title: "Alert")
//            }

        }
        

   /*     spinningWheel.startAnimating()
        sender.isUserInteractionEnabled = false
        DispatchQueue.main.asyncAfter(deadline: .now()){
            
            self.spinningWheel.startAnimating(offset: CGFloat(self.arrayAStr.count)) { (finished) in
                //self.playSound()
                let slice = self.getCenterOffsetOfSliceWithIndex(forOffset: CGFloat(self.arrayAStr.endIndex))
                let offset = slice.offset
                print(slice)
                
                let index = slice.index
                print ("Index===\(index)")
                self.selectedCategory = self.arrayAStr[index]
                print(self.selectedCategory)
 //               self.lblGeneratedName.text = self.selectedCategory.uppercased()
  //              self.lblgenerateland.text = self.selectedCategory.uppercased()
                sender.isUserInteractionEnabled = true
                self.alert(message: "Selected Item :: \(self.selectedCategory.uppercased())", title: "Alert")
            }
        }
    
    */
    }
    
    @IBAction func btnGoTouchUpInside(_ sender: Any) {
        let go = self.storyboard?.instantiateViewController(withIdentifier: "RestaurantViewController") as! RestaurantViewController
        self.navigationController?.pushViewController(go, animated: true)
    }
    
}
