//
//  GoogleMapViewController.swift
//  HungryApp
//
//  Created by differenz152 on 12/04/23.
//

import UIKit
import MapKit
import CoreLocation

class GoogleMapViewController: UIViewController ,CLLocationManagerDelegate,MKMapViewDelegate{

  //  var list : [Result] = [Result]()
    
    @IBOutlet weak var mapView: MKMapView!
    
    var manager = CLLocationManager()
    let pin = MKPointAnnotation()
    let pin2 = MKPointAnnotation()
    
    var coordinate = CLLocationCoordinate2DMake(21.193853, 72.786388)
    var fromBackCordinate: CLLocationCoordinate2D?

    override func viewDidLoad() {
        super.viewDidLoad()
        setCustomNavbar()
        self.navigationController?.navigationBar.isHidden = false
        self.navigationItem.backButtonTitle = "Back"
        
        
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.delegate = self
        manager.requestAlwaysAuthorization()
        manager.requestWhenInUseAuthorization()
        manager.startUpdatingLocation()
    
    
        //var zoom : MKZoomScale = 15
        
//        let distancespan :CLLocationDistance = 5000
//        let mapCoordinate = MKCoordinateRegion(center: coordinate, latitudinalMeters: distancespan, longitudinalMeters: distancespan)
//        mapView.setRegion(mapCoordinate, animated: true)
        
//        let latitudinalMeters: CLLocationDistance = 2000
//        let longitudinalMeters: CLLocationDistance = 2000
//        let region = MKCoordinateRegion(center: coordinate, latitudinalMeters: latitudinalMeters, longitudinalMeters: longitudinalMeters)
//        self.mapView.setRegion(region, animated: false)
        
        showRouteOnMap(pickupCoordinate: coordinate, destinationCoordinate: fromBackCordinate! )
       
        mapView.delegate = self
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    
    // MARK: - Location
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first{
            manager.stopUpdatingLocation()
            render(location)
        }
    }
    // MARK: - Get Location
    
    func render(_ location : CLLocation){
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        let region = MKCoordinateRegion(center: coordinate , span: span)
        mapView.setRegion(region, animated: false)
        
        pin.coordinate = coordinate
        
        pin2.coordinate = fromBackCordinate!
//        print("FromBackCoordinate",fromBackCordinate)
//        print("Coordinate ==",coordinate)
        mapView.addAnnotation(pin)
        mapView.addAnnotation(pin2)

    }

    func showRouteOnMap(pickupCoordinate: CLLocationCoordinate2D, destinationCoordinate: CLLocationCoordinate2D)
    {
        let request = MKDirections.Request()
        request.source = MKMapItem(placemark: MKPlacemark(coordinate: pickupCoordinate, addressDictionary: nil))
        request.destination = MKMapItem(placemark: MKPlacemark(coordinate: destinationCoordinate, addressDictionary: nil))
        request.requestsAlternateRoutes = true
        request.transportType = .automobile

        let directions = MKDirections(request: request)

        directions.calculate { [unowned self] response, error in
            guard let unwrappedResponse = response else { return }
            
            //for getting just one route
            if let route = unwrappedResponse.routes.first {
                    //show on map
            self.mapView.addOverlay(route.polyline)
                    //set the map area to show the route
            self.mapView.setVisibleMapRect(route.polyline.boundingMapRect, edgePadding: UIEdgeInsets.init(top: 80.0, left: 20.0, bottom: 100.0, right: 20.0), animated: false)
            }
        }
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let route = MKPolylineRenderer(overlay: overlay as! MKPolyline)
        route.strokeColor = .blue
        route.lineWidth = 4
        return route
    }
 
    @IBAction func btnBackTouchUpInside(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let mainTB = storyboard.instantiateViewController(identifier: "RestaurantViewController")
        (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.changeRootViewController(mainTB)
        //self.navigationController?.popViewController(animated: true)
    }
}
