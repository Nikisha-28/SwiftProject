//
//  EditProfileViewController.swift
//  HungryApp
//
//  Created by differenz152 on 24/02/23.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase
import FirebaseFirestore
import CoreMedia

class EditProfileViewController: UIViewController, UINavigationControllerDelegate {
    
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var txtfname: UITextField!
    @IBOutlet weak var txtlname: UITextField!
    @IBOutlet weak var txtpnum: UITextField!
    @IBOutlet weak var txtemail: UITextField!
    @IBOutlet weak var txtaddress: UITextField!
    @IBOutlet weak var txtpwd: UITextField!
    @IBOutlet weak var btn_change: UIButton!
        
    let uid : String = (Auth.auth().currentUser?.uid)!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "EDIT PROFILE"
      //  let dataOfUser = DBHelper.share.fetchUser()
       // print("DATA :: \(dataOfUser)")
        
//        self.txtemail.text = UserData.shared.Email
//        print("MY EMAIL IS :::: \(UserData.shared.Email)")
        
        
//        let data = DBHelper.share.getUserData(byIdentifier: UserData.shared.id ?? UUID())
//        self.txtemail.text = data?.email
//        self.txtfname.text = data?.fname
//        self.txtlname.text = data?.lname
//        self.txtpnum.text = data?.phoneno
//        self.txtaddress.text = data?.address
//        self.txtpwd.text = data?.password
//        self.imgProfile.image = UIImage(data: data?.image ?? Data())
        
        txtfname.layer.cornerRadius = 20
        txtfname.clipsToBounds = true
        txtlname.layer.cornerRadius = 20
        txtlname.clipsToBounds = true
        txtpnum.layer.cornerRadius = 20
        txtpnum.clipsToBounds = true
        txtemail.layer.cornerRadius = 20
        txtemail.clipsToBounds = true
        txtaddress.layer.cornerRadius = 20
        txtaddress.clipsToBounds = true
        txtpwd.layer.cornerRadius = 20
        txtpwd.clipsToBounds = true
 
        imgProfile.layer.borderWidth = 1.0
        imgProfile.layer.masksToBounds = false
        imgProfile.layer.borderColor = UIColor.white.cgColor
        imgProfile.layer.cornerRadius = imgProfile.frame.size.height/2
        imgProfile.clipsToBounds = true
        
        if Auth.auth().currentUser != nil{
            
            let db = Firestore.firestore()
            
            db.collection("users").document(uid).getDocument { data , error in
                print("CURRENT DATA UID >>> \(self.uid ?? "")")
                print("This is your Data :: \(data?.data())")
                //print("Eroor :: \(error)")
                let userData = data?.data()
                self.txtfname.text = userData?["firstname"] as? String
                self.txtlname.text = userData?["lastname"] as? String
                self.txtpnum.text = userData?["phoneNumber"] as? String
                self.txtemail.text = userData?["email"] as? String
                self.txtaddress.text = userData?["address"] as? String
                self.txtpwd.text = userData?["password"] as? String
                self.imgProfile.image =  UIImage(data: data?["image"] as? Data ?? Data())
            }
            
        }
        
    }
    
   /* override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
//        getName { (name) in
//            if let name = name {
//                self.txtfname.text = name
//                print("great success")
//            }
//        }
    }*/
    
/*    func getName(completion: @escaping(_ name: String?) -> Void){
        guard let id = Auth.auth().currentUser?.uid else {return}
        print("ID :: \(id)")
        let docRef = Firestore.firestore().collection("users").document(id)
//        docRef.firestore.collection("users").document().setData(
//            [:
//
//        ], merge: <#T##Bool#>)
        
        //let dis = docRef.collection(id).document(self.txtfname.text ?? "")
//        docRef.getDocument { (document, error) in
//            if let document = document, document.exists{
//                let dataDescription = document.data().map(String.init(describing: )) ?? "nil"
//                print("DATA DESCRIPTION::\(dataDescription)")
//            }
//            else{
//                print("Document does not exists")
//            }
//            completion("..........")
//        }
    
    
    }*/
    
    
    @IBAction func btnChangeProfileTouchUpInside(_ sender: Any) {
        let img = UIImagePickerController()
        img.sourceType = .photoLibrary
        img.delegate = self
        img.allowsEditing = true
        present(img, animated: true)

    }
    @IBAction func btnChangeTouchUpInside(_ sender: Any) {
        
        if (txtfname.text == "" && txtlname.text == "" && txtpnum.text == "" && txtemail.text == "" && txtaddress.text == "" && txtpwd.text == ""){
            
            alert(message: "All Fields Requ ired to Fill in", title: "Alert")
            //return
       
        }
        else if isValidPhone(phno: txtpnum.text!) == false {
            alert(message: "Please Enter valid Phone Number", title: "Alert")
        }
//        else if isvalidateEmail(email: txtemail.text!) == false {
//            alert(message: "Enter Proper Email", title: "Alert")
//        }
//        else if isvalidPassword(password: txtpwd.text!) == false {
//            alert(message: "Password must be more than 8 characters, with at least one capital, numeric or special character", title: "Alert")
//        }
        else if isValidName(name: txtfname.text!) == false {
            alert(message: "Please enter only character in First name", title: "Alert")
        }
        else if isValidName(name: txtlname.text!) == false {
            alert(message: "Please enter only character in Last name", title: "Alert")
        }
        else{
            
            let userData : [String:Any] = ["firstname":self.txtfname.text ?? "",
                                           "lastname":self.txtlname.text ?? "",
                                           "phoneNumber":self.txtpnum.text ?? "",
                                           "email":self.txtemail.text ?? "",
                                           "address":self.txtaddress.text ?? "",
                                           "password":self.txtpwd.text ?? "",
                                           "image":self.imgProfile.image?.pngData()
            ]
            print(userData)
            let userEmail = Auth.auth().currentUser?.email
            let db = Firestore.firestore()
            db.collection("users").document(self.uid).updateData(userData)
            if txtemail.text != userEmail{
                Auth.auth().currentUser?.updateEmail(to: txtemail.text ?? "") { error in
                    if error != nil{
                        self.navigationController?.popToRootViewController(animated: true)
                    }
                    else{
                        print("ERROR..")
                    }
                }
            }
            else{
                self.navigationController?.popToRootViewController(animated: true)
            }
        
            
      /*      if let id  = UserData.shared.id {
                let data = UserModel(
                    id: id,
                    email: self.txtemail.text ?? "",
                    fname: self.txtfname.text ?? "",
                    lname: self.txtlname.text ?? "",
                    address: self.txtaddress.text ?? "",
                    password: self.txtpwd.text ?? "",
                    phoneno: self.txtpnum.text ?? "",
                    image: self.imgProfile.image?.pngData()
                )
         //       DBHelper.share.updateData(Identifier: id, data: data)
          //      showToast(message: "Updated!")
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5)
                {
                    self.navigationController?.popToRootViewController(animated: true)
                }
            }*/
//            showToast(message: "Regiser Successfully!")
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5)
//            {
//                self.navigationController?.popToRootViewController(animated: true)
//            }
        }
    }
}
extension EditProfileViewController: UIImagePickerControllerDelegate{
    

    func imagePickerController(_ picker:UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey:Any]){
        if let img = info[.originalImage] as? UIImage{
            imgProfile.image = img
        }
        dismiss(animated: true)
        
    }
}


