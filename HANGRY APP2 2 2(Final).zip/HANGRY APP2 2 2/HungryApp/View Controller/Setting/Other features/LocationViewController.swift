//
//  LocationViewController.swift
//  HungryApp
//
//  Created by differenz152 on 23/02/23.
//

import UIKit
import MapKit
import CoreLocation

class LocationViewController: UIViewController,CLLocationManagerDelegate,MKMapViewDelegate{
    
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var btn_Done: UIButton!
    
    let coordinate = CLLocationCoordinate2DMake(21.170240, 72.831062)
    var circle = MKCircle()
    let manager = CLLocationManager()
    //var location: CLLocation!
    let pin = MKPointAnnotation()
    //let coordinate = CLLocationCoordinate2DMake(21.170240, 72.831062)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "RANGE OF DISTANCE"

        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.delegate = self
        manager.requestWhenInUseAuthorization()
        manager.startUpdatingLocation()
        
        mapView.delegate = self
        mapView.region = MKCoordinateRegion(center: coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
        
        mapView.layer.borderColor = UIColor.blue.cgColor
        mapView.layer.borderWidth = 1
 
    }

    // MARK: - Location
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first{
            manager.stopUpdatingLocation()
            render(location)
        }
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let circleRenderer = MKCircleRenderer(overlay: overlay)
        circleRenderer.strokeColor = UIColor.blue
        circleRenderer.fillColor = UIColor(red: 0, green: 0, blue: 0.35, alpha: 0.20)
        circleRenderer.lineWidth = 2.0
        return circleRenderer
    }

    // MARK: - Get Location
    
    func render(_ location : CLLocation){
//        let coordinate = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        let region = MKCoordinateRegion(center: coordinate, span: span)
        mapView.setRegion(region, animated: true)
        
        pin.coordinate = coordinate
        mapView.addAnnotation(pin)

    }
    
    // MARK: - Slider Effect
    
    @IBAction func slider(_ sender: UISlider) {
    
        mapView.removeOverlay(circle)
        let newRadius = slider.value*100
        circle = MKCircle(center : coordinate, radius: CLLocationDistance(newRadius))

        mapView.addOverlay(circle)
        
        /*  let currentValue = Int(slider.value)
        print(currentValue)  */
    }
    // MARK: - Action Method
    
    @IBAction func btnDoneTouchUpInside(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let mainTB = storyboard.instantiateViewController(identifier: "tabbarViewController")
        (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.changeRootViewController(mainTB)
    }
}
