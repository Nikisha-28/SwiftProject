//
//  ContactUsViewController.swift
//  HungryApp
//
//  Created by differenz152 on 10/03/23.
//

import UIKit
import MessageUI

class ContactUsViewController: UIViewController,MFMailComposeViewControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "CONTACT US"

        Email()
    }
    
    func Email() {
        if MFMailComposeViewController.canSendMail() {
            let mail = MFMailComposeViewController()
            mail.mailComposeDelegate = self
            mail.setToRecipients(["nikisha.palsanawala@differenzsystem.com"])
            mail.setMessageBody("", isHTML: true)

            present(mail, animated: true)
        } else {
        }
    }

    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    

}
