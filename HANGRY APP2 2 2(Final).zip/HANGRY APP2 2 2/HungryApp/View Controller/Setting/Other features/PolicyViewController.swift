//
//  PolicyViewController.swift
//  HungryApp
//
//  Created by differenz152 on 28/02/23.
//

import UIKit
import WebKit

class PolicyViewController: UIViewController,WKUIDelegate {

    var webView : WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "PRIVACY POLICY"
        
        let url = URL(string: "https://www.differenzsystem.com/")
        let request = URLRequest(url: url!)
        webView.load(request)
    }
    
    override func loadView() {
        let configure = WKWebViewConfiguration()
        webView = WKWebView(frame: .zero, configuration: configure)
        webView.uiDelegate = self
        view = webView
        
        let topGradientColor = UIColor.magenta
        let bottomGradientColor = UIColor.blue

        let gradientLayer = CAGradientLayer()
        
        gradientLayer.frame = navigationItem.accessibilityFrame
        gradientLayer.colors = [topGradientColor.cgColor,bottomGradientColor.cgColor]

        gradientLayer.startPoint = CGPoint(x: 0.0, y: 5.0)
        gradientLayer.endPoint = CGPoint(x: 4.5, y: 2.0)

        gradientLayer.locations = [0.0,1.0]
        // navigationItem.layer.insertSublayer(gradientLayer, at: 1)
    }

    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
