//
//  CustomTableViewCell.swift
//  HungryApp
//
//  Created by differenz152 on 15/03/23.
//

import UIKit

class CustomTableViewCell: UITableViewCell {

    
    @IBOutlet weak var iconImg: UIImageView!
    
    @IBOutlet weak var lbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        iconImg.layer.cornerRadius = 10
        iconImg.clipsToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
