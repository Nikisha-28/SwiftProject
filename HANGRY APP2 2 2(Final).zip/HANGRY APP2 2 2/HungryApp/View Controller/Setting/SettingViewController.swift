//
//  SettingViewController.swift
//  HungryApp
//
//  Created by differenz152 on 13/02/23.
//

import UIKit
import FirebaseAuth

class SettingViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
   
 
    @IBOutlet weak var table: UITableView!
    
    
    struct setting{
        let title : String
        let icon : String
    }
 
    let data: [setting] = [
        setting(title: "Edit Profile", icon: "iconeditProfile"),
        setting(title: "Select Range of Distance", icon: "icondistance"),
        setting(title: "About Us", icon: "iconAboutUs"),
        setting(title: "Contact Us", icon: "iconContactUs"),
        setting(title: "Privcy Policy", icon: "iconLock"),
        setting(title: "Log Out", icon: "iconLogout")
        
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "SETTING"
        
        table.dataSource = self
        table.delegate = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let images = data[indexPath.row]
        let cell = table.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustomTableViewCell
        cell.lbl.text = images.title
        cell.iconImg.image = UIImage(named: images.icon)
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0
        {
            let loc = self.storyboard?.instantiateViewController(withIdentifier:"EditProfileViewController") as! EditProfileViewController
            self.navigationController?.pushViewController(loc, animated: true)
        }
        else if indexPath.row == 1
        {
            let loc = self.storyboard?.instantiateViewController(withIdentifier: "LocationViewController") as! LocationViewController
            self.navigationController?.pushViewController(loc, animated: true)
        }
        else if indexPath.row == 2
        {
            print("About Us")
        }
        else if indexPath.row == 3
        {
            let con = self.storyboard?.instantiateViewController(withIdentifier:"ContactUsViewController") as! ContactUsViewController
            self.navigationController?.pushViewController(con, animated: true)
        }
        else if indexPath.row == 4
        {
            let policy = self.storyboard?.instantiateViewController(withIdentifier: "PolicyViewController") as! PolicyViewController
            self.navigationController?.pushViewController(policy, animated: true)

        }
        else if indexPath.row == 5
        {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let logout = storyboard.instantiateViewController(withIdentifier: "login")
            (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.changeRootViewController(logout)
//            if Auth.auth().currentUser != nil{
//                do{
//                    try Auth.auth().signOut()
//                    print("Log Out")
//                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//                    let logout = storyboard.instantiateViewController(withIdentifier: "login")
//                    (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.changeRootViewController(logout)
//                }
//                catch let error as NSError{
//                    print(error.localizedDescription)
//                }
//            }
        }
    }
    
    

}
