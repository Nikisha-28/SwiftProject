//
//  RestaurantTableViewCell.swift
//  HungryApp
//
//  Created by differenz152 on 11/04/23.
//

import UIKit
import Cosmos

class RestaurantTableViewCell: UITableViewCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var cosmosView: CosmosView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblOpen: UILabel!
    var completion: ((Bool) -> ())?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        img.layer.cornerRadius = 10
        img.clipsToBounds = true
        

        cosmosView.settings.starSize = 22
        
        // Show only fully filled,half filled or precise stars
        cosmosView.settings.fillMode = .precise
        cosmosView.settings.filledColor = UIColor.yellow

        // Do not change rating when touched
        // Use if you need just to show the stars without getting user's input
        cosmosView.settings.updateOnTouch = false

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    @IBAction func btnDirectionTouchUpInside(_ sender: Any) {
        self.completion!(true)
    }
    
}
