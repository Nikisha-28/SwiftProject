//
//  DBHelper.swift
//  HungryApp
//
//  Created by differenz152 on 21/03/23.
//

import Foundation
import UIKit
import Foundation
import CoreData
class DBHelper
{
    static let share = DBHelper()
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "CoreData")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
        if let error = error as NSError? {
            fatalError("Unresolved error \(error), \(error.userInfo)")
        }
        })
        return container
    }()
    // MARK: - Core Data Saving support
    lazy var context = persistentContainer.viewContext
    func saveContext () {
        if context.hasChanges {
            do {
                try context.save()

            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    // MARK: - Core Data Fetch
    func fetchUser() -> [TblRegister]
    {
        var login = [TblRegister]()
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: TblRegister.description())
        do
        {
            login = try context.fetch(request) as! [TblRegister]
        }
        catch
        {
            print("Error")
        }
        return login
    }
    // MARK: - Fetch Details (EditProfile)
    
    func getUserData(byIdentifier id: UUID) -> TblRegister?
    {
        let fetchRequest = NSFetchRequest<TblRegister>(entityName: "TblRegister")
        let predicate = NSPredicate(format: "id==%@", id as CVarArg)
        fetchRequest.predicate = predicate
        do{
            let result = try context.fetch(fetchRequest)
            let first = result.first
            guard  first != nil else { return nil }
            return first
        } catch let error {
            
            debugPrint(error)
        }
        return nil
    }
   //MARK: - Update Data
 
    func updateData(Identifier id: UUID, data: UserModel) -> TblRegister?
    {
        var login = [TblRegister]()
        let fetchRequest = NSFetchRequest<TblRegister>(entityName: "TblRegister")
        let predicate = NSPredicate(format: "id==%@", id as CVarArg)
        fetchRequest.predicate = predicate
        do
        {
            login = try context.fetch(fetchRequest) as [TblRegister]
            let value = login.first!
            value.setValue("\(data.fname ?? "")", forKey: "fname")
            value.setValue("\(data.lname ?? "")", forKey: "lname")
            value.setValue("\(data.phoneno ?? "")", forKey: "phoneno")
            value.setValue("\(data.email ?? "")", forKey: "email")
            value.setValue("\(data.address ?? "")", forKey: "address")
            value.setValue("\(data.password ?? "")", forKey: "password")
            value.setValue(data.image, forKey: "image")
            do{
                try context.save()
                return value
            }
            catch{
                print("Error")
            }
        }
        catch
        {
            print("Error")
        }
        return nil
    }

    
//MARK: - Forgot Password

func addPassword(Identifier id: UUID, data: UserModel) -> TblRegister?
{
    var login = [TblRegister]()
    let fetchRequest = NSFetchRequest<TblRegister>(entityName: "TblRegister")
    let predicate = NSPredicate(format: "id==%@", id as CVarArg)
    fetchRequest.predicate = predicate
    do
    {
        login = try context.fetch(fetchRequest) as [TblRegister]
        let value = login.first!
//        value.setValue("\(data.fname ?? "")", forKey: "fname")
//        value.setValue("\(data.lname ?? "")", forKey: "lname")
//        value.setValue("\(data.phoneno ?? "")", forKey: "phoneno")
//        value.setValue("\(data.email ?? "")", forKey: "email")
//        value.setValue("\(data.address ?? "")", forKey: "address")
        value.setValue("\(data.password ?? "")", forKey: "password")
        //value.setValue(data.image, forKey: "image")
        do{
            try context.save()
            return value
        }
        catch{
            print("Error")
        }
    }
    catch
    {
        print("Error")
    }
    return nil
}
    

    
    
    
}

