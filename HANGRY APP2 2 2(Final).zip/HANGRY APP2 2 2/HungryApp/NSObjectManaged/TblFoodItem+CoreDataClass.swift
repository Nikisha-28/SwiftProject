//
//  TblFoodItem+CoreDataClass.swift
//  HungryApp
//
//  Created by differenz147 on 30/03/23.
//
//

import Foundation
import CoreData

@objc(TblFoodItem)
public class TblFoodItem: NSManagedObject {

}
