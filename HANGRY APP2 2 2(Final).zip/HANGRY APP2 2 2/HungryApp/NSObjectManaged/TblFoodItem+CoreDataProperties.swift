//
//  TblFoodItem+CoreDataProperties.swift
//  HungryApp
//
//  Created by differenz147 on 30/03/23.
//
//

import Foundation
import CoreData


extension TblFoodItem {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<TblFoodItem> {
        return NSFetchRequest<TblFoodItem>(entityName: "TblFoodItem")
    }

    @NSManaged public var image: Data?
    @NSManaged public var itemName: String?
//    @NSManaged public var checkMark: Bool?
    

}

extension TblFoodItem : Identifiable {
    func foodItem() -> ItemModel
    {
        return ItemModel (
            image: self.image ?? Data(),
            itemName: self.itemName ?? "")
    }
}
