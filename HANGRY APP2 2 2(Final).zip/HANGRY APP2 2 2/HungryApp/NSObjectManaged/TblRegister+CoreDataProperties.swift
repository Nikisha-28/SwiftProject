//
//  TblRegister+CoreDataProperties.swift
//  HungryApp
//
//  Created by differenz147 on 27/03/23.
//
//

import Foundation
import CoreData


extension TblRegister {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<TblRegister> {
        return NSFetchRequest<TblRegister>(entityName: "TblRegister")
    }

    @NSManaged public var address: String?
    @NSManaged public var email: String?
    @NSManaged public var fname: String?
    @NSManaged public var id: UUID?
    @NSManaged public var lname: String?
    @NSManaged public var phno: String?
    @NSManaged public var pwd: String?
    @NSManaged public var image: Data?

}

extension TblRegister : Identifiable {
    
    func convertToUserData() -> UserModel
    {
        return UserModel(id: self.id ?? UUID(), email: self.fname ?? "", fname: self.lname ?? "", lname: self.phno ?? "", address: self.email ?? "", password: self.address ?? "", phoneno: self.pwd ?? "", image: self.image ?? Data())
    }
}
