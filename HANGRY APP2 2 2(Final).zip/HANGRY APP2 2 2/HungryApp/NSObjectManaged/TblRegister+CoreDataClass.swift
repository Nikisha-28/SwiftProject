//
//  TblRegister+CoreDataClass.swift
//  HungryApp
//
//  Created by differenz147 on 27/03/23.
//
//

import Foundation
import CoreData

@objc(TblRegister)
public class TblRegister: NSManagedObject {

}
